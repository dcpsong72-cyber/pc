# Build PixelForge for Windows 10/11

Two ways to get a real `.exe` — pick one.

> **Why not an .exe straight from this chat?** Windows binaries must be compiled
> on Windows (or under Wine). PixelForge's sandbox is Linux, so here are the two
> standard routes: run one script locally, or let GitHub's machines build it and
> download the result. Both produce identical installers.

---

## Route A — one script on your PC (fastest)

1. Install **Python 3.10+** once: <https://python.org> (tick **Add python.exe to PATH**).
2. Copy this folder to your PC (it *is* this folder — the ZIP you downloaded).
3. Double-click **`packaging\build_exe.bat`** and wait ~5 minutes.

Results:

```
dist\PixelForge\PixelForge.exe        ← portable app (no install, run from anywhere)
```

Optional, a proper **Setup installer**:

1. Install [Inno Setup](https://jrsoftware.org/isinfo.php) (free, one time).
2. Double-click `packaging\installer.iss` → **Compile** (or run
   `iscc packaging\installer.iss`).

Result:

```
dist\installer\PixelForge-4.0-Setup-win64.exe   ← installer with Start-menu /
                                                   desktop shortcuts + uninstaller
```

## Route B — let GitHub build it (nothing to install)

1. Create a GitHub account → **New repository** (can be private).
2. Upload this whole folder (drag & drop works on the repo page — includes
   `.github/workflows/windows-build.yml`).
3. Repo page → **Actions** tab → **Windows build (exe + setup)** → **Run workflow**.
4. ~6 minutes later, the same run page has downloadable artifacts:
   - `PixelForge-4.0-Setup-win64` (the installer)
   - `PixelForge-4.0-portable-win64` (zipped portable exe)

Pushing a tag like `v4.0` also publishes both files to **Releases**.

---

## Troubleshooting

**"'py' is not recognized"** / **"'python' is not recognized"** — Python isn't
installed, or wasn't added to PATH. Fix: <https://www.python.org/downloads/> →
run the installer → on the **first screen tick "Add python.exe to PATH"** →
Install Now → run `build_exe.bat` again. (The script auto-detects `py`,
`python` and `python3`, so any normal install works; Microsoft Store Python
works too, but the python.org one is recommended.)

**Build fails with a long path / path-not-found error** — move the folder to a
short path like `C:\PixelForge\` first.

**Virus warnings on the built exe** — see SmartScreen note below.

## Notes

- **SmartScreen**: unsigned builds show "Windows protected your PC" on first
  run → *More info* → *Run anyway*. Normal for all open-source apps without a
  code-signing certificate (~$100+/yr).
- **.msi?** The Setup `.exe` (Inno) is the recommended format for desktop apps.
  If your organisation strictly requires `.msi`, build the same
  `dist\PixelForge\` output with [WiX v6](https://wixtoolset.org)
  (`wix convert` + harvest) — no code changes needed.
- Everything ships **inside** the exe folder: `assets\` (fonts, icons, action
  sets, sample image). No registry junk; the installer only writes shortcuts +
  an uninstall entry.
- App size ≈ 120–180 MB (PySide6 + OpenCV + numpy bundled).
