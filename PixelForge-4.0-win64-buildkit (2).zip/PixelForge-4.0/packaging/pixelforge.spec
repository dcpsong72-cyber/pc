# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for PixelForge (Windows).
# Build from the repo root:  pyinstaller packaging\pixelforge.spec
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(SPEC)))

a = Analysis(
    [os.path.join(ROOT, "app.py")],
    pathex=[ROOT],
    binaries=[],
    datas=[
        (os.path.join(ROOT, "assets", "icons"), os.path.join("assets", "icons")),
        (os.path.join(ROOT, "assets", "fonts"), os.path.join("assets", "fonts")),
        (os.path.join(ROOT, "assets", "actions"), os.path.join("assets", "actions")),
        (os.path.join(ROOT, "assets", "sample.png"), "assets"),
    ],
    hiddenimports=[
        "cv2",
        "scipy.ndimage",
        "scipy.special",
        "psd_tools",
        "PIL.Image",
        "PIL.ImageDraw",
        "PIL.ImageFont",
        "PIL.ImageFilter",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "matplotlib",
        "IPython",
        "notebook",
        "PySide6.QtWebEngineCore",
        "PySide6.QtWebEngineWidgets",
        "PySide6.QtQml",
        "PySide6.QtQuick",
        "PySide6.QtCharts",
        "PySide6.QtDataVisualization",
        "PySide6.QtPdf",
    ],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="PixelForge",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=os.path.join(ROOT, "assets", "icons", "pixelforge.ico"),
    version=os.path.join(ROOT, "packaging", "version_info.txt"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="PixelForge",
)
