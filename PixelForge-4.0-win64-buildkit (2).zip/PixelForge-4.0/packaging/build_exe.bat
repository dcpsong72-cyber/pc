@echo off
rem ============================================================
rem  PixelForge 4.0 - one-command Windows build (Windows 10/11)
rem  Produces: dist\PixelForge\PixelForge.exe  (portable app)
rem  Then run installer.iss with Inno Setup for a Setup .exe.
rem ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0\.."

rem ---- find a Python 3: py launcher, then python, then python3 ----
set "PYCMD="
py -3 --version >nul 2>nul
if not errorlevel 1 set "PYCMD=py -3"
if not defined PYCMD (
    python --version >nul 2>nul
    if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
    python3 --version >nul 2>nul
    if not errorlevel 1 set "PYCMD=python3"
)
if defined PYCMD (
    for /f "delims=" %%v in ('%PYCMD% --version 2^>^&1') do set "PYVER=%%v"
    echo Found !PYVER! - good.
) else (
    echo Python 3 was not found on this PC.
    echo.
    echo FIX - two minutes:
    echo   1. Open  https://www.python.org/downloads/
    echo   2. Download and run the installer.
    echo   3. On the FIRST screen, TICK  "Add python.exe to PATH".
    echo   4. Click Install Now, then run build_exe.bat again.
    echo.
    echo Rather not install anything? GitHub builds it for you - see
    echo packaging\README_BUILD.md  Route B  (upload folder, press Run).
    pause
    exit /b 1
)

echo [1/4] Preparing the virtual environment .venv ...
if not exist .venv\Scripts\python.exe (
    if exist .venv rmdir /s /q .venv
    %PYCMD% -m venv .venv
    if errorlevel 1 (echo venv failed & pause & exit /b 1)
)

echo [2/4] Installing dependencies - 2 to 4 minutes on first run...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip -q
python -m pip install -r requirements.txt -q || (echo pip install failed - check your internet & pause & exit /b 1)
python -m pip install pyinstaller -q || (echo pyinstaller install failed & pause & exit /b 1)

echo [3/4] Building the app - 2 to 5 minutes...
python -m PyInstaller packaging\pixelforge.spec --noconfirm --clean || (echo build failed & pause & exit /b 1)

echo [4/4] Done.
echo.
echo   Portable app : %cd%\dist\PixelForge\PixelForge.exe
echo   Optional Setup installer: install Inno Setup, then run
echo       iscc packaging\installer.iss
echo.
echo Launching PixelForge...
start "" dist\PixelForge\PixelForge.exe
endlocal
