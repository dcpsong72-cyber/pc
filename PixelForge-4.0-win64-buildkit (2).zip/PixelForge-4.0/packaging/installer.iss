; ============================================================
;  PixelForge 4.0 - Inno Setup script (Windows 10/11)
;  Compile:  iscc packaging\installer.iss
;  Needs the PyInstaller build first:  packaging\build_exe.bat
;  Output: dist\installer\PixelForge-4.0-Setup-win64.exe
;  Per-user install (no admin/UAC needed).
; ============================================================

#define MyAppName "PixelForge"
#define MyAppVersion "4.0"
#define MyAppExeName "PixelForge.exe"

[Setup]
AppId={{7E6A2F90-5B1D-4C7E-9A34-1F2C3D4E5F60}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
UninstallDisplayIcon={app}\{#MyAppExeName}
OutputDir=..\dist\installer
OutputBaseFilename=PixelForge-{#MyAppVersion}-Setup-win64
SetupIconFile=..\assets\icons\pixelforge.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\dist\PixelForge\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent
