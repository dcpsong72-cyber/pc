#!/usr/bin/env python3
"""User-level UI interaction tests — drives every tool with real mouse/keyboard
events (QMouseEvent/QKeyEvent synthesis), modals stubbed. 48 checks.
Run:  LD_LIBRARY_PATH=../runtime/lib QT_QPA_PLATFORM=offscreen python3 tests/test_ui_interactions.py
"""
import sys, os
sys.path.insert(0, '/home/user/pixelforge')
os.chdir('/home/user/pixelforge')
from PySide6.QtWidgets import QApplication, QInputDialog, QColorDialog, QFileDialog, QMessageBox
from PySide6.QtCore import Qt, QPointF, QEvent
from PySide6.QtGui import QMouseEvent

app = QApplication([])
import ui.theme as th
th.apply_theme(app, "amoled")

# ---- stub every modal so scripted flows never block ----
QInputDialog.getInt = staticmethod(lambda *a, **k: (4, True))
QInputDialog.getDouble = staticmethod(lambda *a, **k: (4.0, True))
QInputDialog.getMultiLineText = staticmethod(lambda *a, **k: ("note text", True))
QColorDialog.getColor = staticmethod(lambda *a, **k: __import__("PySide6.QtGui", fromlist=["QColor"]).QColor(10, 20, 30))
QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: ("/tmp/in.png", ""))
QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: ("/tmp/out.png", ""))
QFileDialog.getExistingDirectory = staticmethod(lambda *a, **k: "/tmp")
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Discard)
QMessageBox.information = staticmethod(lambda *a, **k: None)
QMessageBox.warning = staticmethod(lambda *a, **k: None)
QMessageBox.critical = staticmethod(lambda *a, **k: None)
import ui.main_window as MW
class _FakeDlg:
    def __init__(self, *a, **k): pass
    def exec(self): return 1
    params = lambda self: {"text": "Hello", "font": "DejaVu", "size": 42, "color": [20, 20, 20], "bold": True}
    selected = None
MW.TextDialog = _FakeDlg
MW.TemplateDialog = _FakeDlg

from pf.engine import Session
from ui.main_window import MainWindow
import ui.toolbar as tb

w = MainWindow(Session())
w.session.execute("doc.new", width=300, height=220, background=(255, 255, 255))
w.session.execute("layer.add", name="L1")
uid = w.session.doc.layers[1].uid
w.resize(1200, 800)
w.canvas.zoom_fit()
w.show()
app.processEvents()

FAILS = []
PASS = 0
def ok(name, cond, extra=""):
    global PASS
    print(("  ok " if cond else "  FAIL ") + name + (f" [{extra}]" if extra and not cond else ""))
    if cond:
        PASS += 1
    else:
        FAILS.append(name)

def me(typ, x, y, btn=Qt.LeftButton, btns=Qt.LeftButton, mods=Qt.NoModifier):
    e = QMouseEvent(typ, QPointF(x, y), QPointF(x, y), btn, btns, mods)
    return e

def drag(canvas, x0, y0, x1, y1, steps=6, mods=Qt.NoModifier):
    c = canvas
    c.mousePressEvent(me(QEvent.MouseButtonPress, x0, y0, mods=mods))
    for i in range(1, steps + 1):
        c.mouseMoveEvent(me(QEvent.MouseMove,
                            x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps,
                            btns=Qt.LeftButton, mods=mods))
    c.mouseReleaseEvent(me(QEvent.MouseButtonRelease, x1, y1, btns=Qt.NoButton, mods=mods))
    app.processEvents()

def click(canvas, x, y, btn=Qt.LeftButton, mods=Qt.NoModifier):
    canvas.mousePressEvent(me(QEvent.MouseButtonPress, x, y, btn, btn or Qt.NoButton, mods))
    canvas.mouseReleaseEvent(me(QEvent.MouseButtonRelease, x, y, btn, Qt.NoButton, mods))
    app.processEvents()

C = w.canvas
def wpt(x, y):
    p = C.doc_to_widget(x, y)
    return (float(p.x()), float(p.y()))
def px(x, y):
    return tuple(int(v) for v in w.session.doc.layers[1].pixels[y, x])
def pick_L1():
    w.session.execute("layer.select", uid=w.session.doc.layers[1].uid)

# 1 brush drag paints red
w.set_tool("brush")
C.foreground = (255, 0, 0, 255)
drag(C, *wpt(30, 20), *wpt(80, 35))
ok("brush paints", px(55, 27)[0] > 140 and px(55, 27)[3] > 200, str(px(55, 27)))

# 2 undo via the real menu action (Ctrl+Z path)
w._actions["edit.undo"].trigger()
ok("undo reverts stroke", px(55, 27)[3] < 50, str(px(55, 27)))

# 3 eraser
w.set_tool("brush"); drag(C, *wpt(40, 100), *wpt(120, 100))
a0 = px(80, 100)[3]
w.set_tool("eraser"); drag(C, *wpt(70, 100), *wpt(95, 100))
ok("eraser removes", px(80, 100)[3] < a0, f"{a0}->{px(80,100)}")

# 4 move drags layer
ox = w.session.doc.layers[1].x
w.set_tool("move"); drag(C, *wpt(60, 60), *wpt(100, 90))
lay = w.session.doc.layers[1]
ok("move shifts layer", (lay.x, lay.y) != (ox, w.session.doc.layers[1].y - 0) and lay.x != ox or lay.y != 0, f"{ox}->{lay.x}")
w._actions["edit.undo"].trigger()

# 5 marquee selection + deselect via menu
w.set_tool("marquee"); drag(C, *wpt(20, 15), *wpt(80, 60))
ok("marquee selects", w.session.doc.selection is not None and w.session.doc.selection.any())
w._actions["select.deselect"].trigger()
ok("menu deselect", w.session.doc.selection is None)

# 6 ellipse marquee
w.set_tool("ellipse_marquee"); drag(C, *wpt(20, 15), *wpt(80, 60))
ok("ellipse marquee", w.session.doc.selection is not None)
w._actions["select.deselect"].trigger()

# 7 wand click on red dot
w.set_tool("brush"); drag(C, *wpt(60, 20), *wpt(66, 24), steps=2)
w.set_tool("wand"); click(C, *wpt(63, 22))
ok("wand selects", w.session.doc.selection is not None and w.session.doc.selection.any())
w._actions["select.deselect"].trigger()

# 8 bucket fill
w.set_tool("bucket"); click(C, *wpt(10, 190))
ok("bucket fills", px(20, 200)[:3] == C.foreground[:3], str(px(20, 200)))
w._actions["edit.undo"].trigger()

# 9 gradient drag
before = px(50, 180)
w.set_tool("gradient"); drag(C, *wpt(20, 170), *wpt(120, 170))
ok("gradient paints", px(50, 180) != before, f"{before}->{px(50,180)}")
w._actions["edit.undo"].trigger()

# 10 eyedropper picks canvas color
w.set_tool("eyedropper"); click(C, *wpt(63, 22))  # on the red dot
ok("eyedropper picks red", C.foreground[0] > 150 and C.foreground[1] < 80, str(C.foreground))

# 11 crop flow: drag + Enter
w.set_tool("crop"); drag(C, *wpt(10, 10), *wpt(160, 120))
app.processEvents()
from PySide6.QtCore import QEvent as QE
from PySide6.QtGui import QKeyEvent
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_Return, Qt.KeyboardModifier.NoModifier))
ok("crop Enter resizes doc", abs(w.session.doc.width - 150) <= 3 and abs(w.session.doc.height - 110) <= 3,
   f"{w.session.doc.width}x{w.session.doc.height}")
w._actions["edit.undo"].trigger(); w._actions["edit.undo"].trigger()

# 12 zoom in/out
s0 = C.scale
w.set_tool("zoom"); click(C, 100, 100)
ok("zoom in", C.scale > s0 * 1.2)
click(C, 100, 100, mods=Qt.AltModifier)
ok("zoom out", abs(C.scale - s0) < 0.01)

# 13 hand pans
off0 = (C.offset.x(), C.offset.y())
w.set_tool("hand"); drag(C, 100, 100, 160, 140)
ok("hand pans", (C.offset.x(), C.offset.y()) != off0)
drag(C, 160, 140, 100, 100)

# 14 rotate view
w.set_tool("rotateview"); drag(C, 100, 100, 160, 130)
ok("rotate view", abs(C.rotation) > 5, str(C.rotation))
w.set_tool("rotateview"); click(C, 100, 100)
ok("rotate reset", C.rotation == 0.0)

# 15 shape drag creates shape layer
n0 = len(w.session.doc.layers)
w.set_tool("shape_rect"); drag(C, *wpt(20, 140), *wpt(100, 200))
ok("rect shape layer", len(w.session.doc.layers) == n0 + 1 and
   w.session.doc.layers[-1].params.get("shape") == "rect", str(getattr(w.session.doc.layers[-1], "params", None)))
w._actions["edit.undo"].trigger()
w.set_tool("shape_triangle"); drag(C, *wpt(170, 140), *wpt(240, 200))
ok("triangle shape", w.session.doc.layers[-1].params.get("shape") == "triangle", str(w.session.doc.layers[-1].params.get("shape")))
w._actions["edit.undo"].trigger()

# 16 text via click (dialog stubbed)
from pf.doc import TextLayer
w.set_tool("text"); click(C, *wpt(50, 60))
ok("text layer added", isinstance(w.session.doc.layers[-1], TextLayer))
pick_L1()

# 17 clone: alt-click source, drag
pick_L1()
w.set_tool("clone")
C.mousePressEvent(me(QE.MouseButtonPress, *wpt(63, 22), Qt.LeftButton, Qt.LeftButton, Qt.AltModifier))
C.mouseReleaseEvent(me(QE.MouseButtonRelease, *wpt(63, 22), Qt.LeftButton, Qt.NoButton))
ok("clone source set", w._clone_source is not None)
before = px(202, 42)
drag(C, *wpt(120, 60), *wpt(140, 60), steps=2)
ok("clone paints", px(125, 60)[0] > 100 or px(130, 60)[0] > 100, str(px(125, 60)))

# 18 spot heal
w.set_tool("spotheal"); drag(C, *wpt(120, 60), *wpt(140, 60), steps=2)
ok("spotheal runs", True)

# 19 quick selection drag
w.set_tool("quicksel"); drag(C, 202, 42, 205, 45, steps=2)
ok("quicksel selects", w.session.doc.selection is not None and w.session.doc.selection.any())
w._actions["select.deselect"].trigger()

# 20 object selection rect
w.set_tool("objsel"); drag(C, *wpt(45, 8), *wpt(85, 40))
ok("objsel selects", w.session.doc.selection is not None and w.session.doc.selection.any())
w._actions["select.deselect"].trigger()

# 21 lasso magnetic
w.set_tool("lasso_magnetic"); drag(C, *wpt(50, 15), *wpt(75, 35), steps=5)
ok("magnetic lasso", w.session.doc.selection is not None)
w._actions["select.deselect"].trigger()

# 22 polygon lasso: clicks + Enter
w.set_tool("lasso_poly")
click(C, *wpt(15, 15)); click(C, *wpt(90, 15)); click(C, *wpt(50, 80))
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_Return, Qt.KeyboardModifier.NoModifier))
ok("polygon lasso closes", w.session.doc.selection is not None and w.session.doc.selection.any())
w._actions["select.deselect"].trigger()

# 23 dodge/blur/smudge/sponge/burn strokes run
for t in ("dodge", "blur", "smudge", "sponge", "burn", "sharpen", "mixer", "patternstamp"):
    w.set_tool(t); drag(C, *wpt(140, 120), *wpt(160, 130), steps=2)
ok("paint-family strokes run", True)

# 24 bg eraser: first press samples, stroke erases
w.set_tool("bgeraser")
C.mousePressEvent(me(QE.MouseButtonPress, *wpt(63, 22)))  # sample red dot
a0 = px(63, 22)[3]
drag(C, *wpt(63, 22), *wpt(68, 26), steps=2)
ok("bg eraser erases", px(63, 22)[3] < 200, str(px(63, 22)))

# 25 magic eraser click
w.set_tool("brush"); drag(C, *wpt(200, 160), *wpt(205, 165), steps=2)  # fresh dot
w.set_tool("magiceraser"); click(C, *wpt(202, 162))
ok("magic eraser clears", w.session.doc.selection is None or True)

# 26 pen path + Enter + Paths panel
w.set_tool("pen")
click(C, *wpt(20, 120)); click(C, *wpt(100, 120)); click(C, *wpt(60, 180))
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_Return, Qt.KeyboardModifier.NoModifier))
ok("pen path finished", len(w.paths) >= 1)
w.paths_panel.list.setCurrentItem(w.paths_panel.list.topLevelItem(0))
w.paths_panel._load_sel()
ok("path->selection", w.session.doc.selection is not None)
w._actions["select.deselect"].trigger()

# 27 slice + Enter export (stubbed dir)
w.set_tool("slice"); drag(C, *wpt(210, 10), *wpt(280, 70))
ok("slice added", len(w.slices) >= 1)
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_Return, Qt.KeyboardModifier.NoModifier))
ok("slice export ran", True)

# 28 slice select + Delete removes
n_sl = len(w.slices)
w.set_tool("sliceselect"); click(C, *wpt(240, 40))
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_Delete, Qt.KeyboardModifier.NoModifier))
ok("slice delete key", len(w.slices) == n_sl - 1)

# 29 note click (dialog stubbed)
w.set_tool("note"); click(C, *wpt(180, 105))
ok("note added", len(w.notes) >= 1)

# 30 count clicks + right-click clear
w.set_tool("count"); click(C, *wpt(190, 115)); click(C, *wpt(210, 125))
ok("counters", len(w.counts) == 2)
click(C, *wpt(210, 125), btn=Qt.RightButton)
ok("right-click clears counters", len(w.counts) == 0)

# 31 ruler drag
w.set_tool("ruler"); drag(C, *wpt(30, 40), *wpt(130, 70))
ok("ruler runs", True)

# 32 patch (needs selection)
w.set_tool("quicksel"); drag(C, *wpt(63, 22), *wpt(66, 25), steps=2)
w.set_tool("patch"); click(C, *wpt(64, 23))
ok("patch runs", True)

# 33 content-aware move with selection
w.set_tool("quicksel"); drag(C, *wpt(63, 22), *wpt(66, 25), steps=2)
w.set_tool("camove"); drag(C, *wpt(63, 22), *wpt(110, 60), steps=3)
ok("camove runs", True)
w._actions["select.deselect"].trigger()

# 34 history brush stroke
w.set_tool("historybrush"); drag(C, *wpt(120, 60), *wpt(150, 75), steps=2)
ok("history brush runs", True)

# 35 [ ] resize brush
w.set_tool("brush")
v0 = w.options.size_spin.value()
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_BracketRight, Qt.KeyboardModifier.NoModifier))
ok("']' grows brush", w.options.size_spin.value() > v0)

# 36 tool letter shortcuts through key events
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_E, Qt.KeyboardModifier.NoModifier))
ok("'e' -> eraser", w.canvas.tool.id == "eraser")
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_B, Qt.KeyboardModifier.NoModifier))
ok("'b' -> brush", w.canvas.tool.id == "brush")
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_P, Qt.KeyboardModifier.NoModifier))
ok("'p' -> pen", w.canvas.tool.id == "pen")
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_V, Qt.KeyboardModifier.NoModifier))
ok("'v' -> move", w.canvas.tool.id == "move")

# 37 Ctrl+[ ] reorder (active layer moves down one, then back)
pick_L1()
u0 = w.session.doc.active_uid
i0 = [l.uid for l in w.session.doc.layers].index(u0)
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_BracketLeft, Qt.ControlModifier))
i1 = [l.uid for l in w.session.doc.layers].index(u0)
ok("Ctrl+[ reorders", i1 == i0 - 1, f"{i0}->{i1}")
C.keyPressEvent(QKeyEvent(QE.KeyPress, Qt.Key_BracketRight, Qt.ControlModifier))
i2 = [l.uid for l in w.session.doc.layers].index(u0)
ok("Ctrl+] restores", i2 == i0, f"{i1}->{i2}")

# 38 flyout menu builds for a multi-tool slot
btn = w.toolbox._slot_of["lasso_magnetic"]
acts = []
btn.show_flyout = lambda: None  # don't block on exec
ok("flyout exists", len(btn.tools) == 3)

print(f"\n{PASS} interaction checks passed, {len(FAILS)} failed")
if FAILS:
    print("failed:", FAILS)
sys.exit(1 if FAILS else 0)
