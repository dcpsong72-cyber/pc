"""Engine tests (no Qt). Run: python3 tests/test_pf.py"""

import os
import sys
import tempfile

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pf import color as C, compose, psdio
from pf.doc import Document, PixelLayer, GroupLayer
from pf.engine import Session

PASS = 0
FAIL = 0


def check(name, cond, info=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ok  {name}")
    else:
        FAIL += 1
        print(f"FAIL  {name} {info}")


def layer_solid(w, h, rgb, a=255, x=0, y=0, name="L"):
    px = np.zeros((h, w, 4), np.uint8)
    px[..., :3] = rgb
    px[..., 3] = a
    return PixelLayer(name=name, pixels=px, x=x, y=y)


# ---------------------------------------------------------------- blend math
print("== blend math ==")
s = Session()

# normal == source-over
dst = layer_solid(4, 4, (0, 0, 255), 255)
src = layer_solid(4, 4, (255, 0, 0), 128)
out = C.over(np.zeros((4, 4, 4), np.float32), np.full((4, 4, 4), 0.5, np.float32) * np.array([1, 0, 0, 1], np.float32), C.NORMAL)
check("normal blend keeps src color", np.allclose(out[..., 0], 0.5))

# multiply: white x color = color; black x color = black
check("multiply white==identity", np.allclose(C.blend_rgb(C.MULTIPLY, np.ones((2, 2, 3), np.float32), np.full((2, 2, 3), 0.3, np.float32)), 0.3))
check("multiply black==black", np.allclose(C.blend_rgb(C.MULTIPLY, np.zeros((2, 2, 3), np.float32), np.full((2, 2, 3), 0.3, np.float32)), 0.0))
check("screen identity 1-(1-a)(1-b)", np.allclose(
    C.blend_rgb(C.SCREEN, np.full((2, 2, 3), 0.2, np.float32), np.full((2, 2, 3), 0.6, np.float32)),
    1.0 - (1 - 0.2) * (1 - 0.6)))
check("multiply+screen cross", np.allclose(
    C.blend_rgb(C.SCREEN, np.full((2, 2, 3), 0.2, np.float32), C.blend_rgb(C.MULTIPLY, np.full((2, 2, 3), 0.2, np.float32), np.full((2, 2, 3), 0.6, np.float32))),
    C.blend_rgb(C.SCREEN, np.full((2, 2, 3), 0.2, np.float32), 0.2 * 0.6 * np.ones((2, 2, 3), np.float32))))
check("difference symmetric", np.allclose(
    C.blend_rgb(C.DIFFERENCE, np.full((2, 2, 3), 0.3, np.float32), np.full((2, 2, 3), 0.8, np.float32)),
    C.blend_rgb(C.DIFFERENCE, np.full((2, 2, 3), 0.8, np.float32), np.full((2, 2, 3), 0.3, np.float32))))

# non-separable: hue of red over blue backdrop keeps backdrop luminosity
dst_rgb = np.full((1, 1, 3), 0.25, np.float32)
src_rgb = np.full((1, 1, 3), np.float32([1, 0, 0]), np.float32)[0][None, None]
res = C.blend_rgb(C.COLOR, src_rgb, dst_rgb)
check("color mode keeps backdrop luminosity", np.isclose(C._lum(res)[0, 0], C._lum(dst_rgb)[0, 0], atol=1e-4))

# ---------------------------------------------------------------- compose
print("== compositor ==")
s.execute("doc.new", width=10, height=10, background=(255, 0, 0))
s.execute("layer.add", name="blue", fill=(0, 0, 255))
s.execute("layer.setProps", opacity=0.5)
comp = compose.composite_rgba8(s.doc)
check("opacity 50% red+blue = violet", abs(int(comp[5, 5, 0]) - 128) < 3 and abs(int(comp[5, 5, 2]) - 128) < 3,
      str(comp[5, 5]))

s2 = Session()
s2.execute("doc.new", width=8, height=8, background=(0, 0, 0))
s2.execute("layer.add", name="off", fill=(255, 255, 0))
s2.execute("layer.setProps", visible=False)
comp2 = compose.composite_rgba8(s2.doc)
check("invisible layer not composited", tuple(comp2[4, 4][:3]) == (0, 0, 0))

# offset layer clipped at canvas edge
s3 = Session()
s3.execute("doc.new", width=8, height=8, background=(0, 0, 0))
s3.execute("layer.add", name="patch", fill=(0, 255, 0))
s3.execute("layer.translate", dx=6, dy=6)
comp3 = compose.composite_rgba8(s3.doc)
check("offset layer clipped", tuple(comp3[7, 7][:3]) == (0, 255, 0) and tuple(comp3[2, 2][:3]) == (0, 0, 0))

# ---------------------------------------------------------------- history
print("== history ==")
s4 = Session()
s4.execute("doc.new", width=10, height=10, background=(255, 255, 255))
s4.execute("layer.add", name="paint", fill=(0, 0, 0))
layer_before = s4.doc.layers[1].pixels.copy()
s4.execute("paint.stroke", points=[(2, 2), (6, 6)], size=4, color=(255, 0, 0, 255))
check("stroke changed pixels", not np.array_equal(s4.doc.layers[1].pixels, layer_before))
s4.undo()
check("undo restores pixels", np.array_equal(s4.doc.layers[1].pixels, layer_before))
s4.redo()
check("redo reapplies stroke", not np.array_equal(s4.doc.layers[1].pixels, layer_before))

s4.execute("layer.setProps", opacity=0.3)
check("setProps applied", abs(s4.doc.layers[1].opacity - 0.3) < 1e-6)
s4.undo()
check("setProps undo", abs(s4.doc.layers[1].opacity - 1.0) < 1e-6)

# reorder undo
s4.execute("layer.reorder", uid=s4.doc.layers[1].uid, to_flat_index=0)
check("reorder applied", s4.doc.layers[0].name == "paint")
s4.undo()
check("reorder undone", s4.doc.layers[1].name == "paint")

# ---------------------------------------------------------------- PSD I/O
print("== psd round trip ==")
tmp = tempfile.mkdtemp()
s5 = Session()
s5.execute("doc.new", width=64, height=48, background=(200, 10, 10))
s5.execute("layer.add", name="green box", fill=(0, 200, 0))
s5.execute("layer.translate", dx=8, dy=4)
s5.execute("layer.add", name="blue box", fill=(0, 0, 200))
s5.execute("layer.translate", dx=30, dy=20)
s5.execute("layer.setProps", opacity=0.6, blend=C.MULTIPLY)
psd_path = os.path.join(tmp, "t.psd")
s5.execute("doc.save", path=psd_path)
check("psd written", os.path.exists(psd_path) and os.path.getsize(psd_path) > 1000)

s6 = Session()
doc = psdio.read(psd_path)
s6.doc = doc
check("psd layer count", len(doc.layers) == 3, str([l.name for l in doc.layers]))
check("psd layer order (bottom-to-top)", doc.layers[0].name == "Background", str([l.name for l in doc.layers]))
check("psd layer offsets", doc.layers[1].x == 8 and doc.layers[1].y == 4,
      f"({doc.layers[1].x},{doc.layers[1].y})")
check("psd blend mode", doc.layers[2].blend == C.MULTIPLY, doc.layers[2].blend)
check("psd opacity", abs(doc.layers[2].opacity - 0.6) < 0.01, str(doc.layers[2].opacity))

# composite before save == after read (within rounding)
before = compose.composite_rgba8(s5.doc).astype(np.int16)
after = compose.composite_rgba8(doc).astype(np.int16)
check("psd composite survives round trip", np.abs(before - after).mean() < 2.0,
      f"mean diff {np.abs(before-after).mean():.2f}")

# png round trip
png_path = os.path.join(tmp, "t.png")
s5.execute("doc.save", path=png_path)
doc_png = psdio.read(png_path)
check("png opens with single layer", len(doc_png.layers) == 1 and doc_png.width == 64)

# jpeg
jpg_path = os.path.join(tmp, "t.jpg")
s5.execute("doc.save", path=jpg_path)
check("jpeg written", os.path.exists(jpg_path))

# ----------------------------------------------- engine parity (PhotoCraft)
ENGINE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                      "..", "engine", "photocraft-cli")
if os.path.exists(ENGINE):
    print("== PhotoCraft engine parity ==")
    from pf.bridge import PhotoCraftBridge
    from PIL import Image
    import subprocess

    b = PhotoCraftBridge()
    if b.start():
        def parity(label, blend=None, opacity=None):
            s = Session()
            s.execute("doc.new", width=120, height=90, background=(200, 10, 10))
            s.execute("layer.add", name="box", fill=(0, 200, 0))
            s.execute("layer.translate", dx=15, dy=10)
            kw = {}
            if blend: kw["blend"] = blend
            if opacity is not None: kw["opacity"] = opacity
            if kw: s.execute("layer.setProps", **kw)
            p = os.path.join(tmp, "p.psd")
            s.execute("doc.save", path=p)
            idx = b.open_document(p)
            eng = b.render(idx).convert("RGBA")
            eng = np.asarray(eng, np.uint8)
            ours = compose.composite_rgba8(s.doc)
            d = np.abs(ours.astype(int) - eng.astype(int))
            check(f"engine parity {label}", (d <= 8).mean() > 0.99,
                  f"match={(d<=8).mean()*100:.1f}% mean={d.mean():.2f}")

        parity("normal 100%")
        parity("normal 60%", opacity=0.6)
        parity("multiply 100%", blend=C.MULTIPLY)
        parity("multiply 60%", blend=C.MULTIPLY, opacity=0.6)
        parity("screen 100%", blend=C.SCREEN)
        parity("overlay 80%", blend=C.OVERLAY, opacity=0.8)
        parity("luminosity 100%", blend=C.LUMINOSITY)
        parity("difference 100%", blend=C.DIFFERENCE)

        # multi-layer stacking with offset small layers
        s = Session()
        s.execute("doc.new", width=90, height=60, background=(255, 255, 255))
        for name, rgb, x in (("red", (255, 0, 0), 0), ("green", (0, 255, 0), 20), ("blue", (0, 0, 255), 40)):
            px = np.zeros((60, 25, 4), np.uint8); px[..., :3] = rgb; px[..., 3] = 255
            s.execute("layer.add", name=name, pixels=px)
            s.execute("layer.translate", dx=x, dy=0)
        p = os.path.join(tmp, "stack.psd")
        s.execute("doc.save", path=p)
        idx = b.open_document(p)
        eng = np.asarray(b.render(idx).convert("RGBA"), np.uint8)
        ours = compose.composite_rgba8(s.doc)
        d = np.abs(ours.astype(int) - eng.astype(int))
        check("engine parity stacking", (d <= 8).mean() > 0.99,
              f"match={(d<=8).mean()*100:.1f}%")
        b.close()
    else:
        print("== engine parity SKIPPED (bridge unavailable) ==")
else:
    print("== engine parity SKIPPED (no engine binary) ==")

print(f"\n{PASS} passed, {FAIL} failed")
sys.exit(1 if FAIL else 0)
