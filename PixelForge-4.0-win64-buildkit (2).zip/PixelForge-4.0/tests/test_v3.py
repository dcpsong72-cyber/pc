#!/usr/bin/env python3
"""v3 suite — 2026-era features (AI Studio, Blur Gallery, Color Lookup,
Clarity/Dehaze/Grain layers, Photomerge/HDR). All on-device."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ok  {name}")
    else:
        FAIL += 1
        print(f"  FAIL  {name} {extra}")


def scene():
    """160x120 sky-over-hill test scene; returns (session, layer_uid)."""
    from pf.engine import Session
    s = Session()
    s.execute("doc.new", width=160, height=120, background=(135, 190, 235))
    s.execute("layer.add", name="hill")
    px = s.doc.layers[1].pixels
    px[90:, :, :3] = (60, 90, 40)
    px[90:, :, 3] = 255
    return s


def test_new_adjustment_layers():
    from pf import adjust
    rgb = np.random.default_rng(3).random((40, 50, 3)).astype(np.float32) * 0.6 + 0.2
    for kind in ("clarity", "dehaze", "grain"):
        out = adjust.apply_adjustment(rgb, kind, {"amount": 0.4, "strength": 0.5})
        check(f"adjustment layer {kind}", out.shape == rgb.shape and np.isfinite(out).all())
    # clarity with amount 0 must be identity
    same = adjust.apply_adjustment(rgb, "clarity", {"amount": 0.0})
    check("clarity amount=0 identity", np.allclose(same, rgb, atol=1e-5))
    # kinds registered for the engine + UI
    from pf.doc import ADJUSTMENT_KINDS, DEFAULT_ADJ_PARAMS
    for kind in ("clarity", "dehaze", "grain"):
        check(f"{kind} registered", kind in ADJUSTMENT_KINDS and kind in DEFAULT_ADJ_PARAMS)


def test_new_filters():
    from pf import filters as F
    px = np.zeros((64, 64, 4), np.uint8)
    rng = np.random.default_rng(5)
    px[..., :3] = rng.integers(40, 220, (64, 64, 3))
    px[..., 3] = 255
    for fid in ("irisBlur", "tiltShift", "fieldBlur", "colorHalftone",
                "dustAndScratches", "smartSharpen", "softPortrait", "bokehBackground",
                "lookVivid", "lookTealOrange", "lookWarmCinema", "lookNoir", "lookFade",
                "lookVintage", "lookCyberpunk", "lookBleach", "lookLandscape"):
        fn, defaults, _, _ = F.REGISTRY[fid]
        out = fn(px, **defaults)
        check(f"filter {fid}", out.shape == px.shape and out.dtype == np.uint8)
    # noir really desaturates
    noir = F.REGISTRY["lookNoir"][0](px)
    spread = int(noir[10, 10, 0]) - int(noir[10, 10, 2])
    check("lookNoir is monochrome", abs(spread) < 8, str(spread))
    # iris blur keeps the center sharp
    ir = F.REGISTRY["irisBlur"][0](px)
    check("irisBlur center sharp", int(ir[32, 32, 0]) == int(px[32, 32, 0]))


def test_ai_commands():
    s = scene()
    s.execute("image.upscaleSmart", factor=2)
    check("smart upscale 2x", (s.doc.width, s.doc.height) == (320, 240))
    s.execute("image.expandGen", left=40, right=40, top=30, bottom=0)
    check("generative expand", (s.doc.width, s.doc.height) == (400, 270))
    hill = s.doc.layers[0].pixels
    check("expand inpaint filled border", hill[5, 5, 3] == 255)
    # sky replace
    s2 = scene()
    s2.execute("layer.select", uid=s2.doc.layers[0].uid)
    s2.execute("image.skyReplace", preset="sunset")
    sky = s2.doc.layers[0].pixels
    check("sky replaced (warm)", sky[5, 5, 0] > 140 and sky[5, 5, 0] > sky[5, 5, 2] * 0.8,
          str(sky[5, 5]))
    s2.execute("image.skyReplace", preset="storm") if False else None
    # harmonize
    from pf.engine import Session
    s3 = Session()
    s3.execute("doc.new", width=120, height=120, background=(255, 255, 255))
    s3.execute("layer.add", name="obj")
    px = s3.doc.layers[1].pixels
    px[40:80, 40:80, :3] = (200, 60, 60)
    px[40:80, 40:80, 3] = 255
    s3.execute("layer.select", uid=s3.doc.layers[1].uid)
    before = s3.doc.layers[1].pixels.copy()
    s3.execute("layer.harmonize", strength=0.9)
    check("harmonize changes layer", not np.array_equal(before, s3.doc.layers[1].pixels))
    s3.undo()
    check("harmonize undo exact", np.array_equal(before, s3.doc.layers[1].pixels))
    # match color from a textured reference
    from PIL import Image
    rng = np.random.default_rng(9)
    ref = rng.integers(0, 255, (80, 80, 3), dtype=np.uint8)
    Image.fromarray(ref).save("/tmp/pf_ref.png")
    s3.execute("image.matchColorFile", path="/tmp/pf_ref.png", strength=0.9)
    check("match color runs", not np.array_equal(before, s3.doc.layers[1].pixels))


def test_photomerge_hdr():
    from PIL import Image
    rng = np.random.default_rng(11)
    base = rng.integers(0, 255, (220, 320, 3), dtype=np.uint8)
    Image.fromarray(base[:, :270]).save("/tmp/pf_p1.png")
    Image.fromarray(base[:, 50:]).save("/tmp/pf_p2.png")
    s = None
    from pf.engine import Session
    s = Session()
    try:
        s.execute("doc.photomerge", paths=["/tmp/pf_p1.png", "/tmp/pf_p2.png"])
        check("photomerge stitches", s.doc.width >= 200 and s.doc.height >= 150,
              f"{s.doc.width}x{s.doc.height}")
    except Exception as exc:
        check("photomerge stitches", False, str(exc)[:70])
    Image.fromarray((base * 0.45).astype(np.uint8)).save("/tmp/pf_e1.png")
    Image.fromarray(base).save("/tmp/pf_e2.png")
    Image.fromarray(np.clip(base.astype(np.int32) * 3 // 2, 0, 255).astype(np.uint8)).save("/tmp/pf_e3.png")
    s.execute("doc.hdrMerge", paths=["/tmp/pf_e1.png", "/tmp/pf_e2.png", "/tmp/pf_e3.png"])
    check("hdr merge size", (s.doc.width, s.doc.height) == (320, 220))
    px = s.doc.layers[0].pixels
    # Mertens result should be brighter than the dark bracket and less clipped than x1.5
    check("hdr tonemap sane", 60 < px.mean() < 250, f"mean {px.mean():.0f}")


def test_guided_recipes_exist():
    # window-level recipes verified in the UI suite; here just the dialog table
    try:
        from ui.main_window import GuidedActionsDialog
    except Exception as e:
        print(f"  (recipes check skipped: {type(e).__name__} — run with Qt libs)")
        return
    for k in ("remove background", "blur background", "vintage", "upscale", "square"):
        check(f"recipe '{k}'", k in GuidedActionsDialog.RECIPES)


if __name__ == "__main__":
    print("== PixelForge v3: 2026 features ==")
    test_new_adjustment_layers()
    test_new_filters()
    test_ai_commands()
    test_photomerge_hdr()
    test_guided_recipes_exist()
    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)
