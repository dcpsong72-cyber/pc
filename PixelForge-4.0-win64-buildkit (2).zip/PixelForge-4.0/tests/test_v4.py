#!/usr/bin/env python3
"""v4 suite — PS 27.6/27.11 + market pass: engine commands (Layer Cleanup,
Rotate Object, Product Shot, Relight, Restore, Portrait Pro, Find
Distractions, Focus Stack, Watermark), action recording, Actions panel,
NL search, Batch. All on-device."""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ok  {name}")
    else:
        FAIL += 1
        print(f"  FAIL  {name} {extra}")


def scene(w=120, h=120, bg=(240, 240, 240)):
    from pf.engine import Session
    s = Session()
    s.execute("doc.new", width=w, height=h, background=bg)
    s.execute("layer.add", name="subject")
    px = s.doc.layers[1].pixels
    px[30:90, 30:90, :3] = (200, 60, 60)
    px[30:90, 30:90, 3] = 255
    s.execute("layer.select", uid=s.doc.layers[1].uid)
    return s


# ---------------------------------------------------------------- engine v4
def test_layer_cleanup():
    s = scene(60, 60, (250, 250, 250))
    s.execute("layer.add", name="Red")
    px = s.doc.layers[2].pixels
    px[10:40, 10:40, :3] = (200, 30, 30)
    px[10:40, 10:40, 3] = 255
    s.execute("layer.add", name="Layer 3")  # stays empty -> removed
    snap = [(l.name, l.uid, None if l.pixels is None else l.pixels.copy())
            for l in s.doc.layers]
    res = s.execute("file.scripts.deleteAllEmptyLayers")
    check("cleanup removes empty + reports", res["removed"] == 1, str(res))
    check("cleanup keeps painted layers",
          [l.name for l in s.doc.layers] == ["Background", "subject", "Red"],
          str([l.name for l in s.doc.layers]))
    s.undo()
    ok = ([l.uid for l in s.doc.layers] == [t[1] for t in snap] and
          all(l.name == t[0] for l, t in zip(s.doc.layers, snap)) and
          all(t[2] is None or np.array_equal(l.pixels, t[2])
              for l, t in zip(s.doc.layers, snap)))
    check("cleanup exact undo (names+order+pixels)", ok)


def test_rotate_object():
    s = scene()
    before = s.doc.layers[1].pixels.copy()
    uid = s.execute("edit.rotateObject", angle=90)
    lay = s.doc.find(uid)
    check("rotateObject changes pixels", lay is not None and not np.array_equal(lay.pixels, before))
    check("rotateObject preserves alpha extent", int((lay.pixels[..., 3] > 0).sum()) ==
          int((before[..., 3] > 0).sum()))
    s.undo()
    check("rotateObject undo restores", np.array_equal(s.doc.layers[1].pixels, before))


def test_product_shot():
    s = scene()
    prev_w = s.doc.width
    res = s.execute("image.productShot", style="studio", shadow=True,
                    color=(245, 245, 247))
    doc = s.doc
    corner = doc.layers[0].pixels[3, 3, :3]
    check("productShot keeps canvas + backdrop",
          doc.width == prev_w and abs(int(corner[0]) - 245) < 12, str(corner))
    check("productShot keeps subject (not empty)",
          (doc.layers[0].pixels[..., :3].std() > 5))
    check("productShot replaces doc (Product layer, history reset by design)",
          [l.name for l in doc.layers] == ["Product"] and s.undo_stack == [])


def test_relight():
    s = scene()
    before = s.doc.layers[1].pixels.copy()
    s.execute("image.relight", angle=0, strength=0.6)   # light from the right
    after = s.doc.layers[1].pixels[...,:3].astype(int)
    check("relight changes image", not np.array_equal(after.astype(np.uint8), before))
    left = after[:, :40, :].mean()
    right = after[:, -40:, :].mean()
    check("relight is directional (asymmetry)", abs(right - left) > 0.2,
          f"left {left:.1f} right {right:.1f}")
    s.undo()
    check("relight undo restores", np.array_equal(s.doc.layers[1].pixels, before))


def test_restore_old():
    from pf.engine import Session
    s = Session()
    s.execute("doc.new", width=100, height=100, background=(180, 170, 160))
    rng = np.random.default_rng(5)
    px = s.doc.layers[0].pixels
    px[..., :3] = np.clip(px[..., :3] + rng.normal(0, 18, (100, 100, 1)), 0, 255).astype(np.uint8)
    noisy = px.copy()
    s.execute("image.restoreOld", denoise=10, colorize=False)
    import cv2
    out = s.doc.layers[0].pixels[..., :3]
    lap_before = cv2.Laplacian(noisy[..., :3].mean(axis=2), cv2.CV_64F).var()
    lap_after = cv2.Laplacian(out[..., :3].mean(axis=2), cv2.CV_64F).var()
    check("restoreOld denoises (local noise down)", lap_after < lap_before,
          f"{lap_before:.0f} -> {lap_after:.0f}")
    s2 = Session()
    s2.execute("doc.new", width=80, height=80, background=(120, 120, 120))
    before = s2.doc.layers[0].pixels[..., :3].astype(int)
    s2.execute("image.restoreOld", denoise=2, colorize=True)
    after = s2.doc.layers[0].pixels[..., :3].astype(int)
    check("restoreOld colorize warms", after[..., 0].mean() > before[..., 0].mean() - 1)


def test_portrait_pro():
    s = scene()
    before = s.doc.layers[1].pixels.copy()
    uid = s.execute("image.portraitPro", skin=0.5, eye=0.3)
    n = getattr(s, "last_faces", -1)
    check("portraitPro runs with/without face", n >= 0)
    s.undo()
    check("portraitPro undo restores", np.array_equal(s.doc.layers[1].pixels, before))


def test_find_distractions():
    s = scene()
    px = s.doc.layers[1].pixels
    rng = np.random.default_rng(2)
    for _ in range(10):
        x, y = int(rng.integers(35, 85)), int(rng.integers(35, 85))
        px[y:y + 2, x:x + 2, :3] = (250, 250, 250)
    before = px.copy()
    spots, healed, _ = s.execute("image.findDistractions")
    check("findDistractions detects specks", len(spots) >= 5, str(len(spots)))
    check("findDistractions heals tiny", healed >= 5, str(healed))
    s.undo()
    check("findDistractions undo restores", np.array_equal(s.doc.layers[1].pixels, before))


def test_focus_stack():
    from PIL import Image
    a = np.zeros((80, 80, 3), np.uint8)
    a[20:60, 20:60] = (180, 40, 40)
    b = a.copy()
    b[40:70, 40:70] = (40, 90, 200)
    d = tempfile.mkdtemp()
    p1, p2 = os.path.join(d, "a.png"), os.path.join(d, "b.png")
    Image.fromarray(a).save(p1)
    Image.fromarray(b).save(p2)
    from pf.engine import Session
    s = Session()
    s.execute("doc.focusStack", paths=[p1, p2])
    doc = s.doc
    mid = doc.layers[0].pixels[45, 45, :3]      # only sharp in b
    tl = doc.layers[0].pixels[30, 30, :3]       # only in a (both flat here)
    check("focusStack builds doc", doc.width == 80 and doc.height == 80)
    check("focusStack merges brackets", abs(int(mid[2]) - int(mid[0])) > 20, str(mid))


def test_watermark():
    s = scene()
    n0 = len(s.doc.layers)
    uid = s.execute("image.watermark", text="© PixelForge",
                    corner="bottom-right", opacity=0.5)
    check("watermark adds own layer", len(s.doc.layers) == n0 + 1)
    check("watermark paints pixels",
          (s.doc.layers[-1].pixels[..., 3] > 0).any())
    s.undo()
    check("watermark undo removes layer", len(s.doc.layers) == n0)


# ------------------------------------------------------- recording + actions
def test_recording():
    from pf.engine import Session
    s = Session()
    check("session recording attrs init", s.recording is False and s.record_buffer == [])
    s.execute("doc.new", width=40, height=40, background=(255, 255, 255))
    s.recording = True
    s.execute("filter.run", filter_id="lookVivid")
    s.execute("image.relight", angle=200, strength=0.3)
    s.execute("doc.open", path="assets/sample.png")   # must be skipped
    s.execute("filter.run", filter_id="lookNoir")
    s.recording = False
    check("records only armed steps, doc.open skipped",
          len(s.record_buffer) == 3 and
          all(st["cmd"] != "doc.open" for st in s.record_buffer),
          str([st['cmd'] for st in s.record_buffer]))
    check("step format JSON-able", all(
        set(st) == {"cmd", "params"} and isinstance(st["params"], dict)
        for st in s.record_buffer))
    for st in s.record_buffer:
        s.execute(st["cmd"], **st["params"])
    check("replay applies", True)


def test_actions_module():
    from pf import actions as ACT
    steps = [{"cmd": "image.portraitPro", "params": {"skin": 0.5}},
             {"cmd": "image.watermark", "params": {"text": "t"}}]
    ACT.save_set("__v4test", steps)
    check("save/load round-trip", ACT.load_set("__v4test") == steps)
    check("list_sets includes new", "__v4test" in ACT.list_sets())
    check("describe summarizes", "2 steps" in ACT.describe_set("__v4test"))
    check("NL search hits keyword", ACT.search_score("smooth skin", "__v4test") > 0)
    check("NL search misses garbage", ACT.search_score("zzzqqq", "__v4test") == 0)
    check("NL search empty shows all", ACT.search_score("", "__v4test") == 1)
    from pf.engine import Session
    s = Session()
    s.execute("doc.new", width=50, height=50, background=(255, 255, 255))
    applied, errors = ACT.run_steps(s, steps + [{"cmd": "nope.missing", "params": {}}])
    check("run_steps applies + ignores unknown", applied == 2 and errors == [])
    ACT.delete_set("__v4test")
    check("delete removes set", "__v4test" not in ACT.list_sets())


def test_batch():
    from pf import actions as ACT
    from pf.engine import Session
    d_in, d_out = tempfile.mkdtemp(), tempfile.mkdtemp()
    from PIL import Image
    for i, c in enumerate(((200, 60, 60), (60, 180, 60), (60, 60, 200))):
        Image.new("RGB", (64, 64), c).save(os.path.join(d_in, f"img{i}.jpg"))
    (os.path.join(d_in, "note.txt"), open(os.path.join(d_in, "note.txt"), "w")).close() if False else \
        open(os.path.join(d_in, "note.txt"), "w").close()
    steps = [{"cmd": "filter.run", "params": {"filter_id": "lookVivid"}},
             {"cmd": "image.relight", "params": {"angle": 315, "strength": 0.4}}]
    s = Session()
    outputs, errors = ACT.batch(s, sorted(
        os.path.join(d_in, f) for f in os.listdir(d_in)), steps, d_out, "png")
    check("batch processes all images", len(outputs) == 3 and len(errors) == 0,
          f"{len(outputs)}/{len(errors)}")
    check("batch skips non-images", all("note" not in o for o in outputs))
    src = np.asarray(Image.open(os.path.join(d_in, "img0.jpg")).convert("RGB")).astype(int)
    dst = np.asarray(Image.open(outputs[0]).convert("RGB")).astype(int)
    check("batch really applies steps", abs(dst - src).mean() > 1.0)
    # error path: one corrupt file
    bad = os.path.join(d_in, "bad.png")
    open(bad, "wb").write(b"notapng")
    outputs2, errors2 = ACT.batch(s, [bad], steps, d_out, "png")
    check("batch reports per-file errors", len(outputs2) == 0 and len(errors2) == 1)


# ------------------------------------------------------------- Actions panel
def test_actions_panel():
    ok = True
    try:
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication([])
        from pf.engine import Session
        from ui.panels import ActionsPanel
        s = Session()
        s.execute("doc.new", width=80, height=80, background=(240, 240, 240))
        p = ActionsPanel(s)
        names = [p.list.topLevelItem(i).text(0) for i in range(p.list.topLevelItemCount())]
        check("panel lists preset sets", len(names) >= 4, str(names))
        p.search.setText("product")
        hit = [p.list.topLevelItem(i).text(0) for i in range(p.list.topLevelItemCount())]
        check("panel NL search filters", len(hit) == 1 and "Product" in hit[0], str(hit))
        p.search.setText("")
        # play via signal
        got = []
        p.played.connect(lambda name: got.append(name))
        px = s.doc.layers[0].pixels
        px[20:60, 20:60, :3] = (190, 70, 40)
        px[20:60, 20:60, 3] = 255
        applied, errs = p.play_set("Studio Product")
        check("panel play applies", applied >= 2 and got == ["Studio Product"],
              f"{applied}/{got}")
        # record round-trip (save dialog stubbed — no modal offscreen)
        saved = {}
        p._save_recorded = lambda steps: saved.update(steps=steps)
        p.rec_btn.setChecked(True)
        check("record arms session", s.recording is True and s.record_buffer == [])
        s.execute("filter.run", filter_id="lookNoir")
        s.execute("image.relight", angle=45, strength=0.3)
        p.rec_btn.setChecked(False)
        check("record captures steps", len(saved.get("steps", [])) == 2
              and s.recording is False)
    except Exception as exc:
        ok = False
        print(f"      panel exception: {exc}")
    check("panel runs offscreen", ok)


def test_ui_integration():
    ok = True
    detail = ""
    try:
        from PySide6.QtWidgets import QApplication, QMenu
        app = QApplication.instance() or QApplication([])
        from pf.engine import Session
        from ui.main_window import MainWindow
        w = MainWindow(Session())
        ai = [a for m in w.findChildren(QMenu) if m.title() == "AI Studio"
              for a in m.actions()]
        labels = [a.text().replace("&", "") for a in ai]
        need = ["Product Shot", "Relight", "Restore Old Photo", "Portrait Pro",
                "Find Distractions", "Watermark", "Focus Stack", "Rotate Object"]
        missing = [n for n in need if not any(n in l for l in labels)]
        check("AI Studio gains 8 v4 entries", not missing, str(missing))
        for cmd in ("file.automate.batch", "file.scripts.deleteAllEmptyLayers"):
            act = w._actions.get(cmd)
            check(f"catalog {cmd} live", act is not None and act.isEnabled())
        tabs = [w.dock_history.tabText(i) for i in range(w.dock_history.count())]
        check("Actions tab docked with History", "Actions" in tabs, str(tabs))
    except Exception as exc:
        ok = False
        detail = str(exc)
    check("main window builds with v4", ok, detail)


if __name__ == "__main__":
    print("== PixelForge v4: PS 27.6/27.11 + market pass ==")
    test_layer_cleanup()
    test_rotate_object()
    test_product_shot()
    test_relight()
    test_restore_old()
    test_portrait_pro()
    test_find_distractions()
    test_focus_stack()
    test_watermark()
    test_recording()
    test_actions_module()
    test_batch()
    test_actions_panel()
    test_ui_integration()
    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)
