"""Custom title bar (PhotoCraft's titlebar.rs layout, MIT): brand mark, menus,
document title, workspace controls, and Windows-style min/max/close with the
red hover. Frameless window with drag + edge resizing; opt out with
PIXELFORGE_NATIVE_TITLE=1."""

from __future__ import annotations

import os

from PySide6.QtCore import Qt, QPoint, QRect, Signal
from PySide6.QtGui import QColor, QPainter, QBrush
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QLabel, QToolButton,
                               QMenuBar, QMainWindow)


class BrandMark(QWidget):
    """A small rounded app tile. Our own artwork (PixelForge 'Pf'), drawn in
    the layout position PhotoCraft puts its brand mark."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(24, 24)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        t = T()
        r = self.rect().adjusted(2, 2, -2, -2)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(t.accent))
        p.drawRoundedRect(r, 5, 5)
        p.setPen(QColor(t.accent_text))
        f = p.font()
        f.setPixelSize(11)
        f.setBold(True)
        p.setFont(f)
        p.drawText(r, Qt.AlignCenter, "Pf")
        p.end()


def T():
    from .theme import current
    return current()


class TitleBarButton(QToolButton):
    def __init__(self, kind, parent=None):
        super().__init__(parent)
        self.kind = kind
        self.setFixedSize(44, 28)
        self.setText("")

    def paintEvent(self, ev):
        p = QPainter(self)
        t = T()
        hovered = self.underMouse()
        if self.kind == "close" and hovered:
            p.fillRect(self.rect(), QColor(t.caption_close))
            glyph = t.caption_close_text
        elif hovered:
            p.fillRect(self.rect(), QColor(t.hover))
            glyph = t.text
        else:
            glyph = t.text_dim
        p.setPen(QColor(glyph))
        p.setBrush(Qt.NoBrush)
        cx, cy = self.width() / 2, self.height() / 2
        if self.kind == "min":
            p.drawLine(int(cx - 8), int(cy), int(cx + 8), int(cy))
        elif self.kind == "max":
            p.drawRect(self.rect().adjusted(13, 7, -13, -7).normalized())
        else:
            p.drawLine(int(cx - 6), int(cy - 6), int(cx + 6), int(cy + 6))
            p.drawLine(int(cx + 6), int(cy - 6), int(cx - 6), int(cy + 6))
        p.end()


class TitleBar(QWidget):
    """Brand + (menus inserted by the window) + doc title + window controls."""

    def __init__(self, window: QMainWindow, parent=None):
        super().__init__(parent)
        self.win = window
        self.setFixedHeight(32)
        self._drag = None
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 0, 0, 0)
        lay.setSpacing(6)
        self.brand = BrandMark()
        lay.addWidget(self.brand)
        self.menu_holder = QWidget()
        self._menu_lay = QHBoxLayout(self.menu_holder)
        self._menu_lay.setContentsMargins(0, 0, 0, 0)
        self._menu_lay.setSpacing(0)
        lay.addWidget(self.menu_holder)
        self.title = QLabel("PixelForge")
        self.title.setStyleSheet("color: #a0a0a0; padding-left: 10px;")
        lay.addWidget(self.title, 1)

        self.btn_min = TitleBarButton("min")
        self.btn_max = TitleBarButton("max")
        self.btn_close = TitleBarButton("close")
        for b, slot in ((self.btn_min, self.win.showMinimized),
                        (self.btn_max, self._toggle_max),
                        (self.btn_close, self.win.close)):
            b.clicked.connect(slot)
            lay.addWidget(b)

    def _toggle_max(self):
        if self.win.isMaximized():
            self.win.showNormal()
        else:
            self.win.showMaximized()

    def set_doc_title(self, text):
        self.title.setText(text)
        self.title.setStyleSheet(f"color: {T().text_faint}; padding-left: 10px;")

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton and self.win is not None:
            self._drag = ev.globalPosition().toPoint() - self.win.frameGeometry().topLeft()
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev):
        if self._drag is not None and not self.win.isMaximized():
            self.win.move(ev.globalPosition().toPoint() - self._drag)
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self, ev):
        self._drag = None
        super().mouseReleaseEvent(ev)

    def mouseDoubleClickEvent(self, ev):
        self._toggle_max()


def enable_frameless(win: QMainWindow) -> bool:
    """Frameless + custom chrome + edge resizing. Returns True if applied."""
    if os.environ.get("PIXELFORGE_NATIVE_TITLE") == "1":
        return False
    try:
        from PySide6.QtCore import QEvent
        win.setWindowFlags(Qt.Window | Qt.FramelessWindowHint | Qt.WindowMinMaxButtonsHint)
        win.setWindowFlag(Qt.FramelessWindowHint, True)

        edges = (Qt.LeftEdge, Qt.RightEdge, Qt.TopEdge, Qt.BottomEdge,
                 Qt.TopLeftCorner, Qt.TopRightCorner, Qt.BottomLeftCorner, Qt.BottomRightCorner)
        M = 6

        def edge_at(pos, rect):
            e = 0
            if pos.y() <= M:
                e |= Qt.TopEdge
            if pos.y() >= rect.height() - M:
                e |= Qt.BottomEdge
            if pos.x() <= M:
                e |= Qt.LeftEdge
            if pos.x() >= rect.width() - M:
                e |= Qt.RightEdge
            return e

        orig_press = win.mousePressEvent
        orig_move = win.mouseMoveEvent
        orig_release = win.mouseReleaseEvent
        state = {"edge": 0, "geo": None, "pos": None}

        def press(ev):
            if ev.button() == Qt.LeftButton:
                e = edge_at(ev.position().toPoint(), win.rect())
                if e and not win.isMaximized():
                    state["edge"] = e
                    state["geo"] = win.geometry()
                    state["pos"] = ev.globalPosition().toPoint()
                    ev.accept()
                    return
            orig_press(ev)

        def move(ev):
            if state["edge"] and state["geo"] is not None:
                g = QRect(state["geo"])
                d = ev.globalPosition().toPoint() - state["pos"]
                e = state["edge"]
                if e & Qt.LeftEdge:
                    g.setLeft(min(g.left() + d.x(), g.right() - 200))
                if e & Qt.RightEdge:
                    g.setRight(max(g.right() + d.x(), g.left() + 300))
                if e & Qt.TopEdge:
                    g.setTop(min(g.top() + d.y(), g.bottom() - 150))
                if e & Qt.BottomEdge:
                    g.setBottom(max(g.bottom() + d.y(), g.top() + 200))
                win.setGeometry(g)
                ev.accept()
                return
            if not win.isMaximized():
                e = edge_at(ev.position().toPoint(), win.rect())
                win.setCursor(_cursor_for(e))
            orig_move(ev)

        def release(ev):
            state["edge"] = 0
            orig_release(ev)

        win.mousePressEvent = press
        win.mouseMoveEvent = move
        win.mouseReleaseEvent = release
        return True
    except Exception:
        return False


def _cursor_for(edge):
    if edge in (Qt.LeftEdge, Qt.RightEdge):
        return Qt.SizeHorCursor
    if edge in (Qt.TopEdge, Qt.BottomEdge):
        return Qt.SizeVerCursor
    if edge in (Qt.TopLeftCorner, Qt.BottomRightCorner):
        return Qt.SizeFDiagCursor
    if edge in (Qt.TopRightCorner, Qt.BottomLeftCorner):
        return Qt.SizeBDiagCursor
    return Qt.ArrowCursor
