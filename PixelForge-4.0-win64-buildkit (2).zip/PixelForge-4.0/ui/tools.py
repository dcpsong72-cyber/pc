"""Tools v2: full Photoshop/Canva-style tool set with live previews."""

from __future__ import annotations
import os

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QCursor, QPen, QPainter
from PySide6.QtWidgets import (QWidget, QLabel, QSpinBox, QSlider, QDoubleSpinBox,
                               QToolButton, QHBoxLayout, QVBoxLayout, QComboBox,
                               QPushButton, QFontComboBox, QCheckBox)

TOOL_ORDER = [
    "move", "marquee", "ellipse_marquee", "lasso", "wand",
    "crop", "eyedropper", "brush", "eraser", "bucket", "gradient",
    "clone", "dodge", "blursharpen", "text", "shape", "hand", "zoom",
]
TOOL_LABELS = {
    "move": ("Move", "V"), "marquee": ("Rectangular Marquee", "M"),
    "ellipse_marquee": ("Elliptical Marquee", "Shift+M"),
    "lasso": ("Lasso", "L"), "wand": ("Magic Wand", "W"),
    "crop": ("Crop", "C"), "eyedropper": ("Eyedropper", "I"),
    "brush": ("Brush", "B"), "eraser": ("Eraser", "Shift+E"),
    "bucket": ("Paint Bucket", "Shift+B"), "gradient": ("Gradient", "G"),
    "clone": ("Clone Stamp", "S"), "dodge": ("Dodge/Burn", "Shift+D"),
    "blursharpen": ("Blur / Sharpen", "Shift+R"),
    "text": ("Type", "T"), "shape": ("Shape", "U"),
    "hand": ("Hand", "H"), "zoom": ("Zoom", "Z"),
}
PAINT_TOOLS = {"brush", "eraser", "clone", "dodge", "blursharpen"}
# tools whose Size option matters (brush cursor circle + [ ] resize)
SIZE_TOOLS = {"brush", "eraser", "clone", "pencil", "dodge", "burn", "sponge",
              "blur", "sharpen", "smudge", "heal", "mixer", "patternstamp",
              "historybrush", "bgeraser", "spotheal"}


class Tool:
    id = "none"

    def __init__(self, win):
        self.win = win

    def cursor(self):
        return Qt.ArrowCursor

    def activated(self):
        pass

    def press(self, canvas, doc_pos, event):
        pass

    def move(self, canvas, doc_pos, event):
        pass

    def release(self, canvas, doc_pos, event):
        pass

    def double_click(self, canvas, doc_pos, event):
        pass

    def draw_overlay(self, painter, canvas):
        pass


def _ants_pen(painter, phase):
    white = QPen(QColor(255, 255, 255), 1, Qt.DashLine)
    black = QPen(QColor(0, 0, 0), 1, Qt.DashLine)
    white.setDashOffset(phase)
    black.setDashOffset(phase + 4)
    return black, white


class _RectDragTool(Tool):
    """Base for marquee/ellipse/crop/shape-style drag rectangles."""
    _dragging = False

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        self._anchor = doc_pos
        self._current = doc_pos
        self._dragging = True

    def move(self, canvas, doc_pos, event):
        if self._dragging:
            self._current = doc_pos
            canvas.update()

    def _rect(self):
        x0, y0 = self._anchor
        x1, y1 = self._current
        return (int(min(x0, x1)), int(min(y0, y1)),
                int(round(max(x0, x1))), int(round(max(y0, y1))))

    def draw_overlay(self, painter, canvas):
        if not self._dragging:
            return
        x0, y0, x1, y1 = self._rect()
        a = canvas.doc_to_widget(x0, y0)
        b = canvas.doc_to_widget(x1, y1)
        painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
        painter.setBrush(Qt.NoBrush)
        from PySide6.QtCore import QRectF
        painter.drawRect(QRectF(a, b))


class MoveTool(Tool):
    id = "move"

    def cursor(self):
        return Qt.SizeAllCursor

    def press(self, canvas, doc_pos, event):
        layer = canvas.doc.active if canvas.doc else None
        self._layer = layer
        self._start = doc_pos
        self._orig = (layer.x, layer.y) if layer else None

    def move(self, canvas, doc_pos, event):
        if self._layer is None or self._orig is None:
            return
        self._layer.x = self._orig[0] + int(round(doc_pos[0] - self._start[0]))
        self._layer.y = self._orig[1] + int(round(doc_pos[1] - self._start[1]))
        canvas.update()

    def release(self, canvas, doc_pos, event):
        if self._layer is None or self._orig is None:
            return
        dx = self._layer.x - self._orig[0]
        dy = self._layer.y - self._orig[1]
        if dx or dy:
            uid = self._layer.uid
            ox, oy = self._orig
            def undo(s):
                lay = s.doc.find(uid)
                if lay:
                    lay.x, lay.y = ox, oy
            def redo(s):
                lay = s.doc.find(uid)
                if lay:
                    lay.x, lay.y = ox + dx, oy + dy
            canvas.session.push("Move Layer", undo, redo)
        self._layer = None


class MarqueeTool(_RectDragTool):
    id = "marquee"

    def release(self, canvas, doc_pos, event):
        if not self._dragging:
            return
        self._dragging = False
        x0, y0, x1, y1 = self._rect()
        if x1 - x0 < 2 or y1 - y0 < 2:
            canvas.session.execute("selection.deselect")
        else:
            canvas.session.execute("selection.rect", rect=(x0, y0, x1, y1))


class EllipseMarqueeTool(MarqueeTool):
    id = "ellipse_marquee"

    def release(self, canvas, doc_pos, event):
        if not self._dragging:
            return
        self._dragging = False
        x0, y0, x1, y1 = self._rect()
        if x1 - x0 < 2 or y1 - y0 < 2:
            canvas.session.execute("selection.deselect")
        else:
            canvas.session.execute("selection.ellipse", rect=(x0, y0, x1, y1))


class LassoTool(Tool):
    id = "lasso"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        self._points = [doc_pos]
        canvas.update()

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_points", None):
            self._points.append(doc_pos)
            canvas.update()

    def release(self, canvas, doc_pos, event):
        pts = getattr(self, "_points", None)
        self._points = None
        canvas.update()
        if pts and len(pts) >= 3:
            canvas.session.execute("selection.polygon", points=pts)

    def draw_overlay(self, painter, canvas):
        pts = getattr(self, "_points", None)
        if not pts:
            return
        painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
        for a, b in zip(pts[:-1], pts[1:]):
            painter.drawLine(canvas.doc_to_widget(*a), canvas.doc_to_widget(*b))


class WandTool(Tool):
    id = "wand"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        tol = self.win.options.tolerance_spin.value()
        canvas.session.execute("selection.wand", x=doc_pos[0], y=doc_pos[1], tolerance=tol)


class CropTool(_RectDragTool):
    id = "crop"

    def release(self, canvas, doc_pos, event):
        if not self._dragging:
            return
        self._dragging = False
        x0, y0, x1, y1 = self._rect()
        if x1 - x0 > 4 and y1 - y0 > 4:
            canvas.session.execute("selection.rect", rect=(x0, y0, x1, y1))
            self.win.statusBar().showMessage("Press Enter to crop, Esc to cancel", 5000)
            self.win._pending_crop = True
        canvas.update()


class EyedropperTool(Tool):
    id = "eyedropper"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        r, g, b, a = canvas.composite_pixel(int(doc_pos[0]), int(doc_pos[1]))
        self.win.set_foreground((r, g, b, 255))


class _PaintTool(Tool):
    """Live painting with commit-on-release (dirty rect history)."""
    erase = False
    mode = "paint"

    def press(self, canvas, doc_pos, event):
        layer = canvas.doc.active if canvas.doc else None
        if layer is None or not hasattr(layer, "pixels") or getattr(layer, "pixels", None) is None:
            return
        self._layer = layer
        self._before = layer.pixels.copy()
        self._points = [doc_pos]
        self._dirty = None
        if event.modifiers() & Qt.AltModifier and self.id in ("clone", "heal"):
            self.win._clone_source = (doc_pos[0], doc_pos[1])
            self.win.statusBar().showMessage(f"Source set: {int(doc_pos[0])}, {int(doc_pos[1])}", 3000)
            return
        if self.id == "bgeraser":
            r, g, b, a = canvas.composite_pixel(int(doc_pos[0]), int(doc_pos[1]))
            self._bg_col = (r, g, b, a)
        if self.id == "mixer":
            self._mix_col = list(canvas.foreground)
        self._apply(canvas, [doc_pos])

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_layer", None) is None:
            return
        p_prev = self._points[-1]
        x0, y0 = int(p_prev[0]), int(p_prev[1])
        x1, y1 = int(doc_pos[0]), int(doc_pos[1])
        n = max(abs(x1 - x0), abs(y1 - y0), 1)
        pts = [(x0 + (x1 - x0) * t // n, y0 + (y1 - y0) * t // n) for t in range(1, n + 1)]
        self._points.extend(pts)
        self._apply(canvas, pts)

    def _apply(self, canvas, pts):
        layer = self._layer
        opts = self.win.options
        size = opts.brush_options["size"]
        hard = opts.brush_options["hardness"]
        if self.id == "brush":
            col = list(canvas.foreground)
            if size <= 3:
                col[3] = 255
            res = canvas.session.execute("paint.stroke", points=pts, size=size,
                                         hardness=hard, color=col, uid=layer.uid,
                                         erase=False, record=False)
        elif self.id == "eraser":
            res = canvas.session.execute("paint.stroke", points=pts, size=size,
                                         hardness=hard, color=(0, 0, 0, 255),
                                         uid=layer.uid, erase=True, record=False)
        elif self.id == "clone":
            src = getattr(self.win, "_clone_source", None)
            if src is None:
                self.win.statusBar().showMessage("Alt-click to set clone source first", 3000)
                return
            off = (src[0] - pts[0][0], src[1] - pts[0][1])
            res = canvas.session.execute("paint.clone", points=pts, src_offset=off,
                                         size=size, hardness=hard, uid=layer.uid, record=False)
        elif self.id in ("dodge", "burn"):
            if self.id == "burn":
                mode = "burn"
            else:
                mode = "burn" if opts.dodge_mode.currentText() == "Burn" else "dodge"
            res = canvas.session.execute("paint.dodgeBurn", points=pts, size=size,
                                         mode=mode, exposure=opts.strength_spin.value(),
                                         hardness=hard, uid=layer.uid, record=False)
        elif self.id == "sponge":
            mode = "saturate" if opts.sponge_mode.currentText() == "Saturate" else "desaturate"
            res = canvas.session.execute("paint.sponge", points=pts, size=size,
                                         mode=mode, strength=opts.strength_spin.value(),
                                         hardness=hard, uid=layer.uid, record=False)
        elif self.id in ("blur", "sharpen"):
            res = canvas.session.execute("paint.blurSharpen", points=pts, size=size,
                                         mode=self.id, strength=opts.strength_spin.value(),
                                         hardness=hard, uid=layer.uid, record=False)
        elif self.id == "smudge":
            res = canvas.session.execute("paint.smudge", points=pts, size=size,
                                         strength=opts.strength_spin.value(),
                                         hardness=hard, uid=layer.uid, record=False)
        elif self.id == "pencil":
            col = list(canvas.foreground)
            if size <= 3:
                col[3] = 255
            res = canvas.session.execute("paint.stroke", points=pts, size=size,
                                         hardness=1.0, color=col, uid=layer.uid,
                                         erase=False, record=False)
        elif self.id == "heal":
            srcpt = getattr(self.win, "_clone_source", None)
            if srcpt is None:
                self.win.statusBar().showMessage("Alt-click to set the healing source first", 3000)
                return
            off = (srcpt[0] - pts[0][0], srcpt[1] - pts[0][1])
            res = canvas.session.execute("image.healStroke", points=pts, src_offset=off,
                                         size=size, hardness=hard, uid=layer.uid)
        elif self.id == "mixer":
            if not hasattr(self, "_mix_col"):
                self._mix_col = list(canvas.foreground)
            r, g, b, a = canvas.composite_pixel(int(pts[-1][0]), int(pts[-1][1]))
            k = 0.22
            self._mix_col = [int(self._mix_col[i] * (1 - k) + (r, g, b)[i] * k) for i in range(3)]
            res = canvas.session.execute("paint.stroke", points=pts, size=size,
                                         hardness=hard, color=self._mix_col + [255],
                                         uid=layer.uid, erase=False, record=False)
        elif self.id == "patternstamp":
            res = canvas.session.execute("paint.patternStamp", points=pts, size=size,
                                         pattern=opts.pattern_combo.currentText().lower(),
                                         hardness=hard, uid=layer.uid,
                                         fg=tuple(canvas.foreground),
                                         bg=tuple(getattr(canvas, "background", (255, 255, 255, 255))))
        elif self.id == "historybrush":
            snap = getattr(self.win, "_history_snapshot", None)
            if snap is None:
                self.win.statusBar().showMessage("No history state yet", 3000)
                return
            res = canvas.session.execute("image.historyReveal", points=pts, size=size,
                                         snapshot=snap, hardness=hard, uid=layer.uid)
        elif self.id == "bgeraser":
            col = getattr(self, "_bg_col", None)
            if col is None:
                r, g, b, a = canvas.composite_pixel(int(pts[0][0]), int(pts[0][1]))
                self._bg_col = (r, g, b, a)
            res = canvas.session.execute("paint.bgErase", points=pts, size=size,
                                         color=self._bg_col,
                                         tolerance=opts.tolerance_spin.value(),
                                         hardness=0.9, uid=layer.uid)
        else:
            return
        canvas.update()

    def release(self, canvas, doc_pos, event):
        layer = getattr(self, "_layer", None)
        if layer is None:
            return
        label = {"brush": "Brush Stroke", "eraser": "Eraser", "clone": "Clone Stamp",
                 "dodge": "Dodge", "burn": "Burn", "blur": "Blur", "sharpen": "Sharpen",
                 "smudge": "Smudge", "sponge": "Sponge", "pencil": "Pencil Stroke",
                 "heal": "Healing Brush", "mixer": "Mixer Brush",
                 "patternstamp": "Pattern Stamp", "historybrush": "History Brush",
                 "bgeraser": "Background Eraser"}.get(self.id, "Paint")
        before = self._before
        uid = layer.uid

        def undo(s):
            lay = s.doc.find(uid)
            if lay is not None and isinstance(lay, type(layer)) and hasattr(lay, "pixels"):
                lay.pixels = before

        def redo(s):
            lay = s.doc.find(uid)
            if lay is not None and isinstance(lay, type(layer)) and hasattr(lay, "pixels"):
                lay.pixels = layer.pixels

        canvas.session.push(label, undo, redo)
        self._layer = None


class BrushTool(_PaintTool):
    id = "brush"

    def cursor(self):
        return Qt.BlankCursor


class EraserTool(_PaintTool):
    id = "eraser"

    def cursor(self):
        return Qt.BlankCursor


class CloneTool(_PaintTool):
    id = "clone"

    def cursor(self):
        return Qt.BlankCursor


class DodgeTool(_PaintTool):
    id = "dodge"

    def cursor(self):
        return Qt.BlankCursor


class BlurSharpenTool(_PaintTool):
    id = "blursharpen"

    def cursor(self):
        return Qt.BlankCursor


class BucketTool(Tool):
    id = "bucket"

    def cursor(self):
        return Qt.PointingHandCursor

    def press(self, canvas, doc_pos, event):
        layer = canvas.doc.active if canvas.doc else None
        if layer is None:
            return
        canvas.session.execute("paint.bucket", x=int(doc_pos[0]), y=int(doc_pos[1]),
                               color=canvas.foreground,
                               tolerance=self.win.options.tolerance_spin.value(), uid=layer.uid)


class GradientTool(Tool):
    id = "gradient"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        self._p0 = doc_pos
        self._p1 = doc_pos
        self._dragging = True

    def move(self, canvas, doc_pos, event):
        if self._dragging:
            self._p1 = doc_pos
            canvas.update()

    def release(self, canvas, doc_pos, event):
        if not self._dragging:
            return
        self._dragging = False
        canvas.update()
        layer = canvas.doc.active if canvas.doc else None
        if layer is None:
            return
        o = self.win.options
        canvas.session.execute("paint.gradient", p0=self._p0, p1=self._p1,
                               kind=o.gradient_kind.currentText().lower(),
                               color0=tuple(canvas.foreground[:3]),
                               color1=o.gradient_to_bg.isChecked() and tuple(canvas.background[:3]) or None,
                               transparency=not o.gradient_to_bg.isChecked(), uid=layer.uid)

    def draw_overlay(self, painter, canvas):
        if not getattr(self, "_dragging", False):
            return
        painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
        painter.drawLine(canvas.doc_to_widget(*self._p0), canvas.doc_to_widget(*self._p1))


class TextTool(Tool):
    id = "text"

    def cursor(self):
        return Qt.IBeamCursor

    def press(self, canvas, doc_pos, event):
        self.win.text_dialog(new_at=doc_pos)


class ShapeTool(_RectDragTool):
    id = "shape"
    shape_tid = "shape_rect"
    force_kind = None

    def press(self, canvas, doc_pos, event):
        if self.force_kind:
            self.win.options.shape_kind.setCurrentText(self.force_kind)
        super().press(canvas, doc_pos, event)

    def release(self, canvas, doc_pos, event):
        if not self._dragging:
            return
        self._dragging = False
        canvas.update()
        x0, y0, x1, y1 = self._rect()
        if x1 - x0 < 3 or y1 - y0 < 3:
            return
        o = self.win.options
        canvas.session.execute("layer.newShape", x=x0, y=y0,
                               shape=o.shape_kind.currentText().lower(),
                               w=x1 - x0, h=y1 - y0,
                               fill=list(canvas.foreground),
                               stroke=(20, 20, 20, 255),
                               stroke_w=o.shape_stroke_spin.value(),
                               points=o.shape_points_spin.value())


class RectShapeTool(ShapeTool):
    id = "shape_rect"
    force_kind = "rect"


class EllipseShapeTool(ShapeTool):
    id = "shape_ellipse"
    force_kind = "ellipse"


class TriangleShapeTool(ShapeTool):
    id = "shape_triangle"
    force_kind = "triangle"


class PolygonShapeTool(ShapeTool):
    id = "shape_polygon"
    force_kind = "polygon"


class LineShapeTool(ShapeTool):
    id = "shape_line"
    force_kind = "line"


class CustomShapeTool(ShapeTool):
    id = "shape_custom"
    force_kind = None   # user picks star/arrow/bubble/heart… in the options bar


class HandTool(Tool):
    id = "hand"

    def cursor(self):
        return Qt.OpenHandCursor


class ZoomTool(Tool):
    id = "zoom"

    def cursor(self):
        return Qt.PointingHandCursor

    def press(self, canvas, doc_pos, event):
        if event.modifiers() & Qt.AltModifier:
            canvas.zoom_to(canvas.scale / 1.25, event.position())
        else:
            canvas.zoom_to(canvas.scale * 1.25, event.position())


class PencilTool(_PaintTool):
    id = "pencil"

    def cursor(self):
        return Qt.CrossCursor


class BurnTool(_PaintTool):
    id = "burn"

    def cursor(self):
        return Qt.BlankCursor


class SpongeTool(_PaintTool):
    id = "sponge"

    def cursor(self):
        return Qt.BlankCursor


class BlurTool(_PaintTool):
    id = "blur"

    def cursor(self):
        return Qt.BlankCursor


class SharpenTool(_PaintTool):
    id = "sharpen"

    def cursor(self):
        return Qt.BlankCursor


class SmudgeTool(_PaintTool):
    id = "smudge"

    def cursor(self):
        return Qt.BlankCursor


class MagicEraserTool(Tool):
    """Click: magic-wand the color under the cursor, then clear it on the layer."""

    id = "magiceraser"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        tol = self.win.options.tolerance_spin.value()
        canvas.session.execute("selection.wand", x=doc_pos[0], y=doc_pos[1], tolerance=tol)
        canvas.session.execute("edit.clear")
        canvas.invalidate()


class SpotHealTool(Tool):
    """Brush over a blemish; TELEA inpaint fires on release."""

    id = "spotheal"

    def cursor(self):
        return Qt.BlankCursor

    def press(self, canvas, doc_pos, event):
        self._pts = [doc_pos]
        canvas.update()

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_pts", None):
            self._pts.append(doc_pos)
            canvas.update()

    def release(self, canvas, doc_pos, event):
        pts = getattr(self, "_pts", None)
        self._pts = None
        canvas.update()
        if pts and len(pts) >= 1:
            size = self.win.options.brush_options["size"]
            canvas.session.execute("image.spotHeal", points=pts, size=size)
            canvas.invalidate()

    def draw_overlay(self, painter, canvas):
        pts = getattr(self, "_pts", None)
        if not pts:
            return
        painter.setPen(QPen(QColor(120, 200, 255), 1))
        r = self.win.options.brush_options["size"] / 2
        for (x, y) in pts[::4]:
            wx, wy = canvas.doc_to_widget(x, y)
            painter.drawEllipse(wx - r * canvas.scale, wy - r * canvas.scale,
                                2 * r * canvas.scale, 2 * r * canvas.scale)


class RedEyeTool(Tool):
    id = "redeye"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        size = self.win.options.brush_options["size"]
        canvas.session.execute("image.redEye", x=doc_pos[0], y=doc_pos[1],
                               radius=max(6, size // 2))
        canvas.invalidate()


class PolygonLassoTool(Tool):
    """Click to place vertices; click near the first point (or press Enter) to close."""

    id = "lasso_poly"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        pts = getattr(self, "_points", None)
        if pts:
            d = ((doc_pos[0] - pts[0][0]) ** 2 + (doc_pos[1] - pts[0][1]) ** 2) ** 0.5
            if len(pts) >= 3 and d < 10 / max(canvas.scale, 0.01):
                self._commit(canvas)
                return
        self._points = (pts or []) + [doc_pos]
        canvas.update()

    def _commit(self, canvas):
        pts = getattr(self, "_points", None)
        self._points = None
        canvas.update()
        if pts and len(pts) >= 3:
            canvas.session.execute("selection.polygon", points=pts)

    def move(self, canvas, doc_pos, event):
        self._cursor_doc = doc_pos
        if getattr(self, "_points", None):
            canvas.update()

    def draw_overlay(self, painter, canvas):
        pts = getattr(self, "_points", None)
        if not pts:
            return
        painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
        painter.drawPolyline([canvas.doc_to_widget(*p) for p in pts])
        wpts = [canvas.doc_to_widget(*p) for p in pts]
        if len(wpts) >= 1:
            cur = getattr(self, "_cursor_doc", None)
            if cur:
                cw = canvas.doc_to_widget(*cur)
                painter.drawLine(wpts[-1], cw)
            painter.drawEllipse(wpts[0], 5, 5)

    def key(self, canvas, ev):
        if ev.key() == Qt.Key_Return and getattr(self, "_points", None):
            self._commit(canvas)


class RulerTool(Tool):
    """Drag to measure distance and angle (readout in the status bar)."""

    id = "ruler"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        self._a = doc_pos
        self._b = doc_pos
        canvas.update()

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_a", None):
            self._b = doc_pos
            dx = self._b[0] - self._a[0]
            dy = self._b[1] - self._a[1]
            import math
            d = math.hypot(dx, dy)
            ang = math.degrees(math.atan2(-dy, dx))
            self.win.statusBar().showMessage(
                f"Ruler: {d:.1f} px   Δx {dx:.0f}  Δy {dy:.0f}   {ang:.1f}°", 0)
            canvas.update()

    def release(self, canvas, doc_pos, event):
        pass

    def draw_overlay(self, painter, canvas):
        if getattr(self, "_a", None) and getattr(self, "_b", None):
            painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
            a = canvas.doc_to_widget(*self._a)
            b = canvas.doc_to_widget(*self._b)
            painter.drawLine(a, b)
            painter.drawEllipse(a, 3, 3)
            painter.drawEllipse(b, 3, 3)

class HealingBrushTool(_PaintTool):
    id = "heal"

    def cursor(self):
        return Qt.BlankCursor


class MixerBrushTool(_PaintTool):
    id = "mixer"

    def cursor(self):
        return Qt.BlankCursor


class PatternStampTool(_PaintTool):
    id = "patternstamp"

    def cursor(self):
        return Qt.BlankCursor


class HistoryBrushTool(_PaintTool):
    id = "historybrush"

    def cursor(self):
        return Qt.BlankCursor


class BackgroundEraserTool(_PaintTool):
    id = "bgeraser"

    def cursor(self):
        return Qt.BlankCursor


class QuickSelectionTool(Tool):
    """Drag across the subject; the union of color blobs becomes the selection."""

    id = "quicksel"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        self._points = [doc_pos]
        canvas.update()

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_points", None):
            self._points.append(doc_pos)
            canvas.update()

    def release(self, canvas, doc_pos, event):
        pts = getattr(self, "_points", None)
        self._points = None
        canvas.update()
        if pts and len(pts) >= 1:
            canvas.session.execute("selection.quick", points=pts,
                                   tolerance=self.win.options.tolerance_spin.value())

    def draw_overlay(self, painter, canvas):
        pts = getattr(self, "_points", None)
        if not pts:
            return
        painter.setPen(QPen(QColor(120, 200, 255), 1, Qt.DashLine))
        r = self.win.options.brush_options["size"] / 2 * canvas.scale
        for (x, y) in pts[::4]:
            wx, wy = canvas.doc_to_widget(x, y)
            painter.drawEllipse(wx - r, wy - r, 2 * r, 2 * r)


class ObjectSelectionTool(_RectDragTool):
    id = "objsel"

    def release(self, canvas, doc_pos, event):
        if not self._dragging:
            return
        self._dragging = False
        rect = self._rect()
        canvas.update()
        if rect[2] - rect[0] >= 8 and rect[3] - rect[1] >= 8:
            canvas.session.execute("selection.objectRect", rect=rect)


class MagneticLassoTool(Tool):
    """Freehand lasso whose points snap to the strongest nearby image edge."""

    id = "lasso_magnetic"

    def cursor(self):
        return Qt.CrossCursor

    def _edge_map(self, canvas):
        if getattr(self, "_edges", None) is not None:
            return self._edges
        comp = canvas.composite()
        if comp is None:
            self._edges = None
            return None
        import cv2
        gray = cv2.cvtColor(comp[..., :3], cv2.COLOR_RGB2GRAY)
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
        self._edges = np.sqrt(gx * gx + gy * gy)
        return self._edges

    def _snap(self, canvas, x, y, radius=4):
        edges = self._edge_map(canvas)
        if edges is None:
            return x, y
        h, w = edges.shape[:2]
        best, bx, by = -1.0, x, y
        xi, yi = int(x), int(y)
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                xx, yy = xi + dx, yi + dy
                if 0 <= xx < w and 0 <= yy < h:
                    e = float(edges[yy, xx])
                    if e > best:
                        best, bx, by = e, float(xx), float(yy)
        return bx, by

    def press(self, canvas, doc_pos, event):
        self._points = [self._snap(canvas, *doc_pos)]
        canvas.update()

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_points", None):
            p = self._snap(canvas, *doc_pos)
            if p != self._points[-1]:
                self._points.append(p)
            canvas.update()

    def release(self, canvas, doc_pos, event):
        pts = getattr(self, "_points", None)
        self._points = None
        self._edges = None
        canvas.update()
        if pts and len(pts) >= 3:
            canvas.session.execute("selection.polygon", points=pts)

    def draw_overlay(self, painter, canvas):
        pts = getattr(self, "_points", None)
        if not pts:
            return
        painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DashLine))
        for a, b in zip(pts[:-1], pts[1:]):
            painter.drawLine(canvas.doc_to_widget(*a), canvas.doc_to_widget(*b))


class SliceTool(Tool):
    """Drag slice rectangles; Enter exports every slice as a PNG."""

    id = "slice"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        self._anchor = doc_pos
        self._current = doc_pos
        self._dragging = True

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_dragging", False):
            self._current = doc_pos
            canvas.update()

    def release(self, canvas, doc_pos, event):
        if not getattr(self, "_dragging", False):
            return
        self._dragging = False
        canvas.update()
        x0, y0 = self._anchor
        x1, y1 = self._current
        if abs(x1 - x0) < 8 or abs(y1 - y0) < 8:
            return
        self.win.slices.append((int(min(x0, x1)), int(min(y0, y1)),
                                int(max(x0, x1)), int(max(y0, y1))))
        self.win.statusBar().showMessage(f"Slice {len(self.win.slices)} added — Enter exports all", 4000)

    def key(self, canvas, ev):
        if ev.key() in (Qt.Key_Return, Qt.Key_Enter) and self.win.slices:
            self._export(canvas)

    def _export(self, canvas):
        import cv2
        from pf import compose as _c
        comp = _c.composite_rgba8(canvas.doc)
        from PySide6.QtWidgets import QFileDialog
        out_dir = QFileDialog.getExistingDirectory(self.win, "Export slices to…")
        if not out_dir:
            return
        for i, (x0, y0, x1, y1) in enumerate(self.win.slices, 1):
            x0, y0 = max(0, x0), max(0, y0)
            x1, y1 = min(comp.shape[1], x1), min(comp.shape[0], y1)
            cv2.imwrite(os.path.join(out_dir, f"slice_{i:02d}.png"),
                        cv2.cvtColor(comp[y0:y1, x0:x1], cv2.COLOR_RGB2BGR))
        self.win.statusBar().showMessage(f"Exported {len(self.win.slices)} slice(s)", 5000)

    def draw_overlay(self, painter, canvas):
        for i, (x0, y0, x1, y1) in enumerate(self.win.slices, 1):
            a = canvas.doc_to_widget(x0, y0)
            b = canvas.doc_to_widget(x1, y1)
            painter.setPen(QPen(QColor(255, 200, 0), 1, Qt.DashLine))
            painter.drawRect(a.x(), a.y(), b.x() - a.x(), b.y() - a.y())
            painter.setPen(QPen(QColor(255, 200, 0)))
            painter.drawText(a.x() + 3, a.y() + 12, str(i))
        if getattr(self, "_dragging", False):
            a = canvas.doc_to_widget(*self._anchor)
            b = canvas.doc_to_widget(*self._current)
            painter.setPen(QPen(QColor(255, 200, 0, 160), 1, Qt.DashLine))
            painter.drawRect(a.x(), a.y(), b.x() - a.x(), b.y() - a.y())


class SliceSelectTool(Tool):
    """Click a slice to select it; Del removes it; drag moves it."""

    id = "sliceselect"

    def cursor(self):
        return Qt.ArrowCursor

    def _hit(self, canvas, p):
        for i, (x0, y0, x1, y1) in enumerate(self.win.slices):
            if x0 <= p[0] <= x1 and y0 <= p[1] <= y1:
                return i
        return None

    def press(self, canvas, doc_pos, event):
        self.win._active_slice = self._hit(canvas, doc_pos)
        self._last = doc_pos
        if self.win._active_slice is None:
            self.win.statusBar().showMessage("No slice here — use the Slice tool to add", 3000)
        canvas.update()

    def move(self, canvas, doc_pos, event):
        i = getattr(self.win, "_active_slice", None)
        if i is None or getattr(self, "_last", None) is None:
            return
        dx, dy = int(doc_pos[0] - self._last[0]), int(doc_pos[1] - self._last[1])
        x0, y0, x1, y1 = self.win.slices[i]
        self.win.slices[i] = (x0 + dx, y0 + dy, x1 + dx, y1 + dy)
        self._last = doc_pos
        canvas.update()

    def key(self, canvas, ev):
        i = getattr(self.win, "_active_slice", None)
        if ev.key() == Qt.Key_Delete and i is not None:
            self.win.slices.pop(i)
            self.win._active_slice = None
            canvas.update()

    def draw_overlay(self, painter, canvas):
        for i, (x0, y0, x1, y1) in enumerate(self.win.slices, 1):
            a = canvas.doc_to_widget(x0, y0)
            b = canvas.doc_to_widget(x1, y1)
            active = getattr(self.win, "_active_slice", None) == i - 1
            painter.setPen(QPen(QColor(80, 180, 255) if active else QColor(255, 200, 0),
                                2 if active else 1, Qt.DashLine))
            painter.drawRect(a.x(), a.y(), b.x() - a.x(), b.y() - a.y())


class NoteTool(Tool):
    """Click to pin a note; Del removes the nearest one."""

    id = "note"

    def cursor(self):
        return Qt.IBeamCursor

    def press(self, canvas, doc_pos, event):
        from PySide6.QtWidgets import QInputDialog
        text, ok = QInputDialog.getMultiLineText(self.win, "Sticky Note", "Note:")
        if ok and text.strip():
            self.win.notes.append({"x": int(doc_pos[0]), "y": int(doc_pos[1]),
                                   "text": text.strip()})
        canvas.update()

    def key(self, canvas, ev):
        if ev.key() == Qt.Key_Delete and self.win.notes:
            self.win.notes.pop()
            canvas.update()

    def draw_overlay(self, painter, canvas):
        for n in self.win.notes:
            p = canvas.doc_to_widget(n["x"], n["y"])
            painter.setPen(QPen(QColor(255, 220, 90)))
            painter.setBrush(QColor(255, 220, 90, 230))
            painter.drawRect(p.x(), p.y(), 14, 14)
            painter.setPen(QPen(QColor(60, 40, 0)))
            painter.drawText(p.x() + 2, p.y() + 11, "n")
            painter.setPen(QPen(QColor(255, 255, 255, 200)))
            painter.drawText(p.x() + 18, p.y() + 11, n["text"].splitlines()[0][:40])


class CountTool(Tool):
    """Click to drop counters; right-click clears them all."""

    id = "count"
    handles_right = True

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        if event.button() == Qt.RightButton:
            self.win.counts.clear()
        else:
            self.win.counts.append({"x": int(doc_pos[0]), "y": int(doc_pos[1]),
                                    "n": len(self.win.counts) + 1})
        self.win.statusBar().showMessage(f"Count: {len(self.win.counts)}", 4000)
        canvas.update()

    def draw_overlay(self, painter, canvas):
        painter.setPen(QPen(QColor(255, 90, 90)))
        painter.setBrush(QColor(255, 90, 90, 220))
        f = painter.font()
        for c in self.win.counts:
            p = canvas.doc_to_widget(c["x"], c["y"])
            painter.drawEllipse(p.x() - 8, p.y() - 8, 16, 16)
            painter.setPen(QPen(QColor("white")))
            painter.drawText(p.x() - 4, p.y() + 4, str(c["n"]))
            painter.setPen(QPen(QColor(255, 90, 90)))


class PatchTool(Tool):
    """Make a selection (lasso/wand), then click — it heals the region."""

    id = "patch"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        doc = canvas.doc
        if doc is None or doc.selection is None:
            self.win.statusBar().showMessage("Make a selection first (Lasso/Wand), then click to patch", 4000)
            return
        canvas.session.execute("image.patchHeal")
        canvas.invalidate()
        self.win.statusBar().showMessage("Patched", 2000)


class ContentAwareMoveTool(Tool):
    """With a selection: drag to move the content — the hole heals itself."""

    id = "camove"

    def cursor(self):
        return Qt.SizeAllCursor

    def press(self, canvas, doc_pos, event):
        doc = canvas.doc
        if doc is None or doc.selection is None:
            self.win.statusBar().showMessage("Select something first, then drag to move it", 4000)
            self._start = None
            return
        self._start = doc_pos

    def release(self, canvas, doc_pos, event):
        start = getattr(self, "_start", None)
        self._start = None
        if start is None:
            return
        dx, dy = doc_pos[0] - start[0], doc_pos[1] - start[1]
        if abs(dx) < 2 and abs(dy) < 2:
            return
        canvas.session.execute("image.contentAwareMove", dx=dx, dy=dy)
        canvas.invalidate()


class RotateViewTool(Tool):
    """Drag to rotate the view (non-destructive); click resets to 0°."""

    id = "rotateview"

    def cursor(self):
        return Qt.OpenHandCursor

    def press(self, canvas, doc_pos, event):
        self._x0 = event.position().x()
        self._rot0 = canvas.rotation
        self._moved = False

    def move(self, canvas, doc_pos, event):
        if getattr(self, "_x0", None) is None:
            return
        d = event.position().x() - self._x0
        if abs(d) > 2:
            self._moved = True
        canvas.rotation = (self._rot0 + d * 0.5) % 360
        canvas.update()

    def release(self, canvas, doc_pos, event):
        if getattr(self, "_x0", None) is None:
            return
        if not getattr(self, "_moved", False):
            canvas.rotation = 0.0
            self.win.statusBar().showMessage("View rotation reset", 2000)
        self._x0 = None
        canvas.update()


class PenTool(Tool):
    """Click to place anchor points; Enter/Close ends the path (Paths panel)."""

    id = "pen"

    def cursor(self):
        return Qt.CrossCursor

    def press(self, canvas, doc_pos, event):
        win = self.win
        win.pen_work = getattr(win, "pen_work", None) or []
        win.pen_work.append([float(doc_pos[0]), float(doc_pos[1])])
        canvas.update()

    def move(self, canvas, doc_pos, event):
        self._cursor_doc = list(doc_pos)
        canvas.update()

    def key(self, canvas, ev):
        win = self.win
        if ev.key() in (Qt.Key_Return, Qt.Key_Enter) and getattr(win, "pen_work", None):
            win.finish_pen_path()
        elif ev.key() == Qt.Key_Escape and getattr(win, "pen_work", None):
            win.pen_work = None
            canvas.update()

    def draw_overlay(self, painter, canvas):
        win = self.win
        pts = getattr(win, "pen_work", None)
        if not pts:
            return
        painter.setPen(QPen(QColor(80, 180, 255), 1))
        for i in range(len(pts) - 1):
            a = canvas.doc_to_widget(*pts[i])
            b = canvas.doc_to_widget(*pts[i + 1])
            painter.drawLine(a, b)
        if getattr(self, "_cursor_doc", None):
            a = canvas.doc_to_widget(*pts[-1])
            b = canvas.doc_to_widget(*self._cursor_doc)
            painter.setPen(QPen(QColor(80, 180, 255, 120), 1))
            painter.drawLine(a, b)
        for p in pts:
            w = canvas.doc_to_widget(*p)
            painter.setBrush(QColor("white"))
            painter.setPen(QPen(QColor(80, 180, 255)))
            painter.drawRect(w.x() - 2, w.y() - 2, 4, 4)


class PathSelectionTool(Tool):
    """Drag a path to move it (works on the active path in Paths panel)."""

    id = "pathsel"

    def cursor(self):
        return Qt.ArrowCursor

    def press(self, canvas, doc_pos, event):
        win = self.win
        self._last = doc_pos
        if win.paths:
            self.win.statusBar().showMessage(
                f"Dragging “{win.paths[win._active_path]['name']}”", 2000)

    def move(self, canvas, doc_pos, event):
        win = self.win
        if not win.paths or getattr(self, "_last", None) is None:
            return
        dx, dy = doc_pos[0] - self._last[0], doc_pos[1] - self._last[1]
        self._last = doc_pos
        for p in win.paths[win._active_path]["points"]:
            p[0] += dx
            p[1] += dy
        canvas.update()

    def release(self, canvas, doc_pos, event):
        self._last = None


class DirectSelectionTool(Tool):
    """Drag a single anchor point of the active path."""

    id = "directsel"

    def cursor(self):
        return Qt.ArrowCursor

    def _nearest(self, canvas, p):
        win = self.win
        if not win.paths:
            return None
        best, bi = 10.0 / max(canvas.scale, 0.01), None
        for i, pt in enumerate(win.paths[win._active_path]["points"]):
            d = ((pt[0] - p[0]) ** 2 + (pt[1] - p[1]) ** 2) ** 0.5
            if d < best:
                best, bi = d, i
        return bi

    def press(self, canvas, doc_pos, event):
        self._vi = self._nearest(canvas, doc_pos)
        if self._vi is None:
            self.win.statusBar().showMessage("No anchor nearby (select a path first)", 2500)

    def move(self, canvas, doc_pos, event):
        win = self.win
        if getattr(self, "_vi", None) is None or not win.paths:
            return
        pt = win.paths[win._active_path]["points"][self._vi]
        pt[0], pt[1] = float(doc_pos[0]), float(doc_pos[1])
        canvas.update()

    def release(self, canvas, doc_pos, event):
        self._vi = None


class VerticalTypeTool(TextTool):
    """Stacks each character on its own line (simple vertical type)."""

    id = "text_vert"

    def press(self, canvas, doc_pos, event):
        self._at = doc_pos
        self.win.text_dialog(new_at=doc_pos, vertical=True)



TOOL_CLASSES = [MoveTool, MarqueeTool, EllipseMarqueeTool, LassoTool, PolygonLassoTool,
                MagneticLassoTool, ObjectSelectionTool, QuickSelectionTool, WandTool,
                CropTool, SliceTool, SliceSelectTool, EyedropperTool, RulerTool,
                NoteTool, CountTool, SpotHealTool, HealingBrushTool, PatchTool,
                ContentAwareMoveTool, RedEyeTool, BrushTool, PencilTool, MixerBrushTool,
                CloneTool, PatternStampTool, HistoryBrushTool, EraserTool,
                BackgroundEraserTool, MagicEraserTool, GradientTool, BucketTool,
                BlurTool, SharpenTool, SmudgeTool, DodgeTool, BurnTool, SpongeTool,
                PenTool, TextTool, VerticalTypeTool, PathSelectionTool,
                DirectSelectionTool, RectShapeTool, EllipseShapeTool,
                TriangleShapeTool, PolygonShapeTool, LineShapeTool, CustomShapeTool,
                HandTool, RotateViewTool, ZoomTool]

TOOL_ICONS = {
    "move": "✥", "marquee": "▯", "ellipse_marquee": "◯", "lasso": "⟅", "wand": "✦",
    "crop": "⌗", "eyedropper": "◔", "brush": "🖌", "eraser": "▨", "bucket": "🪣",
    "gradient": "_gradient", "clone": "⧉", "dodge": "☀", "blursharpen": "❄",
    "text": "T", "shape": "◼", "hand": "✋", "zoom": "🔍",
}


# ------------------------------------------------------------------ widgets
class ToolPalette(QWidget):
    tool_changed = None  # set by MainWindow

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(40)
        self.buttons = {}
        self._current = "brush"
        layout = QVBoxLayout(self)
        layout.setContentsMargins(3, 6, 3, 6)
        layout.setSpacing(1)
        for tid in TOOL_ORDER:
            btn = QToolButton(self)
            label, shortcut = TOOL_LABELS[tid]
            icon = TOOL_ICONS.get(tid, tid[0])
            btn.setText("▓" if icon == "_gradient" else icon)
            btn.setToolTip(f"{label} ({shortcut})")
            btn.setCheckable(True)
            btn.setFixedSize(32, 30)
            btn.clicked.connect(lambda _=False, t=tid: self.set_tool(t, from_user=True))
            layout.addWidget(btn)
            self.buttons[tid] = btn
        layout.addStretch(1)
        self.buttons["brush"].setChecked(True)

    def set_tool(self, tid, from_user=False):
        if tid not in self.buttons:
            return
        self._current = tid
        for t, btn in self.buttons.items():
            btn.setChecked(t == tid)
        if from_user and self.tool_changed:
            self.tool_changed(tid)

    @property
    def current(self):
        return self._current


class OptionsBar(QWidget):
    """Context-sensitive options: brush section, tolerance, shape, gradient, strength."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(36)
        self.brush_options = {"size": 18, "hardness": 0.85}
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 2, 8, 2)
        lay.setSpacing(6)

        def lbl(t):
            l = QLabel(t)
            return l

        # brush section
        self.brush_widgets = []
        w = lbl("Size:"); self.brush_widgets.append(w); lay.addWidget(w)
        self.size_spin = QSpinBox(); self.size_spin.setRange(1, 800); self.size_spin.setValue(18)
        self.brush_widgets.append(self.size_spin); lay.addWidget(self.size_spin)
        w = lbl("Hardness:"); self.brush_widgets.append(w); lay.addWidget(w)
        self.hard_spin = QDoubleSpinBox(); self.hard_spin.setRange(0, 1); self.hard_spin.setSingleStep(0.05); self.hard_spin.setValue(0.85)
        self.brush_widgets.append(self.hard_spin); lay.addWidget(self.hard_spin)
        self.size_spin.valueChanged.connect(self._sync)
        self.hard_spin.valueChanged.connect(self._sync)

        # tolerance (wand/bucket)
        self.tol_widgets = []
        w = lbl("Tolerance:"); self.tol_widgets.append(w); lay.addWidget(w)
        self.tolerance_spin = QSpinBox(); self.tolerance_spin.setRange(0, 255); self.tolerance_spin.setValue(32)
        self.tol_widgets.append(self.tolerance_spin); lay.addWidget(self.tolerance_spin)

        # strength (dodge/blur)
        self.strength_widgets = []
        w = lbl("Strength:"); self.strength_widgets.append(w); lay.addWidget(w)
        self.strength_spin = QDoubleSpinBox(); self.strength_spin.setRange(0.02, 1.0); self.strength_spin.setSingleStep(0.05); self.strength_spin.setValue(0.3)
        self.strength_widgets.append(self.strength_spin); lay.addWidget(self.strength_spin)
        self.dodge_mode = QComboBox(); self.dodge_mode.addItems(["Dodge", "Burn"])
        self.sponge_mode = QComboBox(); self.sponge_mode.addItems(["Desaturate", "Saturate"])
        self.strength_widgets += [self.dodge_mode, self.sponge_mode]
        lay.addWidget(self.dodge_mode)
        lay.addWidget(self.sponge_mode)

        # shape section
        self.shape_widgets = []
        w = lbl("Shape:"); self.shape_widgets.append(w); lay.addWidget(w)
        self.shape_kind = QComboBox()
        self.shape_kind.addItems(["rect", "roundrect", "ellipse", "triangle", "polygon", "star", "arrow", "bubble", "heart", "line"])
        self.shape_widgets.append(self.shape_kind); lay.addWidget(self.shape_kind)
        w = lbl("Stroke:"); self.shape_widgets.append(w); lay.addWidget(w)
        self.shape_stroke_spin = QSpinBox(); self.shape_stroke_spin.setRange(0, 60); self.shape_stroke_spin.setValue(0)
        self.shape_widgets.append(self.shape_stroke_spin); lay.addWidget(self.shape_stroke_spin)
        w = lbl("Points:"); self.shape_widgets.append(w); lay.addWidget(w)
        self.shape_points_spin = QSpinBox(); self.shape_points_spin.setRange(3, 12); self.shape_points_spin.setValue(5)
        self.shape_widgets.append(self.shape_points_spin); lay.addWidget(self.shape_points_spin)

        # pattern section (Pattern Stamp)
        self.pattern_widgets = []
        w = lbl("Pattern:"); self.pattern_widgets.append(w); lay.addWidget(w)
        self.pattern_combo = QComboBox()
        self.pattern_combo.addItems(["Checker", "Dots", "Diagonal"])
        self.pattern_widgets.append(self.pattern_combo); lay.addWidget(self.pattern_combo)

        # gradient section
        self.gradient_widgets = []
        self.gradient_kind = QComboBox(); self.gradient_kind.addItems(["Linear", "Radial"])
        self.gradient_widgets.append(self.gradient_kind); lay.addWidget(self.gradient_kind)
        self.gradient_to_bg = QCheckBox("FG→BG"); self.gradient_to_bg.setChecked(True)
        self.gradient_widgets.append(self.gradient_to_bg); lay.addWidget(self.gradient_to_bg)

        lay.addStretch(1)
        self.hint = QLabel("")
        self.hint.setObjectName("optionsLabel")
        lay.addWidget(self.hint)

        self._sync()

    def _sync(self, *_):
        self.brush_options["size"] = self.size_spin.value()
        self.brush_options["hardness"] = float(self.hard_spin.value())

    def show_sections(self, tid):
        paintish = PAINT_TOOLS | {"pencil", "blur", "sharpen", "smudge", "burn",
                                  "sponge", "spotheal", "redeye"}
        self.brush_widgets and [w.setVisible(tid in paintish) for w in self.brush_widgets]
        for w in self.tol_widgets:
            w.setVisible(tid in ("wand", "bucket", "magiceraser"))
        shape_tids = ("shape", "shape_rect", "shape_ellipse", "shape_triangle",
                      "shape_polygon", "shape_line", "shape_custom")
        for w in self.shape_widgets:
            w.setVisible(tid in shape_tids)
        for w in self.gradient_widgets:
            w.setVisible(tid == "gradient")
        for w in self.pattern_widgets:
            w.setVisible(tid == "patternstamp")
        for w in self.strength_widgets:
            if w is self.dodge_mode:
                w.setVisible(tid == "dodge")
            elif w is self.sponge_mode:
                w.setVisible(tid == "sponge")
            else:
                w.setVisible(tid in ("dodge", "burn", "sponge", "blur", "sharpen", "smudge"))

    def set_hint(self, text):
        self.hint.setText(text)
