"""L6 — main window v3: PhotoCraft's exact chrome (MIT), our features inside.

- Frameless title bar: brand mark, embedded menus, doc title, min/max/close
- The complete 766-entry Photoshop menu tree from their menu_catalog.rs
  (live where we implement the command, disabled otherwise — their model)
- The Photoshop toolbox with group flyouts and fg/bg chips
- Options bar with colon labels, doc tabs "name @ 12.5% (RGB/8)", status bar
- Dock column: Color|Swatches · Adjustments|Properties · Layers|Channels|Paths
"""

from __future__ import annotations

import json
import os
import tempfile

import numpy as np
from PySide6.QtCore import Qt, QSettings, QTimer
from PySide6.QtGui import QAction, QActionGroup, QKeySequence, QColor, QPixmap
from PySide6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
                               QLabel, QSplitter, QDialog, QLineEdit, QPushButton,
                               QDoubleSpinBox, QFormLayout, QInputDialog, QMenu, QMenuBar,
                               QTabWidget, QApplication, QMessageBox, QToolButton,
                               QColorDialog, QListWidget, QComboBox, QSpinBox,
                               QSlider, QCheckBox)

from pf import color as C, compose, psdio
from pf.bridge import PhotoCraftBridge, EngineError
from pf.doc import (ADJUSTMENT_KINDS, DEFAULT_ADJ_PARAMS, AdjustmentLayer,
                    PixelLayer, ShapeLayer, TextLayer)
from . import icons
from .theme import apply_theme, current as T, THEMES, THEME_LABELS, set_theme, qss
from .canvas import CanvasWidget
from .panels import (LayersPanel, HistoryPanel, ColorPanel, AdjustmentsPanel,
                     BrandPanel, ChannelsPanel, PathsPanel, ActionsPanel)
from .toolbar import Toolbox, ENABLED_TOOLS
from .tools import (OptionsBar, Tool, MoveTool, MarqueeTool, EllipseMarqueeTool,
                    LassoTool, WandTool, CropTool, EyedropperTool, BrushTool,
                    EraserTool, BucketTool, GradientTool, CloneTool, DodgeTool,
                    BlurSharpenTool, TextTool, ShapeTool, HandTool, ZoomTool)
from .dialogs import (TemplateDialog, FilterGalleryDialog, LayerStyleDialog,
                      TextDialog, CollageDialog, ResizeDialog)
from .titlebar import TitleBar, enable_frameless
from .menu_catalog import CATALOG
from .ids import FILTER_MAP, IMAGE_ADJ_DIRECT, IMAGE_ADJ_LIVE, EXTRA_FILTERS
from pf import actions as pf_actions

FILE_FILTERS = "All supported (*.png *.jpg *.jpeg *.bmp *.webp *.tif *.tiff *.psd);;" \
               "Photoshop (*.psd);;PNG (*.png);;JPEG (*.jpg *.jpeg);;All files (*)"

TOOL_KEYS = {"v": "move", "m": "marquee", "l": "lasso", "w": "wand", "c": "crop",
             "i": "eyedropper", "b": "brush", "e": "eraser", "g": "gradient",
             "s": "clone", "o": "dodge", "t": "text", "u": "shape", "h": "hand", "z": "zoom"}


class MainWindow(QMainWindow):
    def __init__(self, session):
        super().__init__()
        self.session = session
        self.settings = QSettings("PixelForge", "PixelForge")
        self.bridge = PhotoCraftBridge()
        self._tools = {}
        self._pending_crop = False
        self._clone_source = None
        self._pf_fonts_cache = None
        self._zoom_pct = 100
        # tool-side vector state (paths, slices, notes, counters)
        self.paths = []
        self._active_path = 0
        self.paths_changed = []
        self.pen_work = None
        self.slices = []
        self._active_slice = None
        self.notes = []
        self.counts = []
        self._history_snapshot = None
        self._hist_doc_id = None

        enable_frameless(self)
        self.setWindowTitle("PixelForge")
        self.resize(1500, 940)

        self._build_tools()
        self._build_widgets()
        self._build_menus()
        self._wire_session()

        self.set_tool("brush")
        self.statusBar().showMessage("PixelForge 4.0", 5000)

    # ------------------------------------------------------------- widgets
    def _build_widgets(self):
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # --- title bar (brand, menus go here, doc title, window controls)
        self.titlebar = TitleBar(self)
        root.addWidget(self.titlebar)

        # --- body: toolbox | (options, doc tabs, canvas) | dock column
        body = QWidget()
        bl = QHBoxLayout(body)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(0)

        self.toolbox = Toolbox()
        self.toolbox.tool_changed.connect(self._toolbox_signal)
        bl.addWidget(self.toolbox)

        mid = QWidget()
        ml = QVBoxLayout(mid)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.setSpacing(0)
        self.options = OptionsBar()
        ml.addWidget(self.options)
        self.doc_tabs = DocTabs(self)
        ml.addWidget(self.doc_tabs)
        self.canvas = CanvasWidget(self.session)
        ml.addWidget(self.canvas, 1)
        bl.addWidget(mid, 1)

        self._build_docks(bl)
        root.addWidget(body, 1)
        self.setCentralWidget(central)
        self.menuBar().hide()  # menus live in the title bar

        # status bar: zoom | position | message
        sb = self.statusBar()
        self.zoom_label = QLabel("100%")
        self.zoom_label.setToolTip("Zoom — click to fit on screen")
        self.pos_label = QLabel("0, 0 px")
        self.zoom_label.setStyleSheet(f"color: {T().text_dim}; padding: 0 10px;")
        self.pos_label.setStyleSheet(f"color: {T().text_dim}; padding: 0 10px;")
        sb.addPermanentWidget(self.zoom_label)
        sb.addPermanentWidget(self.pos_label)
        zoom_widget = _ClickableLabel(self.zoom_label.text())
        self.zoom_label.mousePressEvent = lambda ev: self.canvas.zoom_fit()

        self._status_msg = QLabel("PixelForge")
        sb.addWidget(self._status_msg, 1)

        self.canvas.status_changed.connect(self.pos_label.setText)
        self.canvas.zoom_changed.connect(self._update_zoom)
        self.layers_panel.changed.connect(self.canvas.invalidate)
        self.color_panel.fg_changed.connect(self.set_foreground)
        self.adj_panel.add_requested.connect(self.add_adjustment)
        self.brand_panel.color_picked.connect(lambda c: self.set_foreground(tuple(c) + (255,)))
        self.layers_panel.edit_text_requested.connect(lambda uid: self.text_dialog(uid=uid))
        self.layers_panel.edit_adjustment_requested.connect(lambda uid: self.adjustment_properties(uid))
        self.layers_panel.layer_style_requested.connect(lambda uid: self.layer_style_dialog(uid))

    def _build_docks(self, parent_layout):
        self.layers_panel = LayersPanel(self.session)
        self.history_panel = HistoryPanel(self.session)
        self.color_panel = ColorPanel(self.session)
        self.adj_panel = AdjustmentsPanel(self.session)
        self.brand_panel = BrandPanel()
        self.props_panel = PropertiesPanel(self.session)

        column = QWidget()
        col_lay = QVBoxLayout(column)
        col_lay.setContentsMargins(0, 0, 0, 0)
        col_lay.setSpacing(1)

        def card(*tabs):
            """A Pro card: tab strip + stacked panels. (name, widget, enabled)."""
            tabs_w = QTabWidget()
            tabs_w.setDocumentMode(True)
            for name, widget, enabled in tabs:
                idx = tabs_w.addTab(widget, name)
                tab = tabs_w.tabBar().tabButton(idx, QTabBarPos(idx))
                if tab is not None:
                    tab.setEnabled(enabled)
            tabs_w.setCurrentIndex(0)
            return tabs_w

        self.dock_color = card(("Color", self.color_panel, True),
                               ("Swatches", self.brand_panel, True))
        self.dock_adj = card(("Adjustments", self.adj_panel, True),
                             ("Properties", self.props_panel, True))
        self.channels_panel = ChannelsPanel(self.session)
        self.paths_panel = PathsPanel(self)
        self.dock_layers = card(("Layers", self.layers_panel, True),
                                ("Channels", self.channels_panel, True),
                                ("Paths", self.paths_panel, True))
        self.actions_panel = ActionsPanel(self.session, self)
        self.actions_panel.played.connect(self._on_action_played)
        self.dock_history = card(("History", self.history_panel, True),
                                 ("Actions", self.actions_panel, True))

        split = QSplitter(Qt.Vertical)
        for w in (self.dock_color, self.dock_adj, self.dock_layers, self.dock_history):
            split.addWidget(w)
        split.setStretchFactor(2, 1)
        split.setChildrenCollapsible(False)
        col_lay.addWidget(split)

        wrapper = QWidget()
        wl = QHBoxLayout(wrapper)
        wl.setContentsMargins(1, 0, 1, 0)
        wl.addWidget(column)
        parent_layout.addWidget(wrapper)

    def _build_tools(self):
        from .tools import TOOL_CLASSES
        for cls in TOOL_CLASSES:
            tool = cls(self)
            self._tools[tool.id] = tool

    def _toolbox_signal(self, sig):
        if isinstance(sig, str) and sig.startswith("__fg__:"):
            try:
                rgb = eval(sig[7:], {"__builtins__": {}}, {})
                self.set_foreground(tuple(rgb))
            except Exception:
                pass
            return
        self.set_tool(sig)

    @property
    def brush_options(self):
        return self.options.brush_options

    SHAPE_KINDS = {"shape_rect": "rect", "shape_ellipse": "ellipse", "shape_triangle": "triangle",
                   "shape_polygon": "polygon", "shape_line": "line"}

    def set_tool(self, tid):
        if tid not in self._tools:
            return
        self.toolbox.set_tool(tid)
        self.canvas.tool = self._tools[tid]
        self.canvas.setCursor(self.canvas.tool_cursor())
        if tid in self.SHAPE_KINDS:
            self.options.shape_kind.setCurrentText(self.SHAPE_KINDS[tid])
            self.options.shape_kind.setVisible(True)
        self.options.show_sections(tid)
        hints = {
            "brush": "Paint. [ ] resizes, Alt+click picks color",
            "pencil": "Hard-edged strokes — Size in options",
            "eraser": "Erase pixels of the active layer",
            "magiceraser": "Click: wipes similar pixels (tolerance in options)",
            "clone": "Alt+click sets the clone source, then paint",
            "dodge": "Paint to lighten",
            "burn": "Paint to darken",
            "sponge": "Saturate or Desaturate (mode in options)",
            "blur": "Paint to soften edges",
            "sharpen": "Paint to sharpen details",
            "smudge": "Drag to smear pixels",
            "spotheal": "Brush over a blemish — heals on release",
            "redeye": "Click a red pupil",
            "wand": "Click with the Magic Wand — tolerance in options",
            "bucket": "Click to flood-fill with the foreground color",
            "gradient": "Drag on canvas: foreground → transparent (or BG)",
            "text": "Click on canvas to add a text layer",
            "text_vert": "Click on canvas — each character stacks vertically",
            "shape_rect": "Drag to draw a rectangle",
            "shape_ellipse": "Drag to draw an ellipse",
            "shape_triangle": "Drag to draw a triangle",
            "shape_polygon": "Drag to draw an n-gon (Points in options)",
            "shape_line": "Drag to draw a line",
            "shape_custom": "Drag to draw the selected shape (star, arrow…)",
            "crop": "Drag a crop box, press Enter to apply",
            "lasso": "Draw a freehand selection",
            "lasso_poly": "Click vertices; click the first point or press Enter to close",
            "lasso_magnetic": "Draw near an edge — points snap to it",
            "quicksel": "Drag across the subject to select it (tolerance in options)",
            "objsel": "Drag a box around the object — it selects the subject",
            "slice": "Drag slice boxes; Enter exports them all as PNGs",
            "sliceselect": "Click a slice to select, drag to move, Del to remove",
            "note": "Click anywhere to pin a sticky note; Del removes the last",
            "count": "Click to place counters; right-click clears them",
            "heal": "Alt+click sets the source, then paint over flaws",
            "patch": "Select an area (lasso/wand), then click to heal it",
            "camove": "Select, then drag — content moves, the hole heals",
            "mixer": "Paints while mixing the colors under the brush",
            "patternstamp": "Paint a pattern — pick it in the options bar",
            "historybrush": "Paint to reveal the image as it was when opened",
            "bgeraser": "First click samples the background, then erase it away",
            "rotateview": "Drag to rotate the view; click to reset",
            "pen": "Click anchors; Enter finishes the path (Paths panel)",
            "pathsel": "Drag the active path to move it",
            "directsel": "Drag a single anchor point of the active path",
            "ruler": "Drag to measure distance and angle",
            "marquee": "Drag a rectangular selection",
            "ellipse_marquee": "Drag an elliptical selection",
            "move": "Drag to move the active layer",
        }
        self.options.set_hint(hints.get(tid, ""))

    def set_foreground(self, rgba):
        self.canvas.foreground = tuple(rgba)
        self.color_panel.set_fg(tuple(rgba))
        self.toolbox.chips.set_fg(tuple(rgba)[:3])

    def pf_fonts(self):
        if self._pf_fonts_cache is None:
            from pf.render import font_families
            self._pf_fonts_cache = font_families()
        return self._pf_fonts_cache

    # --------------------------------------------------------------- menus
    def _build_menus(self):
        mb = QMenuBar(self)
        mb.setStyleSheet(f"QMenuBar {{ background: {T().chrome}; }}")
        self.titlebar._menu_lay.addWidget(mb)
        self.menuBar().hide()

        built: dict[tuple, QMenu] = {}
        self._actions: dict[str, QAction] = {}
        used_shortcuts: set[str] = set()
        top_order: list[str] = []

        for path, label, shortcut, cmd in CATALOG:
            top = path[0]
            if top not in built:
                if top not in top_order:
                    top_order.append(top)
                built[top] = mb.addMenu(top)
            menu = built[top]
            for level in path[1:]:
                key = (top,) + (level,) if isinstance(level, str) else None
                if key not in built:
                    built[key] = menu.addMenu(level)
                menu = built[key]
            if label == "---":
                menu.addSeparator()
                continue
            act = QAction(label, self)
            if shortcut and shortcut not in used_shortcuts:
                act.setShortcut(QKeySequence(shortcut))
                used_shortcuts.add(shortcut)
            handler = self._handler_for(cmd)
            if handler is None:
                act.setEnabled(False)
            else:
                act.triggered.connect(handler)
            menu.addAction(act)
            self._actions[cmd] = act

        # our additions beyond the Photoshop tree (value-adds, clearly grouped)
        ai = mb.addMenu("AI Studio")
        ai.addAction(self._qact("Remove &Background (one-click)", self.remove_background))
        ai.addAction(self._qact("&Remove Object…", self.remove_object_dialog))
        ai.addAction(self._qact("Replace &Sky…", self.sky_dialog))
        ai.addAction(self._qact("&Harmonize Layer to Scene", self.harmonize_layer))
        ai.addSeparator()
        ai.addAction(self._qact("Smart &Upscale 2×", lambda: self._ai_upscale(2)))
        ai.addAction(self._qact("Smart Upscale &4×", lambda: self._ai_upscale(4)))
        ai.addAction(self._qact("&Generative Expand…", self.gen_expand_dialog))
        ai.addAction(self._qact("Soft &Portrait", self.soft_portrait))
        ai.addAction(self._qact("&Bokeh Background", self.bokeh_background))
        ai.addSeparator()
        # --- 2026 additions (PS 27.6 / Luminar Neo analogs, on-device) ---
        ai.addAction(self._qact("Product &Shot…  (matte + studio backdrop + AI shadow)", self.product_shot_dialog))
        ai.addAction(self._qact("&Relight…  (directional scene light)", self.relight_dialog))
        ai.addAction(self._qact("Restore &Old Photo…  (dust · denoise · fade)", self.restore_old_dialog))
        ai.addAction(self._qact("&Portrait Pro  (skin + eyes)", self.portrait_pro))
        ai.addAction(self._qact("&Find Distractions  (auto-heal specks)", self.find_distractions))
        ai.addAction(self._qact("&Watermark…", self.watermark_dialog))
        ai.addAction(self._qact("&Focus Stack…  (blend focus brackets)", self.focus_stack_dialog))
        ai.addAction(self._qact("Rotate &Object…  (spin a layer on canvas)", self.rotate_object_dialog))
        ai.addSeparator()
        ai.addAction(self._qact("&Guided Actions…  (type what you want)", self.guided_actions))

        create = mb.addMenu("Create")
        create.addAction(self._qact("&Templates…", self.new_from_template, "Ctrl+Alt+N"))
        create.addAction(self._qact("&Collage Maker…", self.collage_maker))
        create.addAction(self._qact("&Magic Resize…", self.magic_resize, "Ctrl+Shift+R"))
        create.addSeparator()
        create.addAction(self._qact("Remove &Background (one-click)", self.remove_background))
        create.addAction(self._qact("Add &Text Layer…", lambda: self.text_dialog(new_at=(60, 60))))

        m_filter = self._actions_menu("Filter", mb, built)
        extras = m_filter.addMenu("PixelForge Extras")
        for fid in EXTRA_FILTERS:
            extras.addAction(self._qact(FILTER_LABEL(fid), lambda _=False, f=fid: self.run_filter(f)))
        engine = m_filter.addMenu("PhotoCraft Engine")
        engine.addAction(self._qact("Command &Palette…", self.engine_palette, "Ctrl+Alt+P"))
        engine.addAction(self._qact("&Verify PSD Round-trip", self.engine_verify))

        helpm = mb.addMenu("Help")
        helpm.addAction(self._qact("&About PixelForge", self.about))

        # themes in Window menu
        wm = built.get("Window")
        if wm is not None:
            wm.addSeparator()
            theme_menu = wm.addMenu("Theme")
            grp = QActionGroup(self)
            for kind, label in THEME_LABELS.items():
                a = QAction(label, self)
                a.setCheckable(True)
                a.setChecked(kind == T().kind)
                a.triggered.connect(lambda _=False, k=kind: self.switch_theme(k))
                grp.addAction(a)
                theme_menu.addAction(a)

    def _actions_menu(self, name, mb, built):
        for key, menu in built.items():
            if key == name:
                return menu
        return mb.addMenu(name)

    def _qact(self, text, slot, shortcut=None):
        act = QAction(text, self)
        if shortcut:
            act.setShortcut(QKeySequence(shortcut))
        act.triggered.connect(slot)
        return act

    def _handler_for(self, cmd: str):
        """Map a catalog command id to a bound handler, or None (disabled)."""
        win = self
        table = {
            "file.new": win.new_from_template,
            "file.open": win.open_doc,
            "file.close": win.close_document,
            "file.save": win.save_doc,
            "file.saveAs": win.save_doc_as,
            "file.export.quickExportAsPng": lambda: win.export_as("png"),
            "file.export.exportAs": lambda: win.export_as("png"),
            "file.placeEmbedded": win.place_image,
            "edit.undo": win.session.undo,
            "edit.redo": win.session.redo,
            "edit.fill": lambda: win.session.execute("edit.fill", color=win.canvas.foreground) if win._require_doc(silent=True) else None,
            "edit.stroke": win.stroke_selection,
            "edit.clear": lambda: win.session.execute("edit.clear") if win._require_doc(silent=True) else None,
            "edit.freeTransform": win.transform_dialog,
            "edit.copy": win.copy_selection,
            "edit.copyMerged": win.copy_merged,
            "edit.paste": win.paste_clipboard,
            "edit.pasteSpecial.pasteInPlace": win.paste_clipboard,
            "image.imageSize": win.image_size,
            "image.canvasSize": win.canvas_size,
            "image.imageRotation.180": lambda: win.session.execute("image.rotateCanvas", degrees=180),
            "image.imageRotation.90Cw": lambda: win.session.execute("image.rotateCanvas", degrees=90),
            "image.imageRotation.90Ccw": lambda: win.session.execute("image.rotateCanvas", degrees=-90),
            "image.canvasFlip.horizontal": lambda: win.session.execute("image.flipCanvas", horizontal=True),
            "image.canvasFlip.vertical": lambda: win.session.execute("image.flipCanvas", horizontal=False),
            "image.trim": lambda: win.session.execute("image.trim"),
            "layer.new.layer": lambda: win.session.execute("layer.add"),
            "layer.new.group": lambda: win.session.execute("layer.addGroup"),
            "layer.duplicateLayer": lambda: win.session.execute("layer.duplicate"),
            "layer.deleteLayer": lambda: win.session.execute("layer.remove"),
            "layer.arrange.bringForward": lambda: win._reorder(+1),
            "layer.arrange.sendBackward": lambda: win._reorder(-1),
            "layer.arrange.bringToFront": lambda: win._reorder_to(len(win.session.doc.layers) - 1),
            "layer.arrange.sendToBack": lambda: win._reorder_to(0),
            "layer.mergeDown": lambda: win.session.execute("layer.mergeDown"),
            "layer.flattenImage": lambda: win.session.execute("layer.flatten"),
            "layer.rasterize.layer": lambda: win.session.execute("layer.rasterize"),
            "layer.layerMask.revealAll": lambda: win.session.execute("layer.mask.new", mode="reveal"),
            "layer.layerMask.hideAll": lambda: win.session.execute("layer.mask.new", mode="hide"),
            "layer.layerMask.fromSelection": lambda: win.session.execute("layer.mask.new", mode="from_sel"),
            "layer.layerMask.delete": lambda: win.session.execute("layer.mask.delete", apply=False),
            "layer.layerMask.apply": lambda: win.session.execute("layer.mask.delete", apply=True),
            "layer.style.blendingOptions": lambda: win.layer_style_dialog(),
            "layer.transform.flipHorizontal": lambda: win.session.execute("layer.flip", horizontal=True),
            "layer.transform.flipVertical": lambda: win.session.execute("layer.flip", horizontal=False),
            "layer.transform.rotate90Cw": lambda: win.session.execute("layer.rotate90", ccw=False),
            "layer.transform.rotate90Ccw": lambda: win.session.execute("layer.rotate90", ccw=True),
            "select.all": lambda: win.session.execute("selection.all"),
            "select.deselect": lambda: win.session.execute("selection.deselect"),
            "select.inverse": lambda: win.session.execute("selection.invert"),
            "select.reselect": win.reselect,
            "select.subject": lambda: win.session.execute("selection.subject"),
            "select.colorRange": win.color_range_dialog,
            "select.modify.feather": win.feather_dialog,
            "select.modify.expand": lambda: win.grow_dialog(+8),
            "select.modify.contract": lambda: win.grow_dialog(-8),
            "select.grow": lambda: win.grow_dialog(+8),
            "filter.filterGallery": win.filter_gallery,
            "file.automate.photomerge": win.photomerge_dialog,
            "file.automate.mergeToHdrPro": win.hdr_dialog,
            "file.automate.batch": win.batch_dialog,
            "file.scripts.deleteAllEmptyLayers": win.layer_cleanup,
            "image.adjustments.matchColor": win.match_color_dialog,
            "layer.newAdjustmentLayer.colorLookup": win.color_lookup_dialog,
        }
        if cmd in table:
            return table[cmd]
        if cmd in FILTER_MAP:
            return lambda _=False, f=FILTER_MAP[cmd]: win.run_filter(f)
        if cmd in IMAGE_ADJ_LIVE:
            return lambda _=False, k=IMAGE_ADJ_LIVE[cmd]: win.add_adjustment(k)
        if cmd in IMAGE_ADJ_DIRECT:
            return lambda _=False, f=IMAGE_ADJ_DIRECT[cmd]: win.run_filter(f)
        # text tool adjustments via Type menu entries map to our text layer
        if cmd == "type.panel":
            return lambda: win.text_dialog(new_at=(60, 60))
        return None

    def _reorder_to(self, idx):
        doc = self.session.doc
        if doc is None or doc.active_uid is None:
            return
        self.session.execute("layer.reorder", uid=doc.active_uid, to_flat_index=idx)

    def _wire_session(self):
        def on_doc(**_):
            self._update_title()
            self.doc_tabs.sync()
            self._maybe_snapshot()
            if self.session.doc and self.session.doc.active:
                self.props_panel.sync()
        self.session.on("doc", on_doc)
        self.session.on("history", on_doc)

    def _maybe_snapshot(self):
        """History Brush source: the composite as it was when the doc opened."""
        doc = self.session.doc
        if doc is None:
            self._history_snapshot = None
            self._hist_doc_id = None
            return
        if id(doc) != self._hist_doc_id:
            from pf import compose as _c
            comp = _c.composite_rgba8(doc)
            self._history_snapshot = comp.copy() if comp is not None else None
            self._hist_doc_id = id(doc)

    # ------------------------------------------------------ vector overlays
    def finish_pen_path(self):
        if self.pen_work and len(self.pen_work) >= 2:
            self.paths.append({"name": f"Path {len(self.paths) + 1}",
                               "points": [list(p) for p in self.pen_work]})
            self._active_path = len(self.paths) - 1
            self.paths_changed_notify()
            self.statusBar().showMessage(f"Path {len(self.paths)} created", 3000)
        self.pen_work = None
        self.canvas.update()

    def paths_changed_notify(self):
        for cb in list(self.paths_changed):
            try:
                cb()
            except RuntimeError:
                pass

    def draw_overlays(self, painter, canvas):
        """Window-level overlays: paths (from the Paths panel)."""
        from PySide6.QtGui import QPen, QColor
        for i, p in enumerate(self.paths):
            active = i == self._active_path
            painter.setPen(QPen(QColor(80, 180, 255) if active else QColor(160, 160, 160, 160),
                                1.4 if active else 1))
            pts = [canvas.doc_to_widget(*pt) for pt in p["points"]]
            for a, b in zip(pts[:-1], pts[1:]):
                painter.drawLine(a, b)
            a, b = pts[-1], pts[0]
            painter.drawLine(a, b)

    # -------------------------------------------------------------- helpers
    def _update_title(self, *_):
        doc = self.session.doc
        if doc is None:
            self.titlebar.set_doc_title("PixelForge")
            return
        name = os.path.basename(doc.path) if doc.path else "Untitled"
        star = " *" if doc.dirty else ""
        self.titlebar.set_doc_title(f"{name}{star} @ {self._zoom_pct:g}% (RGB/8)")

    def _update_zoom(self, z):
        self._zoom_pct = round(z * 100, 2)
        self.zoom_label.setText(f"{self._zoom_pct:g}%")
        self.doc_tabs.sync()
        self._update_title()

    def _reorder(self, delta):
        doc = self.session.doc
        if doc is None or doc.active_uid is None:
            return
        try:
            idx = [l.uid for l in doc.layers].index(doc.active_uid)
            self.session.execute("layer.reorder", uid=doc.active_uid, to_flat_index=idx + delta)
        except ValueError:
            pass

    def _require_doc(self, silent=False):
        if self.session.doc is None:
            if not silent:
                QMessageBox.information(self, "PixelForge", "Open or create a document first.")
            return False
        return True

    # ------------------------------------------------------------- file ops
    def new_from_template(self):
        dlg = TemplateDialog(self)
        if dlg.exec() != QDialog.Accepted or dlg.selected is None:
            return
        w, h = dlg.selected
        self.session.execute("doc.new", width=w, height=h, background=(255, 255, 255))
        self.canvas.zoom_fit()
        self._update_title()

    def open_doc(self):
        path, _ = QFileDialog_getOpen(self, FILE_FILTERS)
        if path:
            self.load_path(path)

    def place_image(self):
        if not self._require_doc():
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self, "Place image", "", FILE_FILTERS)
        if path:
            self.session.execute("doc.place", path=path)
            self.canvas.invalidate()

    def close_document(self):
        doc = self.session.doc
        if doc is None:
            return
        if doc.dirty:
            ret = QMessageBox.question(self, "Save changes?", "Save changes to this document?",
                                       QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if ret == QMessageBox.Cancel:
                return
            if ret == QMessageBox.Save:
                self.save_doc()
        self.session.doc = None
        self.session.undo_stack.clear()
        self.session.redo_stack.clear()
        self.session.emit("doc")
        self.session.emit("history")

    def load_path(self, path):
        try:
            self.session.execute("doc.open", path=path)
        except Exception as exc:
            QMessageBox.critical(self, "Open failed", str(exc))
            return
        if self.session.doc.warnings:
            QMessageBox.warning(self, "Open warnings", "\n".join(self.session.doc.warnings[:8]))
        self.canvas.zoom_fit()
        self._update_title()

    def save_doc(self):
        doc = self.session.doc
        if doc is None:
            return
        if not doc.path:
            return self.save_doc_as()
        try:
            self.session.execute("doc.save", path=doc.path)
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))
            return
        self._update_title()

    def save_doc_as(self):
        doc = self.session.doc
        if doc is None:
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(self, "Save As", "untitled.psd",
                                              "Photoshop (*.psd);;PNG (*.png);;JPEG (*.jpg)")
        if not path:
            return
        try:
            self.session.execute("doc.save", path=path)
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))
            return
        self._update_title()

    def export_as(self, fmt):
        doc = self.session.doc
        if doc is None:
            return
        from PySide6.QtWidgets import QFileDialog
        ext = "png" if fmt == "png" else "jpg"
        path, _ = QFileDialog.getSaveFileName(self, "Export", f"export.{ext}", f"{fmt.upper()} (*.{ext})")
        if not path:
            return
        try:
            self.session.execute("doc.save", path=path)
            self.statusBar().showMessage(f"Exported: {path}", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    # ------------------------------------------------------------ clipboard
    def copy_selection(self):
        doc = self.session.doc
        if doc is None:
            return
        comp = compose.composite_rgba8(doc)
        bb = doc.selection_bbox() or (0, 0, doc.width, doc.height)
        x0, y0, x1, y1 = bb
        region = comp[y0:y1, x0:x1].copy()
        if doc.selection is not None:
            mask = doc.selection[y0:y1, x0:x1]
            region[..., 3] = np.where(mask, region[..., 3], 0)
        from PySide6.QtGui import QImage
        img = QImage(region.data, region.shape[1], region.shape[0], region.shape[1] * 4, QImage.Format_RGBA8888)
        QApplication.clipboard().setImage(img.copy())
        self.statusBar().showMessage("Copied", 2000)

    def copy_merged(self):
        doc = self.session.doc
        if doc is None:
            return
        comp = compose.composite_rgba8(doc)
        bb = doc.selection_bbox() or (0, 0, doc.width, doc.height)
        x0, y0, x1, y1 = bb
        region = comp[y0:y1, x0:x1].copy()
        from PySide6.QtGui import QImage
        img = QImage(region.data, region.shape[1], region.shape[0], region.shape[1] * 4, QImage.Format_RGBA8888)
        QApplication.clipboard().setImage(img.copy())
        self.statusBar().showMessage("Copied (merged)", 2000)

    def paste_clipboard(self):
        if not self._require_doc():
            return
        img = QApplication.clipboard().image()
        if img.isNull():
            return
        img = img.convertToFormat(__import__("PySide6.QtGui", fromlist=["QImage"]).QImage.Format_RGBA8888)
        import numpy as _np
        ptr = img.constBits()
        arr = _np.frombuffer(ptr, _np.uint8).reshape(img.height(), img.width(), 4).copy()
        self.session.execute("layer.add", name="Pasted", pixels=arr)
        self.canvas.invalidate()

    def reselect(self):
        # our last selection bbox from history is not tracked; select all
        if self._require_doc(silent=True):
            self.session.execute("selection.all")

    # ------------------------------------------------------------- edit ops
    def stroke_selection(self):
        w, ok = QInputDialog.getInt(self, "Stroke Selection", "Width (px):", 4, 1, 60)
        if ok:
            self.session.execute("edit.strokeSelection", width=w, color=self.canvas.foreground)

    def transform_dialog(self):
        doc = self.session.doc
        if doc is None or doc.active is None or not self._require_doc():
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Free Transform")
        form = QFormLayout(dlg)
        sx = QDoubleSpinBox(); sx.setRange(0.05, 8); sx.setValue(1.0); sx.setSingleStep(0.05)
        sy = QDoubleSpinBox(); sy.setRange(0.05, 8); sy.setValue(1.0); sy.setSingleStep(0.05)
        rot = QDoubleSpinBox(); rot.setRange(-180, 180); rot.setValue(0)
        form.addRow("Scale X", sx); form.addRow("Scale Y", sy); form.addRow("Rotate °", rot)
        preview_state = {"applied": False}

        def preview():
            if preview_state["applied"]:
                self.session.undo()
                preview_state["applied"] = False
            if abs(sx.value() - 1) < 1e-3 and abs(sy.value() - 1) < 1e-3 and abs(rot.value()) < 1e-3:
                return
            self.session.execute("layer.transform", scale_x=sx.value(), scale_y=sy.value(), rotate=rot.value())
            preview_state["applied"] = True
            self.canvas.invalidate()

        def commit():
            if preview_state["applied"]:
                self.session.undo()
                preview_state["applied"] = False
                self.session.execute("layer.transform", scale_x=sx.value(), scale_y=sy.value(), rotate=rot.value())
            dlg.accept()

        sx.valueChanged.connect(preview); sy.valueChanged.connect(preview); rot.valueChanged.connect(preview)
        row = QHBoxLayout()
        ok = QPushButton("Apply"); cancel = QPushButton("Cancel")
        ok.clicked.connect(commit); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        form.addRow(row)
        dlg.exec()
        if preview_state["applied"]:
            self.session.undo()
        self.canvas.invalidate()

    # ------------------------------------------------------- adjustments UI
    def add_adjustment(self, kind):
        if not self._require_doc():
            return
        self.session.execute("layer.newAdjustment", kind=kind)
        self.adjustment_properties(self.session.doc.active_uid)

    def adjustment_properties(self, uid):
        doc = self.session.doc
        layer = doc.find(uid) if doc else None
        if not isinstance(layer, AdjustmentLayer):
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(f"{ADJUSTMENT_KINDS.get(layer.adjustment, layer.adjustment)}")
        form = QFormLayout(dlg)
        widgets = {}
        for pname, pval in layer.params.items():
            if isinstance(pval, (list, tuple)) and pname in ("color", "shadow", "highlight"):
                btn = QToolButton()
                store = {"c": QColor(*pval[:3])}

                def paint(btn=btn, store=store):
                    pm_btn = QPixmap_cmd(44, 18, store["c"], btn)

                def pick(_=False, store=store, btn=btn):
                    c = QColorDialog.getColor(store["c"], dlg, "Color")
                    if c.isValid():
                        store["c"] = c
                        paint()

                paint()
                btn.clicked.connect(pick)
                widgets[pname] = ("color", btn, store)
                form.addRow(pname.title(), btn)
            elif isinstance(pval, (int, float)):
                sp = QDoubleSpinBox()
                base = DEFAULT_ADJ_PARAMS.get(layer.adjustment, {}).get(pname, pval)
                span = max(1.0, abs(float(base)) * 3)
                sp.setRange(-span, span)
                sp.setSingleStep(span / 50)
                sp.setValue(float(pval))
                widgets[pname] = ("num", sp, None)
                form.addRow(pname.title(), sp)
            elif isinstance(pval, list) and pname == "points":
                ed = QLineEdit(json.dumps(pval))
                widgets[pname] = ("points", ed, None)
                form.addRow("Points (json)", ed)
        row = QHBoxLayout()
        ok = QPushButton("OK"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        form.addRow(row)
        if dlg.exec() != QDialog.Accepted:
            return
        params = {}
        for pname, (kindw, w, store) in widgets.items():
            if kindw == "num":
                params[pname] = w.value()
            elif kindw == "color":
                c = store["c"]
                params[pname] = [c.red(), c.green(), c.blue()]
            elif kindw == "points":
                try:
                    params[pname] = json.loads(w.text())
                except Exception:
                    pass
        self.session.execute("layer.setAdjustment", uid=uid, **params)

    def layer_style_dialog(self, uid=None):
        doc = self.session.doc
        layer = doc.active if doc else None
        if layer is None or isinstance(layer, AdjustmentLayer) or not hasattr(layer, "effects"):
            return
        dlg = LayerStyleDialog(self, layer.effects)
        if dlg.exec() == QDialog.Accepted:
            self.session.execute("layer.setEffects", uid=layer.uid, effects=dlg.result_effects())
        elif dlg._cleared:
            self.session.execute("layer.setEffects", uid=layer.uid, effects={})

    def text_dialog(self, uid=None, new_at=None, vertical=False):
        if not self._require_doc():
            return
        params = {}
        if uid:
            layer = self.session.doc.find(uid)
            if isinstance(layer, TextLayer):
                params = dict(layer.params)
        dlg = TextDialog(self, params, self.pf_fonts())
        if dlg.exec() != QDialog.Accepted:
            return
        p = dlg.params()
        if vertical and p.get("text"):
            p["text"] = "\n".join(list(str(p["text"]).replace("\n", "")))
        if uid:
            self.session.execute("layer.setText", uid=uid, **p)
        else:
            self.session.execute("layer.newText", x=int(new_at[0]), y=int(new_at[1]), **p)

    # ---------------------------------------------------------- selections
    def feather_dialog(self):
        r, ok = QInputDialog.getDouble(self, "Feather Selection", "Radius (px):", 4.0, 0.5, 100, 1)
        if ok:
            self.session.execute("selection.feather", radius=r)

    def grow_dialog(self, px=3):
        amount, ok = QInputDialog.getInt(self, "Expand / Contract", "Pixels (−to contract):", px, -100, 100)
        if ok:
            self.session.execute("selection.growContract", px=amount)

    def color_range_dialog(self):
        tol, ok = QInputDialog.getInt(self, "Color Range", "Tolerance:", 48, 0, 255)
        if ok:
            self.session.execute("selection.colorRange", color=self.canvas.foreground, tolerance=tol)

    def crop_selection(self):
        doc = self.session.doc
        if doc is None or doc.selection is None:
            self.statusBar().showMessage("Make a selection first", 3000)
            return
        self.session.execute("image.crop", rect=doc.selection_bbox())
        self.canvas.zoom_fit()

    def _commit_pending_crop(self):
        doc = self.session.doc
        self._pending_crop = False
        if doc is not None and doc.selection is not None:
            self.session.execute("image.crop", rect=doc.selection_bbox())
            self.canvas.zoom_fit()

    def image_size(self):
        doc = self.session.doc
        if doc is None:
            return
        w, ok = QInputDialog.getInt(self, "Image Size", "Width (px):", doc.width, 1, 20000)
        if not ok:
            return
        h, ok = QInputDialog.getInt(self, "Image Size", "Height (px):", doc.height, 1, 20000)
        if not ok:
            return
        self.session.execute("image.resize", width=w, height=h)
        self.canvas.zoom_fit()

    def canvas_size(self):
        doc = self.session.doc
        if doc is None:
            return
        w, ok = QInputDialog.getInt(self, "Canvas Size", "Width (px):", doc.width, 1, 20000)
        if not ok:
            return
        h, ok = QInputDialog.getInt(self, "Canvas Size", "Height (px):", doc.height, 1, 20000)
        if not ok:
            return
        self.session.execute("image.canvasSize", width=w, height=h)
        self.canvas.zoom_fit()

    # -------------------------------------------------------------- filters
    def run_filter(self, fid):
        if not self._require_doc():
            return
        try:
            self.session.execute("filter.run", filter_id=fid)
            self.statusBar().showMessage(f"Filter applied: {fid}", 3000)
        except Exception as exc:
            QMessageBox.warning(self, "Filter failed", str(exc))

    def filter_gallery(self):
        if not self._require_doc():
            return
        dlg = FilterGalleryDialog(self, self)
        if dlg.exec() == QDialog.Accepted and dlg.selected:
            self.run_filter(dlg.selected)

    # ----------------------------------------------------------- canva ops
    def collage_maker(self):
        CollageDialog(self, self).exec()

    def magic_resize(self):
        if not self._require_doc():
            return
        dlg = ResizeDialog(self, self)
        if dlg.exec() != QDialog.Accepted:
            return
        chosen, mode = dlg.selected
        from PySide6.QtWidgets import QFileDialog
        out_dir = QFileDialog.getExistingDirectory(self, "Where should the copies go?")
        if not out_dir:
            return
        base = os.path.splitext(os.path.basename(self.session.doc.path or "design"))[0]
        results = []
        for w, h, name in chosen:
            if mode.startswith("Export"):
                with tempfile.TemporaryDirectory() as tmp:
                    src = os.path.join(tmp, "r.psd")
                    self.session.execute("doc.save", path=src)
                    d = psdio.read(src)
                    s = min(w / d.width, h / d.height)
                    self.session.execute("image.resize", width=max(1, int(d.width * s)),
                                         height=max(1, int(d.height * s)))
                    dest = os.path.join(out_dir, f"{base}_{name.replace(' ', '_')}.png")
                    self.session.execute("doc.save", path=dest)
                    self.session.undo()
                    results.append(dest)
            else:
                self.session.execute("image.resize", width=w, height=h)
                self.canvas.zoom_fit()
                break
        self.statusBar().showMessage(
            f"Magic resize: {len(results)} file(s) written" if results else "Resized", 5000)

    # ------------------------------------------------- AI Studio (on-device)
    def _combo_pick(self, title, label, options, current=0):
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(label))
        combo = QComboBox()
        combo.addItems(options)
        combo.setCurrentIndex(current)
        lay.addWidget(combo)
        row = QHBoxLayout()
        ok = QPushButton("OK"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        lay.addLayout(row)
        return (combo.currentText(), True) if dlg.exec() == QDialog.Accepted else (None, False)

    def _ai_upscale(self, factor):
        if not self._require_doc():
            return
        self.statusBar().showMessage(f"Smart upscaling {factor}× (detail recovery)…", 4000)
        self.session.execute("image.upscaleSmart", factor=factor)
        self.canvas.zoom_fit()
        self.statusBar().showMessage(f"Upscaled to {self.session.doc.width}×{self.session.doc.height}", 4000)

    def gen_expand_dialog(self):
        if not self._require_doc():
            return
        from PySide6.QtWidgets import QSpinBox, QGridLayout
        dlg = QDialog(self)
        dlg.setWindowTitle("Generative Expand (on-device inpaint)")
        grid = QGridLayout(dlg)
        spins = {}
        for name, r, c in (("top", 0, 1), ("left", 1, 0), ("right", 1, 2), ("bottom", 2, 1)):
            sp = QSpinBox(); sp.setRange(0, 800); sp.setValue(96)
            grid.addWidget(QLabel(name.title()), r, c * 2)
            grid.addWidget(sp, r, c * 2 + 1)
            spins[name] = sp
        note = QLabel("The canvas grows and the new border is invented from the image context.")
        note.setWordWrap(True)
        grid.addWidget(note, 3, 0, 1, 5)
        row = QHBoxLayout()
        ok = QPushButton("Expand"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 4, 0, 1, 5)
        if dlg.exec() != QDialog.Accepted:
            return
        self.statusBar().showMessage("Expanding canvas (inpainting border)…", 4000)
        self.session.execute("image.expandGen",
                             left=spins["left"].value(), right=spins["right"].value(),
                             top=spins["top"].value(), bottom=spins["bottom"].value())
        self.canvas.zoom_fit()

    def sky_dialog(self):
        if not self._require_doc():
            return
        preset, ok = self._combo_pick("Replace Sky", "Sky:",
                                      ["sunset", "clear", "golden", "dusk", "storm", "teal"], 0)
        if not ok:
            return
        self.statusBar().showMessage("Detecting sky and replacing…", 4000)
        try:
            self.session.execute("image.skyReplace", preset=preset)
            self.canvas.invalidate()
            self.statusBar().showMessage(f"Sky replaced ({preset}) with scene relight", 4000)
        except Exception as exc:
            QMessageBox.warning(self, "Replace Sky", f"No sky found in this image.\n{exc}")

    def harmonize_layer(self):
        if not self._require_doc():
            return
        self.session.execute("layer.harmonize", strength=0.85)
        self.canvas.invalidate()
        self.statusBar().showMessage("Layer harmonized to the scene (Lab match)", 4000)

    def soft_portrait(self):
        if not self._require_doc():
            return
        self.session.execute("filter.run", filter_id="softPortrait")
        self.canvas.invalidate()

    def bokeh_background(self):
        if not self._require_doc():
            return
        self.statusBar().showMessage("Selecting subject and blurring background…", 4000)
        self.session.execute("filter.run", filter_id="bokehBackground")
        self.canvas.invalidate()

    def remove_object_dialog(self):
        doc = self.session.doc
        if doc is None or doc.selection is None:
            QMessageBox.information(self, "Remove Object",
                                    "Make a selection around the object first (Lasso, Wand, Object Selection…),\nthen run this again.")
            return
        self.session.execute("image.patchHeal")
        self.canvas.invalidate()
        self.statusBar().showMessage("Object removed (content-aware inpaint)", 4000)

    def guided_actions(self):
        if not self._require_doc():
            return
        dlg = GuidedActionsDialog(self)
        if dlg.exec() != QDialog.Accepted or not dlg.recipe:
            return
        doc = self.session.doc
        for step in dlg.recipe:
            try:
                if step["cmd"] == "image.expandGen" and all(
                        step.get(k, 0) == 0 for k in ("left", "right", "top", "bottom")):
                    side = max(doc.width, doc.height)
                    self.session.execute("image.expandGen",
                                         left=(side - doc.width) // 2,
                                         right=side - doc.width - (side - doc.width) // 2,
                                         top=(side - doc.height) // 2,
                                         bottom=side - doc.height - (side - doc.height) // 2)
                    continue
                params = {k: v for k, v in step.items() if k != "cmd"}
                self.session.execute(step["cmd"], **params)
            except Exception as exc:
                QMessageBox.warning(self, "Guided Action", f"{step}: {exc}")
                break
        self.canvas.invalidate()
        self.statusBar().showMessage("Guided action applied", 4000)

    def photomerge_dialog(self):
        from PySide6.QtWidgets import QFileDialog
        paths, _ = QFileDialog.getOpenFileNames(self, "Pick photos left→right for the panorama",
                                                "", FILE_FILTERS)
        if len(paths) < 2:
            if paths:
                QMessageBox.information(self, "Photomerge", "Pick at least two photos.")
            return
        self.statusBar().showMessage("Stitching panorama…", 5000)
        try:
            self.session.execute("doc.photomerge", paths=paths)
            self.canvas.zoom_fit()
            self._update_title()
            self.doc_tabs.sync()
            self.statusBar().showMessage("Photomerge complete", 4000)
        except Exception as exc:
            QMessageBox.warning(self, "Photomerge", str(exc))

    def hdr_dialog(self):
        from PySide6.QtWidgets import QFileDialog
        paths, _ = QFileDialog.getOpenFileNames(self, "Pick exposure brackets (dark → bright)",
                                                "", FILE_FILTERS)
        if len(paths) < 2:
            if paths:
                QMessageBox.information(self, "Merge to HDR", "Pick at least two exposures.")
            return
        self.statusBar().showMessage("Merging to HDR (Mertens fusion)…", 5000)
        try:
            self.session.execute("doc.hdrMerge", paths=paths)
            self.canvas.zoom_fit()
            self._update_title()
            self.doc_tabs.sync()
            self.statusBar().showMessage("HDR merge complete", 4000)
        except Exception as exc:
            QMessageBox.warning(self, "Merge to HDR", str(exc))

    # --------------------------------------------- 2026 additions (v4, on-device)
    def product_shot_dialog(self):
        if not self._require_doc():
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Product Shot — matte, backdrop, AI shadow")
        grid = QGridLayout(dlg)
        grid.addWidget(QLabel("Style"), 0, 0)
        style = QComboBox(); style.addItems(["studio", "solid"]); grid.addWidget(style, 0, 1)
        shadow = QCheckBox("AI contact shadow"); shadow.setChecked(True); grid.addWidget(shadow, 1, 0, 1, 2)
        grid.addWidget(QLabel("Backdrop color"), 2, 0)
        color = QComboBox(); color.addItems(["light gray", "white", "black", "warm beige"])
        grid.addWidget(color, 2, 1)
        note = QLabel("Cuts the subject out, puts it on a clean studio backdrop and paints a soft contact shadow.")
        note.setWordWrap(True); grid.addWidget(note, 3, 0, 1, 2)
        row = QHBoxLayout()
        ok = QPushButton("Create"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 4, 0, 1, 2)
        if dlg.exec() != QDialog.Accepted:
            return
        colors = {"light gray": (245, 245, 247), "white": (252, 252, 252),
                  "black": (18, 18, 20), "warm beige": (238, 228, 214)}
        self.statusBar().showMessage("Building product shot (matte → backdrop → shadow)…", 5000)
        try:
            self.session.execute("image.productShot", style=style.currentText(),
                                 shadow=shadow.isChecked(),
                                 color=colors[color.currentText()])
            self.canvas.zoom_fit()
            self.statusBar().showMessage("Product shot ready", 4000)
        except Exception as exc:
            QMessageBox.warning(self, "Product Shot", str(exc))

    def relight_dialog(self):
        if not self._require_doc():
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Relight — directional scene light")
        grid = QGridLayout(dlg)
        grid.addWidget(QLabel("Light angle (°, 0 = right, 90 = top)"), 0, 0)
        angle = QSpinBox(); angle.setRange(0, 359); angle.setValue(315); grid.addWidget(angle, 0, 1)
        grid.addWidget(QLabel("Strength"), 1, 0)
        strength = QSlider(Qt.Horizontal); strength.setRange(0, 100); strength.setValue(50)
        grid.addWidget(strength, 1, 1)
        grid.addWidget(QLabel("Falloff"), 2, 0)
        falloff = QSlider(Qt.Horizontal); falloff.setRange(0, 300); falloff.setValue(120)
        grid.addWidget(falloff, 2, 1)
        row = QHBoxLayout()
        ok = QPushButton("Relight"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 3, 0, 1, 2)
        if dlg.exec() != QDialog.Accepted:
            return
        self.statusBar().showMessage("Relighting scene from depth…", 4000)
        self.session.execute("image.relight", angle=angle.value(),
                             strength=strength.value() / 100,
                             falloff=1.2 + falloff.value() / 100)
        self.canvas.invalidate()
        self.statusBar().showMessage("Scene relit", 4000)

    def restore_old_dialog(self):
        if not self._require_doc():
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Restore Old Photo")
        grid = QGridLayout(dlg)
        grid.addWidget(QLabel("Dust & denoise strength"), 0, 0)
        den = QSlider(Qt.Horizontal); den.setRange(0, 20); den.setValue(8); grid.addWidget(den, 0, 1)
        colorize = QCheckBox("Colorize faded B&W"); colorize.setChecked(False); grid.addWidget(colorize, 1, 0, 1, 2)
        row = QHBoxLayout()
        ok = QPushButton("Restore"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 2, 0, 1, 2)
        if dlg.exec() != QDialog.Accepted:
            return
        self.statusBar().showMessage("Removing dust, denoising, restoring contrast…", 5000)
        self.session.execute("image.restoreOld", denoise=den.value(),
                             colorize=colorize.isChecked())
        self.canvas.invalidate()
        self.statusBar().showMessage("Photo restored", 4000)

    def portrait_pro(self):
        if not self._require_doc():
            return
        self.statusBar().showMessage("Detecting face — smoothing skin, brightening eyes…", 4000)
        self.session.execute("image.portraitPro", skin=0.55, eye=0.35)
        self.canvas.invalidate()
        n = getattr(self.session, "last_faces", 0)
        self.statusBar().showMessage("Portrait Pro: face detected" if n else
                                     "Portrait Pro: no face found — applied gentle global smooth", 4000)

    def find_distractions(self):
        if not self._require_doc():
            return
        self.statusBar().showMessage("Scanning for small distractions…", 4000)
        spots, healed, _ = self.session.execute("image.findDistractions")
        self.canvas.invalidate()
        if spots or healed:
            self.statusBar().showMessage(f"Find Distractions: {healed} tiny speck(s) healed, "
                                         f"{max(len(spots) - healed, 0)} larger spot(s) left to review", 6000)
        else:
            self.statusBar().showMessage("Find Distractions: nothing found — clean shot", 4000)

    def watermark_dialog(self):
        if not self._require_doc():
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Watermark")
        grid = QGridLayout(dlg)
        grid.addWidget(QLabel("Text"), 0, 0)
        text = QLineEdit("© PixelForge"); grid.addWidget(text, 0, 1)
        grid.addWidget(QLabel("Corner"), 1, 0)
        corner = QComboBox()
        corner.addItems(["bottom-right", "bottom-left", "top-right", "top-left", "center"])
        grid.addWidget(corner, 1, 1)
        grid.addWidget(QLabel("Opacity %"), 2, 0)
        op = QSlider(Qt.Horizontal); op.setRange(5, 100); op.setValue(45); grid.addWidget(op, 2, 1)
        tile = QCheckBox("Tile across image"); grid.addWidget(tile, 3, 0, 1, 2)
        row = QHBoxLayout()
        ok = QPushButton("Apply"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 4, 0, 1, 2)
        if dlg.exec() != QDialog.Accepted or not text.text().strip():
            return
        self.session.execute("image.watermark", text=text.text().strip(),
                             corner=corner.currentText(), opacity=op.value() / 100,
                             tile=tile.isChecked())
        self.canvas.invalidate()
        self.statusBar().showMessage("Watermark applied (own layer)", 4000)

    def focus_stack_dialog(self):
        from PySide6.QtWidgets import QFileDialog
        paths, _ = QFileDialog.getOpenFileNames(self, "Pick focus brackets (any order)", "", FILE_FILTERS)
        if len(paths) < 2:
            if paths:
                QMessageBox.information(self, "Focus Stack", "Pick at least two brackets.")
            return
        self.statusBar().showMessage("Stacking focus (sharpest pixels win)…", 5000)
        try:
            self.session.execute("doc.focusStack", paths=paths)
            self.canvas.zoom_fit()
            self._update_title()
            self.doc_tabs.sync()
            self.statusBar().showMessage("Focus stack complete", 4000)
        except Exception as exc:
            QMessageBox.warning(self, "Focus Stack", str(exc))

    def rotate_object_dialog(self):
        doc_ok = self._require_doc()
        if not doc_ok:
            return
        layer = self.session.doc.active
        if layer is None or getattr(layer, "pixels", None) is None:
            QMessageBox.information(self, "Rotate Object", "Select a pixel layer to rotate first.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Rotate Object")
        grid = QGridLayout(dlg)
        grid.addWidget(QLabel("Angle (°, negative = counter-clockwise)"), 0, 0)
        ang = QSpinBox(); ang.setRange(-180, 180); ang.setValue(15); grid.addWidget(ang, 0, 1)
        grid.addWidget(QLabel("Scale %"), 1, 0)
        scl = QSpinBox(); scl.setRange(10, 300); scl.setValue(100); grid.addWidget(scl, 1, 1)
        row = QHBoxLayout()
        ok = QPushButton("Rotate"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 2, 0, 1, 2)
        if dlg.exec() != QDialog.Accepted:
            return
        self.session.execute("edit.rotateObject", angle=ang.value(), scale=scl.value() / 100)
        self.canvas.invalidate()
        self.statusBar().showMessage("Object rotated on canvas", 4000)

    def layer_cleanup(self):
        if not self._require_doc():
            return
        res = self.session.execute("file.scripts.deleteAllEmptyLayers")
        self.canvas.invalidate()
        if res:
            self.statusBar().showMessage(f"Layer Cleanup: {res['removed']} empty layer(s) removed, "
                                         f"{res['renamed']} renamed by content", 6000)
        else:
            self.statusBar().showMessage("Layer Cleanup: nothing to clean", 4000)

    def batch_dialog(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Batch — folder → action set → folder")
        grid = QGridLayout(dlg)
        grid.addWidget(QLabel("Action set"), 0, 0)
        sets = pf_actions.list_sets()
        combo = QComboBox(); combo.addItems(sets if sets else ["(no sets — record one in the Actions panel)"])
        grid.addWidget(combo, 0, 1, 1, 2)
        in_edit = QLineEdit(); in_edit.setPlaceholderText("Folder with images…")
        b_in = QPushButton("Choose…")
        def pick_in():
            d = QFileDialog.getExistingDirectory(self, "Input folder")
            if d: in_edit.setText(d)
        b_in.clicked.connect(pick_in)
        grid.addWidget(QLabel("Input folder"), 1, 0)
        grid.addWidget(in_edit, 1, 1); grid.addWidget(b_in, 1, 2)
        out_edit = QLineEdit(); out_edit.setPlaceholderText("Where results go…")
        b_out = QPushButton("Choose…")
        def pick_out():
            d = QFileDialog.getExistingDirectory(self, "Output folder")
            if d: out_edit.setText(d)
        b_out.clicked.connect(pick_out)
        grid.addWidget(QLabel("Output folder"), 2, 0)
        grid.addWidget(out_edit, 2, 1); grid.addWidget(b_out, 2, 2)
        grid.addWidget(QLabel("Format"), 3, 0)
        fmt = QComboBox(); fmt.addItems(["png", "jpg"]); grid.addWidget(fmt, 3, 1)
        row = QHBoxLayout()
        ok = QPushButton("Run Batch"); cancel = QPushButton("Cancel")
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        grid.addLayout(row, 4, 0, 1, 3)
        if dlg.exec() != QDialog.Accepted:
            return
        src_dir, out_dir = in_edit.text().strip(), out_edit.text().strip()
        if not sets or not src_dir or not out_dir:
            QMessageBox.information(self, "Batch", "Pick an action set, an input folder and an output folder.")
            return
        exts = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff")
        paths = sorted(os.path.join(src_dir, f) for f in os.listdir(src_dir)
                       if f.lower().endswith(exts))
        if not paths:
            QMessageBox.information(self, "Batch", "No images found in the input folder.")
            return
        try:
            steps = pf_actions.load_set(combo.currentText())
        except Exception as exc:
            QMessageBox.warning(self, "Batch", f"Cannot read action set: {exc}")
            return
        self.statusBar().showMessage(f"Batch: playing '{combo.currentText()}' on {len(paths)} image(s)…", 10000)
        outputs, errors = pf_actions.batch(self.session, paths, steps, out_dir, fmt.currentText())
        self.canvas.invalidate()
        if errors:
            QMessageBox.warning(self, "Batch", f"{len(outputs)} processed, {len(errors)} failed:\n" + "\n".join(errors[:6]))
        else:
            self.statusBar().showMessage(f"Batch complete: {len(outputs)} image(s) written to {out_dir}", 6000)

    def _on_action_played(self, name):
        self.canvas.invalidate()
        self.statusBar().showMessage(f"Action '{name}' played", 4000)

    def match_color_dialog(self):
        if not self._require_doc():
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self, "Match colors from image…", "", FILE_FILTERS)
        if not path:
            return
        self.session.execute("image.matchColorFile", path=path, strength=0.8)
        self.canvas.invalidate()
        self.statusBar().showMessage("Match Color applied", 4000)

    def color_lookup_dialog(self):
        if not self._require_doc():
            return
        looks = ["lookVivid", "lookTealOrange", "lookWarmCinema", "lookNoir", "lookFade",
                 "lookVintage", "lookCyberpunk", "lookBleach", "lookLandscape"]
        names = [l[5:] if l.startswith("look") else l for l in looks]
        name, ok = self._combo_pick("Color Lookup", "Preset pack:", names, 0)
        if not ok:
            return
        self.session.execute("filter.run", filter_id=looks[names.index(name)])
        self.canvas.invalidate()
        self.statusBar().showMessage(f"Color Lookup: {name}", 4000)

    def remove_background(self):
        if not self._require_doc():
            return
        self.statusBar().showMessage("Removing background (GrabCut)…", 4000)
        try:
            self.session.execute("image.removeBackground")
            self.canvas.invalidate()
            self.statusBar().showMessage("Background removed", 3000)
        except Exception as exc:
            QMessageBox.warning(self, "Remove background", str(exc))

    # ---------------------------------------------------------- engine menu
    def engine_palette(self):
        doc = self.session.doc
        if doc is None:
            return
        try:
            cmds = self.bridge.commands()
        except EngineError as exc:
            QMessageBox.warning(self, "PhotoCraft engine unavailable", str(exc))
            return
        dlg = EngineCommandDialog(self, cmds)
        if dlg.exec() != QDialog.Accepted or dlg.selected is None:
            return
        command, params = dlg.selected
        try:
            with tempfile.TemporaryDirectory() as tmp:
                src = os.path.join(tmp, "in.psd")
                self.session.execute("doc.save", path=src)
                dest = os.path.join(tmp, "out.psd")
                self.bridge.run_command_on_file(src, command, params, dest)
                self.session.execute("doc.open", path=dest)
                self.canvas.zoom_fit()
            self.statusBar().showMessage(f"Engine: {command} applied", 4000)
        except EngineError as exc:
            QMessageBox.warning(self, "Engine error", str(exc))

    def engine_verify(self):
        doc = self.session.doc
        if doc is None:
            return
        try:
            with tempfile.TemporaryDirectory() as tmp:
                src = os.path.join(tmp, "verify.psd")
                self.session.execute("doc.save", path=src)
                d = psdio.read(src)
                a = compose.composite_rgba8(d).astype(np.int16)
                b = self.bridge.render_file(src).astype(np.int16)
                if a.shape != b.shape:
                    QMessageBox.warning(self, "Verify", f"Size mismatch: {a.shape} vs {b.shape}")
                    return
                diff = np.abs(a - b)
                pct = float((diff <= 6).mean() * 100.0)
                QMessageBox.information(self, "PSD Round-trip Verification",
                                        f"Engine: PhotoCraft\nMean |diff|: {diff.mean():.2f}/255\n"
                                        f"Pixels within ±6: {pct:.2f}%\n\n"
                                        + ("✅ Composites match." if pct > 99 else "⚠️ Differences."))
        except EngineError as exc:
            QMessageBox.warning(self, "PhotoCraft engine unavailable", str(exc))

    def about(self):
        QMessageBox.about(self, "About PixelForge",
                          "<h3>PixelForge 4.0</h3>"
                          "<p>Photoshop-grade editing with PhotoCraft's design system "
                          "(Pro Medium theme, Lucide icons, the complete Photoshop menu tree) "
                          "plus Canva-style creation. Rust <b>PhotoCraft</b> engine attached for "
                          "PSD verification.</p>")

    def switch_theme(self, kind):
        t = set_theme(kind)
        from .theme import apply_palette
        apply_palette(QApplication.instance(), t)
        QApplication.instance().setStyleSheet(qss(t))
        mb = self.titlebar._menu_lay.itemAt(0).widget()
        if mb is not None:
            mb.setStyleSheet(f"QMenuBar {{ background: {t.chrome}; }}")
        self.toolbox.retint()
        self.canvas.invalidate()
        self.doc_tabs.sync()
        self._update_title()

    MORE_TOOL_KEYS = {"p": "pen", "j": "spotheal", "n": "note", "r": "rotateview",
                      "y": "historybrush", "a": "pathsel", "k": "sliceselect",
                      "d": "directsel", "f": "objsel", "q": "quicksel"}

    def keyPressEvent(self, ev):
        fw = QApplication.focusWidget()
        from PySide6.QtWidgets import QPlainTextEdit
        typing = fw and isinstance(fw, (QLineEdit, QPlainTextEdit))
        if typing:
            super().keyPressEvent(ev)
            return
        key, mod = ev.key(), ev.modifiers()
        # Ctrl+[ / Ctrl+]: layer order (Photoshop) — plain [ ] resizes brushes (canvas)
        if mod & Qt.ControlModifier and key in (Qt.Key_BracketLeft, Qt.Key_BracketRight):
            if self._require_doc(silent=True):
                self._reorder(1 if key == Qt.Key_BracketRight else -1)
            return
        if not (mod & ~Qt.ShiftModifier):   # plain letters = tool shortcuts
            k = chr(key) if 32 <= key < 127 else ""
            tid = TOOL_KEYS.get(k.lower()) or self.MORE_TOOL_KEYS.get(k.lower())
            if tid:
                self.set_tool(tid)
                return
        super().keyPressEvent(ev)

    def closeEvent(self, event):
        doc = self.session.doc
        if doc is not None and doc.dirty:
            ret = QMessageBox.question(self, "Save changes?",
                                       "The document has unsaved changes. Save before quitting?",
                                       QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if ret == QMessageBox.Cancel:
                event.ignore()
                return
            if ret == QMessageBox.Save:
                self.save_doc()
        self.bridge.close()
        event.accept()


# ------------------------------------------------------------ small widgets
def QTabBarPos(idx):
    from PySide6.QtWidgets import QTabBar
    return QTabBar.ButtonPosition.RightSide


def _disabled_panel():
    w = QWidget()
    lay = QVBoxLayout(w)
    lbl = QLabel("Not implemented yet — like PhotoCraft's early alphas")
    lbl.setAlignment(__import__("PySide6.QtCore", fromlist=["Qt"]).Qt.AlignCenter)
    lbl.setStyleSheet("color: #a0a0a0;")
    lay.addWidget(lbl)
    return w


def _ClickableLabel(text):
    return QLabel(text)


def QFileDialog_getOpen(parent, filters):
    from PySide6.QtWidgets import QFileDialog
    return QFileDialog.getOpenFileName(parent, "Open", "", filters)


def QPixmap_cmd(w, h, color, btn):
    from PySide6.QtGui import QPixmap
    pm = QPixmap(w, h)
    pm.fill(color)
    btn.setIcon(pm)
    btn.setIconSize(pm.size())


def FILTER_LABEL(s):
    out = ""
    for i, ch in enumerate(str(s)):
        if i and ch.isupper() and s[i - 1].islower():
            out += " "
        out += ch
    return out


class PropertiesPanel(QWidget):
    """Live layer properties form (x/y/w/h, opacity)."""

    def __init__(self, session, parent=None):
        super().__init__(parent)
        self.session = session
        lay = QFormLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        self.l_name = QLineEdit()
        self.l_kind = QLabel()
        self.l_pos = QLabel()
        self.l_size = QLabel()
        lay.addRow("Name", self.l_name)
        lay.addRow("Kind", self.l_kind)
        lay.addRow("Position", self.l_pos)
        lay.addRow("Size", self.l_size)
        session.on("doc", self.sync)
        self.sync()

    def sync(self, **_):
        doc = self.session.doc
        layer = doc.active if doc else None
        if layer is None:
            self.l_name.setText("")
            self.l_kind.setText("")
            self.l_pos.setText("")
            self.l_size.setText("")
            return
        self.l_name.setText(layer.name)
        self.l_kind.setText(layer.kind)
        self.l_pos.setText(f"x {layer.x}, y {layer.y}")
        w = getattr(layer, "w", 0)
        h = getattr(layer, "h", 0)
        self.l_size.setText(f"{w} × {h} px" if w or h else "auto")


class DocTabs(QWidget):
    """Document tab strip: 'name @ 12.5% (RGB/8)' with a close button."""

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.setFixedHeight(26)
        self.session = win.session
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 0, 4, 0)
        lay.setSpacing(6)
        self.tab = QWidget()
        self.tab.setFixedHeight(22)
        self.tab_lay = QHBoxLayout(self.tab)
        self.tab_lay.setContentsMargins(10, 0, 6, 0)
        self.tab_lay.setSpacing(6)
        self.tab_title = QLabel("PixelForge")
        self.tab_lay.addWidget(self.tab_title)
        self.close_btn = QLabel("×")
        self.close_btn.setFixedWidth(10)
        self.close_btn.setStyleSheet("color: #a0a0a0;")
        self.close_btn.mousePressEvent = lambda ev: self.win.close_document()
        self.tab_lay.addWidget(self.close_btn)
        self.tab.mousePressEvent = lambda ev: None
        lay.addWidget(self.tab)
        lay.addStretch(1)
        self._style()
        self.session.on("doc", lambda **_: self.sync())

    def _style(self):
        t = T()
        self.setStyleSheet(
            f"QWidget {{ background: {t.tab_strip}; }}"
            f"#doctab {{ background: {t.canvas}; border-top: 2px solid {t.accent}; }}"
            f"QLabel {{ color: {t.text_dim}; font-size: 11px; background: transparent; }}")
        self.tab.setObjectName("doctab")

    def sync(self, **_):
        doc = self.session.doc
        t = T()
        if doc is None:
            self.tab_title.setText("PixelForge")
            self.close_btn.hide()
        else:
            name = os.path.basename(doc.path) if doc.path else "Untitled"
            star = "*" if doc.dirty else ""
            self.tab_title.setText(f"{name}{star}  @ {self.win._zoom_pct:g}% (RGB/8)")
            self.close_btn.show()
        self._style()


from PySide6.QtWidgets import QFileDialog  # noqa: E402


class EngineCommandDialog(QDialog):
    def __init__(self, parent, commands):
        super().__init__(parent)
        self.setWindowTitle("PhotoCraft Engine — Command Palette")
        self.resize(660, 560)
        self.selected = None
        lay = QVBoxLayout(self)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search the engine's 800+ commands…")
        lay.addWidget(self.search)
        self.results = QListWidget()
        lay.addWidget(self.results, 1)
        self.params_edit = QLineEdit()
        self.params_edit.setPlaceholderText('params JSON, e.g. {"radius": 5}')
        lay.addWidget(self.params_edit)
        row = QHBoxLayout()
        ok = QPushButton("Run on Document"); cancel = QPushButton("Cancel")
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        lay.addLayout(row)
        self._all = commands
        self.search.textChanged.connect(self._refilter)
        self.results.itemDoubleClicked.connect(lambda *_: self.accept())
        self._refilter("")

    def _refilter(self, text):
        self.results.clear()
        text = (text or "").lower()
        for cmd in self._all:
            cid = cmd.get("id", "") if isinstance(cmd, dict) else str(cmd)
            label = cmd.get("label", "") if isinstance(cmd, dict) else ""
            menu = cmd.get("menu", "") if isinstance(cmd, dict) else ""
            if text in f"{cid} {label} {menu}".lower():
                self.results.addItem(f"{cid}   — {label}" + (f"   [{menu}]" if menu else ""))

    def accept(self):
        item = self.results.currentItem()
        if item is None:
            return
        cid = item.text().split()[0]
        raw = self.params_edit.text().strip()
        params = {}
        if raw:
            try:
                params = json.loads(raw)
            except json.JSONDecodeError:
                QMessageBox.warning(self, "Bad JSON", "Params must be valid JSON.")
                return
        self.selected = (cid, params)
        super().accept()


class GuidedActionsDialog(QDialog):
    """Type-what-you-want actions (on-device keyword recipes, no cloud)."""

    RECIPES = {
        "remove background": [{"cmd": "image.removeBackground"}],
        "delete background": [{"cmd": "image.removeBackground"}],
        "cut out subject": [{"cmd": "selection.subject"}],
        "remove object": [{"cmd": "image.patchHeal"}],
        "remove people": [{"cmd": "image.patchHeal"}],
        "restore old photo": [{"cmd": "image.restoreOld", "denoise": 8}],
        "product shot": [{"cmd": "image.productShot", "style": "studio"}],
        "portrait retouch": [{"cmd": "image.portraitPro", "skin": 0.55, "eye": 0.35}],
        "watermark my photo": [{"cmd": "image.watermark", "text": "© PixelForge"}],
        "blur background": [{"cmd": "selection.subject"},
                            {"cmd": "selection.invert"},
                            {"cmd": "filter.run", "filter_id": "irisBlur"}],
        "bokeh": [{"cmd": "selection.subject"},
                   {"cmd": "selection.invert"},
                   {"cmd": "filter.run", "filter_id": "irisBlur"}],
        "black and white": [{"cmd": "filter.run", "filter_id": "bw"}],
        "b&w": [{"cmd": "filter.run", "filter_id": "bw"}],
        "vintage": [{"cmd": "filter.run", "filter_id": "lookVintage"}],
        "cinema": [{"cmd": "filter.run", "filter_id": "lookWarmCinema"}],
        "movie look": [{"cmd": "filter.run", "filter_id": "lookTealOrange"}],
        "pop": [{"cmd": "filter.run", "filter_id": "lookVivid"}],
        "vivid": [{"cmd": "filter.run", "filter_id": "lookVivid"}],
        "vibrant": [{"cmd": "filter.run", "filter_id": "lookVivid"}],
        "cyberpunk": [{"cmd": "filter.run", "filter_id": "lookCyberpunk"}],
        "noir": [{"cmd": "filter.run", "filter_id": "lookNoir"}],
        "sharpen": [{"cmd": "filter.run", "filter_id": "smartSharpen"}],
        "upscale": [{"cmd": "image.upscaleSmart", "factor": 2}],
        "bigger": [{"cmd": "image.upscaleSmart", "factor": 2}],
        "square": [{"cmd": "image.expandGen", "left": 0, "right": 0, "top": 0, "bottom": 0}],
        "replace sky": [{"cmd": "image.skyReplace", "preset": "sunset"}],
        "sunset sky": [{"cmd": "image.skyReplace", "preset": "sunset"}],
        "fix colors": [{"cmd": "filter.run", "filter_id": "autoEnhance"}],
        "auto enhance": [{"cmd": "filter.run", "filter_id": "autoEnhance"}],
        "denoise": [{"cmd": "filter.run", "filter_id": "reduceNoise"}],
        "remove noise": [{"cmd": "filter.run", "filter_id": "reduceNoise"}],
        "portrait": [{"cmd": "filter.run", "filter_id": "softPortrait"}],
        "smooth skin": [{"cmd": "filter.run", "filter_id": "softPortrait"}],
    }

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Guided Actions — type what you want")
        self.resize(560, 340)
        self.recipe = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Describe the edit (works fully offline):"))
        self.input = QLineEdit()
        self.input.setPlaceholderText("e.g. remove background, blur background, vintage, upscale…")
        lay.addWidget(self.input)
        self.listw = QListWidget()
        lay.addWidget(self.listw, 1)
        for k in self.RECIPES:
            self.listw.addItem(k)
        row = QHBoxLayout()
        ok = QPushButton("Apply"); cancel = QPushButton("Cancel")
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        lay.addLayout(row)
        self.input.textChanged.connect(self._filter)
        self.listw.itemDoubleClicked.connect(lambda *_: self.accept())
        self.input.setFocus()

    def _filter(self, text):
        text = (text or "").lower()
        for i in range(self.listw.count()):
            self.listw.item(i).setHidden(text not in self.listw.item(i).text())

    def accept(self):
        it = self.listw.currentItem()
        key = self.input.text().strip().lower()
        if key in self.RECIPES:
            chosen = key
        elif it is not None and not it.isHidden():
            chosen = it.text()
        else:
            return
        self.recipe = self.RECIPES[chosen]
        super().accept()
