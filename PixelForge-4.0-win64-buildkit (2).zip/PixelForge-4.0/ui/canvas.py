"""Canvas v2: composite display, zoom/pan, arbitrary-mask marching ants,
brush cursor, tool input."""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt, QTimer, QPointF, QRectF, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPixmap, QBrush
from PySide6.QtWidgets import QWidget

from pf import compose
from pf.doc import PixelLayer

ZOOM_MIN, ZOOM_MAX = 0.03, 32.0


class CanvasWidget(QWidget):
    status_changed = Signal(str)
    zoom_changed = Signal(float)

    def __init__(self, session, parent=None):
        super().__init__(parent)
        self.session = session
        self.scale = 1.0
        self.offset = QPointF(0, 0)
        self.rotation = 0.0        # Rotate View tool (degrees, view-only)
        self.display_channel = None  # Channels panel: None | 'r' | 'g' | 'b' | 'a' 
        self.tool = None
        self.foreground = (0, 0, 0, 255)
        self.background = (255, 255, 255, 255)
        self.shape_stroke = (20, 20, 20, 255)
        self._cache = None
        self._cache_rev = None
        self._panning = False
        self._pan_start = QPointF()
        self._pan_offset = QPointF()
        self._space_down = False
        self._ants_phase = 0
        self._ants_boundary = None
        self._ants_key_val = None
        self._mouse_pos = None
        self._checker = self._make_checker()
        self._ants_timer = QTimer(self)
        self._ants_timer.timeout.connect(self._tick_ants)
        self._ants_timer.start(140)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        session.on("doc", self.invalidate)

    @property
    def doc(self):
        return self.session.doc

    @property
    def win(self):
        """The MainWindow this canvas lives in (walks up the widget tree)."""
        p = self.parent()
        while p is not None and not hasattr(p, "session"):
            p = p.parent()
        return p

    def invalidate(self):
        self._cache = None
        self._ants_boundary = None
        self.update()

    # ------------------------------------------------------------- transforms
    def to_doc(self, pos):
        xr = (pos.x() - self.offset.x()) / self.scale
        yr = (pos.y() - self.offset.y()) / self.scale
        th = np.radians(getattr(self, "rotation", 0.0))
        if not th or self.doc is None:
            return (xr, yr)
        cx, cy = self.doc.width / 2, self.doc.height / 2
        c, s = np.cos(-th), np.sin(-th)
        return (cx + (xr - cx) * c - (yr - cy) * s,
                cy + (xr - cx) * s + (yr - cy) * c)

    def doc_to_widget(self, x, y):
        th = np.radians(getattr(self, "rotation", 0.0))
        if th and self.doc is not None:
            cx, cy = self.doc.width / 2, self.doc.height / 2
            c, s = np.cos(th), np.sin(th)
            xr = cx + (x - cx) * c - (y - cy) * s
            yr = cy + (x - cx) * s + (y - cy) * c
        else:
            xr, yr = x, y
        return QPointF(xr * self.scale + self.offset.x(), yr * self.scale + self.offset.y())

    def zoom_to(self, value, anchor=None):
        value = float(np.clip(value, ZOOM_MIN, ZOOM_MAX))
        anchor = anchor or QPointF(self.width() / 2, self.height() / 2)
        dx, dy = self.to_doc(anchor)
        self.scale = value
        self.offset = QPointF(anchor.x() - dx * value, anchor.y() - dy * value)
        self.zoom_changed.emit(value)
        self.update()

    def zoom_fit(self):
        if self.doc is None:
            return
        s = min(self.width() / max(1, self.doc.width), self.height() / max(1, self.doc.height)) * 0.92
        self.scale = s
        self.offset = QPointF((self.width() - self.doc.width * s) / 2,
                              (self.height() - self.doc.height * s) / 2)
        self.zoom_changed.emit(s)
        self.update()

    def zoom_100(self):
        self.zoom_to(1.0)

    # -------------------------------------------------------------- painting
    @staticmethod
    def _make_checker():
        pm = QPixmap(16, 16)
        pm.fill(QColor("#9a9a9a"))
        p = QPainter(pm)
        p.fillRect(0, 0, 8, 8, QColor("#7a7a7a"))
        p.fillRect(8, 8, 8, 8, QColor("#7a7a7a"))
        p.end()
        return QBrush(pm)

    def composite(self):
        if self.doc is None:
            return None
        rev = (id(self.doc), len(self.doc.layers))
        if self._cache is None or self._cache_rev != rev:
            self._cache = compose.composite_rgba8(self.doc)
            self._cache_rev = rev
        return self._cache

    def composite_pixel(self, x, y):
        cache = self.composite()
        if cache is None:
            return (255, 255, 255, 255)
        h, w = cache.shape[:2]
        x, y = int(np.clip(x, 0, w - 1)), int(np.clip(y, 0, h - 1))
        px = cache[y, x]
        return (int(px[0]), int(px[1]), int(px[2]), int(px[3]))

    def paintEvent(self, event):
        painter = QPainter(self)
        from .theme import current as _T
        painter.fillRect(self.rect(), QColor(_T().canvas))
        cache = self.composite()
        if cache is None:
            painter.setPen(QPen(QColor("#555")))
            painter.drawText(self.rect(), Qt.AlignCenter, "No document — File ▸ New from Template or Open")
            painter.end()
            return

        if self.display_channel:
            ch = {"r": 0, "g": 1, "b": 2, "a": 3}[self.display_channel]
            gray = cache[..., ch].astype(np.uint8)
            view = np.dstack([gray, gray, gray, np.full_like(gray, 255)])
        else:
            view = cache
        h, w = view.shape[:2]
        img = QImage(view.data, w, h, w * 4, QImage.Format_RGBA8888)
        p0 = self.doc_to_widget(0, 0)
        p1 = self.doc_to_widget(w, h)
        from PySide6.QtCore import QRect
        rw, rh = float(p1.x()) - float(p0.x()), float(p1.y()) - float(p0.y())
        rect = QRect(int(p0.x()), int(p0.y()), int(np.ceil(rw)), int(np.ceil(rh)))
        clip = self.rect().intersected(rect)
        if not clip.isEmpty():
            painter.fillRect(clip, self._checker)
        painter.save()
        painter.translate(self.offset)
        painter.scale(self.scale, self.scale)
        if self.rotation:
            painter.translate(w / 2.0, h / 2.0)
            painter.rotate(self.rotation)
            painter.translate(-w / 2.0, -h / 2.0)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, self.scale < 1.0)
        painter.drawImage(0, 0, img)
        painter.restore()
        painter.setPen(QPen(QColor("#00000060")))
        painter.drawRect(rect.adjusted(0, 0, -1, -1))

        if self.doc.selection is not None:
            self._draw_ants(painter)

        if self.tool is not None:
            self.tool.draw_overlay(painter, self)
        win = self.win
        if win is not None and hasattr(win, "draw_overlays"):
            win.draw_overlays(painter, self)

        self._draw_brush_cursor(painter)
        painter.end()

    # ------------------------------------------------------------ selections
    def _ants_key(self):
        doc = self.doc
        if doc is None or doc.selection is None:
            return None
        sel = doc.selection
        return (sel.sum(), float(sel.sum() * 0.000001 % 1), doc.width, doc.height,
                len(self.session.undo_stack), len(self.session.redo_stack))

    def _boundary(self):
        key = self._ants_key()
        if key is None:
            return None
        if self._ants_boundary is None or self._ants_key_val != key:
            sel = self.doc.selection
            padded = np.zeros((sel.shape[0] + 2, sel.shape[1] + 2), bool)
            padded[1:-1, 1:-1] = sel
            b = padded[1:-1, 1:-1] ^ padded[:-2, 1:-1]
            b |= padded[1:-1, 1:-1] ^ padded[2:, 1:-1]
            b |= padded[1:-1, 1:-1] ^ padded[1:-1, :-2]
            b |= padded[1:-1, 1:-1] ^ padded[1:-1, 2:]
            ys, xs = np.nonzero(b)
            # subsample boundary for performance at huge selections
            if xs.size > 40000:
                step = max(1, xs.size // 40000)
                xs, ys = xs[::step], ys[::step]
            self._ants_boundary = (xs, ys)
            self._ants_key_val = key
        return self._ants_boundary

    def _draw_ants(self, painter):
        b = self._boundary()
        if b is None:
            return
        xs, ys = b
        phase = self._ants_phase
        painter.setPen(QPen(QColor(0, 0, 0), 1))
        for i in range(len(xs)):
            if (i + phase) % 2:
                continue
            pt = self.doc_to_widget(float(xs[i]), float(ys[i]))
            painter.drawPoint(pt)
        painter.setPen(QPen(QColor(255, 255, 255), 1))
        for i in range(len(xs)):
            if (i + phase) % 2 == 0:
                continue
            pt = self.doc_to_widget(float(xs[i]), float(ys[i]))
            painter.drawPoint(pt)

    def _draw_brush_cursor(self, painter):
        if self._mouse_pos is None or self.tool is None:
            return
        from .tools import SIZE_TOOLS
        if self.tool.id not in SIZE_TOOLS:
            return
        opts = self.win.brush_options if hasattr(self.win, "brush_options") else {"size": 18}
        r = opts.get("size", 18) / 2 * self.scale
        painter.setPen(QPen(QColor(255, 255, 255, 200), 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawEllipse(self._mouse_pos, max(2, r), max(2, r))
        painter.setPen(QPen(QColor(0, 0, 0, 160), 1))
        painter.drawEllipse(self._mouse_pos, max(3, r + 1), max(3, r + 1))

    def _tick_ants(self):
        if self.doc is not None and self.doc.selection is not None:
            self._ants_phase = (self._ants_phase + 1) % 2
            self.update()

    # ---------------------------------------------------------------- events
    def wheelEvent(self, event):
        factor = 1.25 if event.angleDelta().y() > 0 else 0.8
        self.zoom_to(self.scale * factor, event.position())

    def mousePressEvent(self, event):
        if self.doc is None:
            return
        pos = event.position()
        pan_mode = (event.button() in (Qt.MiddleButton, Qt.XButton1)
                    or self._space_down
                    or (self.tool and self.tool.id == "hand"))
        if pan_mode:
            self._panning = True
            self._pan_start = pos
            self._pan_offset = QPointF(self.offset)
            self.setCursor(Qt.ClosedHandCursor)
            return
        if self.tool and event.button() == Qt.LeftButton:
            self.tool.press(self, self.to_doc(pos), event)
        elif self.tool and event.button() == Qt.RightButton \
                and getattr(self.tool, "handles_right", False):
            self.tool.press(self, self.to_doc(pos), event)

    def mouseMoveEvent(self, event):
        pos = event.position()
        self._mouse_pos = pos
        dx, dy = self.to_doc(pos)
        if self.doc is not None:
            self.status_changed.emit(f"{int(dx)}, {int(dy)} px   ·   {self.doc.width}×{self.doc.height}")
        if self._panning:
            self.offset = QPointF(self._pan_offset.x() + (pos.x() - self._pan_start.x()),
                                  self._pan_offset.y() + (pos.y() - self._pan_start.y()))
            self.update()
            return
        if self.tool and event.buttons() & Qt.LeftButton:
            self.tool.move(self, self.to_doc(pos), event)
        else:
            self.update()

    def mouseReleaseEvent(self, event):
        if self._panning:
            self._panning = False
            self.setCursor(self.tool_cursor())
            return
        if self.tool and event.button() == Qt.LeftButton:
            self.tool.release(self, self.to_doc(event.position()), event)

    def mouseDoubleClickEvent(self, event):
        if self.tool and event.button() == Qt.LeftButton:
            self.tool.double_click(self, self.to_doc(event.position()), event)

    def leaveEvent(self, event):
        self._mouse_pos = None
        self.update()

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key_Space and not event.isAutoRepeat():
            self._space_down = True
            self.setCursor(Qt.OpenHandCursor)
            return
        if key in (Qt.Key_Return, Qt.Key_Enter):
            w = self.win
            if getattr(w, "_pending_crop", False):
                w._commit_pending_crop()
            elif getattr(self.tool, "id", "") == "lasso_poly" and getattr(self.tool, "_points", None):
                self.tool._commit(self)
            elif hasattr(self.tool, "key"):
                self.tool.key(self, event)
            return
        if key == Qt.Key_Escape:
            w = self.win
            if getattr(w, "_pending_crop", False):
                w._pending_crop = False
                self.session.execute("selection.deselect")
            elif getattr(self.tool, "id", "") == "lasso_poly" and getattr(self.tool, "_points", None):
                self.tool._points = None
                self.update()
            elif hasattr(self.tool, "key"):
                self.tool.key(self, event)
            return
        # [ / ] resize the brush like Photoshop (paint tools only)
        if key in (Qt.Key_BracketLeft, Qt.Key_BracketRight) and self.tool is not None:
            from .tools import SIZE_TOOLS
            if self.tool.id in SIZE_TOOLS:
                opts = self.win.options
                step = max(1, opts.size_spin.value() // 8)
                v = opts.size_spin.value() + (step if key == Qt.Key_BracketRight else -step)
                opts.size_spin.setValue(max(1, min(800, v)))
                return
        if hasattr(self.tool, "key"):
            self.tool.key(self, event)   # tool-specific keys first
        w = self.win
        if w is not None:
            w.keyPressEvent(event)   # window: tool letters, Ctrl+[ ]

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Space and not event.isAutoRepeat():
            self._space_down = False
            self.setCursor(self.tool_cursor())
        else:
            if self.parent():
                self.parent().keyReleaseEvent(event)

    def tool_cursor(self):
        return self.tool.cursor() if self.tool else Qt.ArrowCursor
