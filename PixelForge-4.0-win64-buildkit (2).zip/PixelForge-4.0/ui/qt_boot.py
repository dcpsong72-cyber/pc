"""Qt bootstrap: make PySide6 work even on stripped containers.

If libxkbcommon (or another Qt dependency) can't be resolved by the dynamic
loader, we prepend our bundled runtime/lib to LD_LIBRARY_PATH and re-exec the
interpreter — LD_LIBRARY_PATH is only read at process startup, so a re-exec is
the reliable way to apply it.
"""

from __future__ import annotations

import ctypes
import os
import sys


def _project_runtime_dir() -> str:
    here = os.path.dirname(os.path.abspath(__file__))          # ui/
    root = os.path.dirname(here)                                # pixelforge/
    cand = os.path.join(root, "runtime", "lib")
    if os.path.isdir(cand):
        return cand
    parent = os.path.join(os.path.dirname(root), "runtime", "lib")
    return parent if os.path.isdir(parent) else cand


def preload_runtime_libs() -> None:
    # Already resolvable by the loader? (normal user machines)
    try:
        ctypes.CDLL("libxkbcommon.so.0")
        return
    except OSError:
        pass

    # Not resolvable: re-exec with LD_LIBRARY_PATH pointing at our bundled
    # libs. (Preloading via ctypes is not enough when the file's internal
    # SONAME differs from the name Qt requests — e.g. auditwheel renames.)
    if os.environ.get("_PF_REEXEC") != "1":
        libdir = _project_runtime_dir()
        env = os.environ.copy()
        existing = env.get("LD_LIBRARY_PATH", "")
        env["LD_LIBRARY_PATH"] = f"{libdir}:/usr/lib/x86_64-linux-gnu" + (f":{existing}" if existing else "")
        env["_PF_REEXEC"] = "1"
        os.execve(sys.executable, [sys.executable] + sys.argv, env)
    # If we still get here and the import fails below, the ImportError is the
    # most useful diagnostic.


def create_app(argv: list[str]):
    preload_runtime_libs()
    os.environ.setdefault("QT_LOGGING_RULES", "*.debug=false;qt.qpa.*=false")
    from PySide6.QtWidgets import QApplication
    from PySide6.QtGui import QIcon
    from .theme import apply_theme
    app = QApplication(argv)
    app.setApplicationName("PixelForge")
    app.setOrganizationName("PixelForge")
    apply_theme(app)
    return app
