"""Photoshop toolbox — a port of PhotoCraft's toolbar (panels.rs, MIT):
their exact tool sections, 40px chrome column, 30px slots, Lucide glyphs,
corner-triangle group flyouts, and the overlapping fg/bg color chips."""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal, QPointF, QRect, QSize
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QWidget, QVBoxLayout, QMenu, QToolButton, QLabel

from . import icons
from .theme import current as T

# Tool groups separated by hairlines, Photoshop order — PhotoCraft's TOOL_SECTIONS.
# (first entry of each group = the group's default; tools our app implements are enabled)
# The COMPLETE Photoshop 2026 toolbox — PhotoCraft's exact TOOL_SECTIONS
# (panels.rs, MIT): every tool is present; the ones our engine implements are
# enabled, the rest render disabled until implemented (their model).
TOOL_SECTIONS = [
    [("move", "Move")],
    [("marquee", "Rectangular Marquee"), ("ellipse_marquee", "Elliptical Marquee")],
    [("lasso", "Lasso"), ("lasso_poly", "Polygonal Lasso"), ("lasso_magnetic", "Magnetic Lasso")],
    [("objsel", "Object Selection"), ("quicksel", "Quick Selection"), ("wand", "Magic Wand")],
    [("crop", "Crop"), ("slice", "Slice"), ("sliceselect", "Slice Select")],
    [("eyedropper", "Eyedropper"), ("ruler", "Ruler"), ("note", "Note"), ("count", "Count")],
    [("spotheal", "Spot Healing Brush"), ("heal", "Healing Brush"), ("patch", "Patch"),
     ("camove", "Content-Aware Move"), ("redeye", "Red Eye")],
    [("brush", "Brush"), ("pencil", "Pencil"), ("mixer", "Mixer Brush")],
    [("clone", "Clone Stamp"), ("patternstamp", "Pattern Stamp")],
    [("historybrush", "History Brush")],
    [("eraser", "Eraser"), ("bgeraser", "Background Eraser"), ("magiceraser", "Magic Eraser")],
    [("gradient", "Gradient"), ("bucket", "Paint Bucket")],
    [("blur", "Blur"), ("sharpen", "Sharpen"), ("smudge", "Smudge")],
    [("dodge", "Dodge"), ("burn", "Burn"), ("sponge", "Sponge")],
    [("pen", "Pen")],
    [("text", "Horizontal Type"), ("text_vert", "Vertical Type")],
    [("pathsel", "Path Selection"), ("directsel", "Direct Selection")],
    [("shape_rect", "Rectangle"), ("shape_ellipse", "Ellipse"), ("shape_triangle", "Triangle"),
     ("shape_polygon", "Polygon"), ("shape_line", "Line"), ("shape_custom", "Custom Shape")],
    [("hand", "Hand"), ("rotateview", "Rotate View")],
    [("zoom", "Zoom")],
]
# hairline after the last group of each of their sections
SECTION_BREAKS = {0, 5, 13, 17}

# tools PixelForge implements (the rest render disabled, like PhotoCraft's alphas)
ENABLED_TOOLS = {t for group in TOOL_SECTIONS for t, _ in group}  # all 52 live

BX = 30          # slot size (their `bx` for pro)
MARGIN = 5       # column margin (their `m` for pro)
ICON = int(BX * 0.52)


class ToolButton(QToolButton):
    """30×30 slot: Lucide glyph + corner triangle for flyout groups."""

    def __init__(self, tools, current, parent=None):
        super().__init__(parent)
        self.tools = tools            # [(tid, label)]
        self.current = current
        self.setFixedSize(BX, BX)
        self.setCheckable(True)
        t = T()
        self._icon_color = t.icon
        self._update()

    def _update(self):
        t = T()
        sel = self.isChecked()
        name = icons.TOOL_ICONS.get(self.current, "square-dashed")
        color = t.accent_text if sel else t.icon
        self.setIcon(icons.icon(name, color, ICON))
        self.setIconSize(QSize(ICON, ICON))
        label = self.tools[0][1] if self.tools else ""
        self.setToolTip(label)
        self.update()

    def set_current(self, tid):
        self.current = tid
        self._update()

    def paintEvent(self, ev):
        super().paintEvent(ev)
        if len(self.tools) > 1:
            p = QPainter(self)
            t = T()
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(t.icon if not self.isChecked() else t.accent_text))
            w, h = self.width(), self.height()
            p.drawPolygon([QPointF(w - 7, h - 3), QPointF(w - 3, h - 3), QPointF(w - 3, h - 7)])
            p.end()

    def mousePressEvent(self, ev):
        if ev.button() == Qt.RightButton and len(self.tools) > 1:
            self.show_flyout()
            return
        if ev.button() == Qt.LeftButton:
            # long-press opens the flyout, like Photoshop's press-and-hold
            self._press_pos = ev.position()
            self._longpress = QTimer(self)
            self._longpress.setSingleShot(True)
            self._longpress.setInterval(450)
            if len(self.tools) > 1:
                self._longpress.timeout.connect(self.show_flyout)
                self._longpress.start()
        super().mousePressEvent(ev)

    def mouseReleaseEvent(self, ev):
        if getattr(self, "_longpress", None) is not None and self._longpress.isActive():
            self._longpress.stop()
        if getattr(self, "_flyout_shown", False):
            self._flyout_shown = False   # the menu consumed this press
            ev.accept()
            return
        super().mouseReleaseEvent(ev)

    def show_flyout(self):
        if getattr(self, "_longpress", None) is not None:
            self._longpress.stop()
        self._flyout_shown = True
        menu = QMenu(self)
        t = T()
        for tid, label in self.tools:
            act = menu.addAction(icons.icon(icons.TOOL_ICONS.get(tid, "square-dashed"),
                                            t.icon, 15), label)
            act.setCheckable(True)
            act.setChecked(tid == self.current)
            enabled = tid in ENABLED_TOOLS
            act.setEnabled(enabled)
            if not enabled:
                act.setToolTip("Not implemented yet")
            act.triggered.connect(lambda _=False, t=tid: self.window().set_tool(t))
        menu.exec(self.mapToGlobal(self.rect().bottomLeft()))


# tools our engine implements (the rest render disabled, like PhotoCraft's)


class ColorChips(QWidget):
    """Photoshop overlapping fg/bg squares with Default/Switch buttons (Pro)."""

    fg_changed = Signal(tuple)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(62)
        self.fg = (0, 0, 0)
        self.bg = (255, 255, 255)

    def set_fg(self, rgb):
        self.fg = tuple(rgb[:3])
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        t = T()
        w = self.width()
        chip, step = 16, 16
        left = (w - (chip + step)) // 2   # overlapping pair, centred
        top = 22
        radius = min(3.0, t.radius_sm)
        bg_r = QRect(left, top, chip, chip)
        fg_r = QRect(left + step, top + step, chip, chip)

        def frame(r):
            p.setBrush(Qt.NoBrush)
            light = QColor(t.text)
            light.setAlpha(200)
            p.setPen(QPen(light, 1))
            p.drawRect(r.adjusted(0, 0, -1, -1))
            p.setPen(QPen(QColor(t.field_border), 1))
            p.drawRect(r.adjusted(-1, -1, 0, 0))

        p.setPen(Qt.NoPen)
        p.setBrush(QColor(*self.bg))
        p.drawRect(bg_r)
        frame(bg_r)
        # foreground chip sits on the background one with a chrome-colored gap
        p.setBrush(QColor(t.chrome))
        p.drawRect(fg_r.adjusted(-2, -2, 2, 2))
        p.setBrush(QColor(*self.fg))
        p.drawRect(fg_r)
        frame(fg_r)

        # Default Colors (left) and Switch Colors (right), above the chips
        from . import icons as I
        pm_default = I.pixmap("square", t.icon, 11)
        pm_switch = I.pixmap("rotate-cw", t.icon, 11)
        p.drawPixmap(QRect(max(0, left), 4, 11, 11), pm_default)
        p.drawPixmap(QRect(max(12, left + chip + step - 11), 4, 11, 11), pm_switch)
        p.end()

    def mousePressEvent(self, ev):
        from PySide6.QtWidgets import QColorDialog
        pos = ev.position()
        # top row: default/switch; squares: fg then bg
        if pos.y() < 18:
            x = self.width() // 2 - 16 - 8
            if pos.x() < x + 14:
                self.fg, self.bg = (0, 0, 0), (255, 255, 255)
                self.fg_changed.emit(self.fg + (255,))
            else:
                self.fg, self.bg = self.bg, self.fg
                self.fg_changed.emit(self.fg + (255,))
            self.update()
            return
        fg_r_x = self.width() // 2 - 16
        if pos.x() >= fg_r_x + 14:
            color = QColorDialog.getColor(QColor(*self.bg), self, "Set background color")
            if color.isValid():
                self.bg = (color.red(), color.green(), color.blue())
        else:
            color = QColorDialog.getColor(QColor(*self.fg), self, "Set foreground color")
            if color.isValid():
                self.fg = (color.red(), color.green(), color.blue())
                self.fg_changed.emit(self.fg + (255,))
        self.update()


class Toolbox(QWidget):
    """The 40px Photoshop tool column with chevrons, slots, chips."""

    tool_changed = Signal(str)

    def retint(self):
        """Re-tint every glyph after a theme switch (icons are cached by color)."""
        t = T()
        for btn in set(self.buttons.values()):
            btn._icon_color = t.icon
            btn._update()
        self.update()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(40)
        self.buttons: dict[str, ToolButton] = {}
        self._current = "brush"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(MARGIN, 6, MARGIN, 8)
        lay.setSpacing(3)
        # header chevrons (Photoshop's one/two column switch) — visual only here
        chev = QLabel()
        chev.setPixmap(icons.pixmap("chevrons-right", "#a0a0a0", 11))
        chev.setAlignment(Qt.AlignCenter)
        chev.setFixedHeight(14)
        lay.addWidget(chev)
        lay.addSpacing(2)

        # each group is one slot: the slot shows its current tool
        self._slot_of = {}
        from PySide6.QtWidgets import QFrame
        for gi, group in enumerate(TOOL_SECTIONS):
            default = group[0][0]
            btn = ToolButton(group, default)
            btn.clicked.connect(lambda _=False, b=btn: self._slot_clicked(b))
            lay.addWidget(btn)
            for tid, _label in group:
                self._slot_of[tid] = btn
                self.buttons[tid] = btn
            if gi in SECTION_BREAKS:
                line = QFrame()
                line.setFixedHeight(1)
                line.setStyleSheet(f"background: {T().separator}; margin: 2px 4px;")
                lay.addWidget(line)
        lay.addStretch(1)
        # edit toolbar (visual parity)
        ell = QLabel()
        ell.setPixmap(icons.pixmap("ellipsis", "#a0a0a0", int(BX * 0.52)))
        ell.setAlignment(Qt.AlignCenter)
        ell.setToolTip("Edit Toolbar…")
        lay.addWidget(ell)
        lay.addSpacing(2)
        self.chips = ColorChips()
        self.chips.fg_changed.connect(lambda c: self.tool_changed.emit("__fg__:" + str(c)))
        lay.addWidget(self.chips)
        lay.addSpacing(2)
        screen = QLabel()
        screen.setPixmap(icons.pixmap("app-window", "#a0a0a0", int(BX * 0.52)))
        screen.setAlignment(Qt.AlignCenter)
        screen.setToolTip("Change Screen Mode  (F)")
        lay.addWidget(screen)

        self.buttons["brush"].setChecked(True)

    def _slot_clicked(self, btn):
        if btn.current not in ENABLED_TOOLS:
            first = next((t for t, _ in btn.tools if t in ENABLED_TOOLS), None)
            if first is not None:
                btn.current = first
                btn._update()
        tid = btn.current
        if tid in ENABLED_TOOLS:
            self.tool_changed.emit(tid)

    def set_tool(self, tid, from_user=False):
        if tid not in self.buttons:
            return
        self._current = tid
        btn = self._slot_of[tid]
        if tid in [t for t, _ in btn.tools]:
            btn.set_current(tid)
        for b in set(self.buttons.values()):
            b.setChecked(b is btn)
        if from_user:
            self.tool_changed.emit(tid)

    @property
    def current(self):
        return self._current
