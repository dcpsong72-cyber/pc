"""Theme engine — a faithful port of PhotoCraft's token system
(crates/ui-egui/src/theme.rs, MIT). Pro Medium is the default and is sampled
from Photoshop 2026's default brightness. Colors/radii ALWAYS come from Tokens.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Tokens:
    kind: str
    chrome: str          # window chrome (title bar, toolbars)
    canvas: str          # canvas surround
    canvas_dot: str
    dock: str            # dock background behind cards
    card: str            # cards / panels
    card_border: str
    field: str           # inputs, dropdowns
    field_border: str
    hover: str
    pressed: str
    text: str
    text_dim: str
    text_faint: str
    icon: str
    accent: str
    accent_soft: str
    accent_border: str
    accent_text: str
    separator: str
    primary_bg: str
    primary_text: str
    danger: str
    warning: str
    radius_sm: float
    radius: float
    radius_lg: float
    tab_strip: str
    row_selected: str
    caption_close: str
    caption_close_text: str = "#ffffff"
    mono_for_numbers: bool = True

    # convenience for QSS
    @property
    def pressed2(self):
        return self.pressed


# --------------------------------------------------------------- the themes
PRO = Tokens(
    kind="pro",
    chrome="#323232", canvas="#282828", canvas_dot="#282828",
    dock="#1e1e1e", card="#323232", card_border="#1e1e1e",
    field="#242424", field_border="#4a4a4a", hover="#424242", pressed="#4e4e4e",
    text="#dedede", text_dim="#b2b2b2", text_faint="#808080", icon="#c8c8c8",
    accent="#378ef0", accent_soft="#4e4e4e", accent_border="#378ef0", accent_text="#ffffff",
    separator="#1e1e1e", primary_bg="#378ef0", primary_text="#ffffff",
    danger="#ec5b62", warning="#e8b046", radius_sm=3, radius=4, radius_lg=6,
    tab_strip="#262626", row_selected="#525252", caption_close="#c42b1c",
)

PRO_MEDIUM = Tokens(
    kind="proMedium",
    chrome="#535353", canvas="#282828", canvas_dot="#282828",
    dock="#424242", card="#535353", card_border="#424242",
    field="#454545", field_border="#686868", hover="#626262", pressed="#707070",
    text="#eeeeee", text_dim="#d4d4d4", text_faint="#a0a0a0", icon="#e2e2e2",
    accent="#378ef0", accent_soft="#6e6e6e", accent_border="#378ef0", accent_text="#ffffff",
    separator="#3e3e3e", primary_bg="#378ef0", primary_text="#ffffff",
    danger="#ec5b62", warning="#e8b046", radius_sm=3, radius=4, radius_lg=6,
    tab_strip="#4a4a4a", row_selected="#6b6b6b", caption_close="#c42b1c",
)

STUDIO = Tokens(
    kind="studio",
    chrome="#141415", canvas="#0e0e0f", canvas_dot="#2e2e32",
    dock="#111112", card="#1a1a1c", card_border="#28282c",
    field="#232326", field_border="#343439", hover="#2c2c30", pressed="#38383e",
    text="#ec ec ec".replace(" ", ""), text_dim="#96969e", text_faint="#606068", icon="#c4c4cc",
    accent="#8b7cf6", accent_soft="#2e8b7cf6", accent_border="#6ea094ff", accent_text="#d6d0ff",
    separator="#26262a", primary_bg="#f6f6f8", primary_text="#0c0c0e",
    danger="#f06060", warning="#f0be5a", radius_sm=6, radius=8, radius_lg=12,
    tab_strip="#141415", row_selected="#232326", caption_close="#c42b1c",
)

STUDIO_LIGHT = Tokens(
    kind="studioLight",
    chrome="#f6f6f8", canvas="#e2e2e6", canvas_dot="#c8c8ce",
    dock="#f0f0f3", card="#fcfcfd", card_border="#dedee4",
    field="#f2f2f5", field_border="#d6d6dc", hover="#e8e8ed", pressed="#dcdce2",
    text="#18181c", text_dim="#60606a", text_faint="#9696a0", icon="#3c3c44",
    accent="#6c5ce7", accent_soft="#246c5ce7", accent_border="#786c5ce7", accent_text="#ffffff",
    separator="#e2e2e8", primary_bg="#141418", primary_text="#fafafc",
    danger="#d23c3c", warning="#be8214", radius_sm=6, radius=8, radius_lg=12,
    tab_strip="#f6f6f8", row_selected="#ececf1", caption_close="#c42b1c",
)

SOLARIZED_DARK = Tokens(
    kind="solarizedDark",
    chrome="#073642", canvas="#002b36", canvas_dot="#0a3d4a",
    dock="#00252f", card="#073642", card_border="#00252f",
    field="#00252f", field_border="#15505f", hover="#0e4a5a", pressed="#12596b",
    text="#839496", text_dim="#657b83", text_faint="#586e75", icon="#93a1a1",
    accent="#268bd2", accent_soft="#2e268bd2", accent_border="#78268bd2", accent_text="#fdf6e3",
    separator="#00252f", primary_bg="#268bd2", primary_text="#fdf6e3",
    danger="#dc322f", warning="#b58900", radius_sm=6, radius=8, radius_lg=12,
    tab_strip="#073642", row_selected="#0e4a5a", caption_close="#dc322f",
    caption_close_text="#fdf6e3",
)

AMOLED = Tokens(
    kind="amoled",
    chrome="#000000", canvas="#000000", canvas_dot="#1f1f1f",
    dock="#000000", card="#0a0a0a", card_border="#1c1c1c",
    field="#101010", field_border="#2e2e2e", hover="#1d1d1d", pressed="#262626",
    text="#eeeeee", text_dim="#d4d4d4", text_faint="#9a9a9a", icon="#e2e2e2",
    accent="#378ef0", accent_soft="#1f1f1f", accent_border="#378ef0", accent_text="#ffffff",
    separator="#1a1a1a", primary_bg="#378ef0", primary_text="#ffffff",
    danger="#ec5b62", warning="#e8b046", radius_sm=3, radius=4, radius_lg=6,
    tab_strip="#050505", row_selected="#2a2a2a", caption_close="#c42b1c",
)

THEMES = {t.kind: t for t in (AMOLED, PRO, PRO_MEDIUM, STUDIO, STUDIO_LIGHT, SOLARIZED_DARK)}
THEME_LABELS = {
    "amoled": "AMOLED (true black)",
    "proMedium": "Pro Medium (Photoshop default)",
    "pro": "Pro (Photoshop dark)",
    "studio": "Studio",
    "studioLight": "Studio Light",
    "solarizedDark": "Solarized Dark",
}

_current: Tokens = AMOLED


def current() -> Tokens:
    """Live accessor: T() always reflects the active theme."""
    return _current


def set_theme(kind: str) -> Tokens:
    global _current
    _current = THEMES.get(kind, AMOLED)
    return _current


def qss(t: Tokens) -> str:
    """Global stylesheet built ONLY from tokens (their rule #1)."""
    return f"""
* {{
    font-size: 12px;
    color: {t.text};
    selection-background-color: {t.accent};
    selection-color: {t.accent_text};
}}
QWidget {{ background: {t.chrome}; }}
QMainWindow::separator {{ background: {t.separator}; width: 3px; height: 3px; }}
QMenuBar {{ background: {t.chrome}; border: none; padding: 0; }}
QMenuBar::item {{ padding: 5px 9px; background: transparent; border-radius: {int(t.radius_sm)}px; }}
QMenuBar::item:selected {{ background: {t.hover}; }}
QMenu {{
    background: {t.card}; border: 1px solid {t.field_border};
    border-radius: {int(t.radius)}px; padding: 4px;
}}
QMenu::item {{ padding: 5px 26px 5px 14px; border-radius: {int(t.radius_sm)}px; background: transparent; }}
QMenu::item:selected {{ background: {t.hover}; color: {t.text}; }}
QMenu::item:disabled {{ color: {t.text_faint}; }}
QMenu::separator {{ height: 1px; background: {t.separator}; margin: 4px 8px; }}
QMenu::indicator {{ width: 13px; height: 13px; margin-left: 3px; }}

QDockWidget {{ titlebar-close-icon: none; font-weight: 600; }}
QDockWidget::title {{
    background: {t.card}; border-bottom: 1px solid {t.card_border};
    padding: 6px 8px;
}}

QToolBar {{ background: {t.chrome}; border: none; spacing: 2px; padding: 3px; }}
QToolButton {{
    background: transparent; border: 1px solid transparent;
    border-radius: {int(t.radius_sm)}px; padding: 5px; color: {t.icon};
}}
QToolButton:hover {{ background: {t.hover}; color: {t.text}; }}
QToolButton:checked {{ background: {t.accent_soft}; border-color: {t.accent_border}; color: {t.accent_text}; }}

QTabWidget::pane {{ border: 1px solid {t.card_border}; background: {t.card}; top: -1px; }}
QTabWidget {{ background: {t.card}; }}
QTabBar {{ background: {t.tab_strip}; }}
QTabBar::tab {{
    background: {t.tab_strip}; color: {t.text_dim};
    border: 1px solid {t.card_border}; border-bottom: none;
    padding: 5px 12px; margin-right: 1px;
    border-top-left-radius: {int(t.radius_sm)}px; border-top-right-radius: {int(t.radius_sm)}px;
}}
QTabBar::tab:selected {{ background: {t.card}; color: {t.text}; }}
QTabBar::tab:hover:!selected {{ background: {t.hover}; }}
QTabBar::tab:disabled {{ color: {t.text_faint}; }}

QTreeWidget, QListWidget, QListView {{
    background: {t.card}; border: 1px solid {t.card_border};
    outline: none; alternate-background-color: {t.card};
}}
QTreeWidget::item, QListWidget::item {{ padding: 3px 4px; border-radius: {int(t.radius_sm)}px; }}
QTreeWidget::item:selected, QListWidget::item:selected {{ background: {t.row_selected}; color: {t.text}; }}
QTreeWidget::item:hover:!selected, QListWidget::item:hover:!selected {{ background: {t.hover}; }}

QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit {{
    background: {t.field}; border: 1px solid {t.field_border};
    border-radius: {int(t.radius_sm)}px; padding: 3px 6px;
}}
QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
    background: {t.field}; border: none; width: 14px;
}}
QComboBox::drop-down {{ border: none; width: 18px; }}
QComboBox QAbstractItemView {{
    background: {t.card}; border: 1px solid {t.field_border};
    selection-background-color: {t.hover}; selection-color: {t.text};
}}
QPushButton {{
    background: {t.field}; border: 1px solid {t.field_border};
    border-radius: {int(t.radius_sm)}px; padding: 4px 12px; color: {t.text};
}}
QPushButton:hover {{ background: {t.hover}; }}
QPushButton:pressed {{ background: {t.pressed}; }}
QPushButton:default {{ background: {t.primary_bg}; color: {t.primary_text}; border-color: {t.primary_bg}; }}
QPushButton:default:hover {{ background: {t.accent}; }}

QSlider::groove:horizontal {{ height: 4px; background: {t.field}; border-radius: 2px; }}
QSlider::handle:horizontal {{
    background: {t.text_dim}; width: 12px; margin: -5px 0; border-radius: 6px;
}}
QSlider::handle:horizontal:hover {{ background: {t.text}; }}

QStatusBar {{ background: {t.chrome}; border-top: 1px solid {t.separator}; color: {t.text_dim}; }}
QToolTip {{ background: {t.field}; color: {t.text}; border: 1px solid {t.field_border}; padding: 4px; border-radius: {int(t.radius_sm)}px; }}
QScrollBar:vertical {{ background: {t.dock}; width: 10px; }}
QScrollBar::handle:vertical {{ background: {t.field_border}; border-radius: 3px; min-height: 24px; }}
QScrollBar::handle:vertical:hover {{ background: {t.text_faint}; }}
QScrollBar:horizontal {{ background: {t.dock}; height: 10px; }}
QScrollBar::handle:horizontal {{ background: {t.field_border}; border-radius: 3px; min-width: 24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QCheckBox::indicator {{ width: 13px; height: 13px; border: 1px solid {t.field_border};
    border-radius: 3px; background: {t.field}; }}
QCheckBox::indicator:checked {{ background: {t.accent}; border-color: {t.accent}; }}
QGroupBox {{
    border: 1px solid {t.card_border}; border-radius: {int(t.radius)}px;
    margin-top: 8px; background: {t.card}; font-weight: 600;
}}
QGroupBox::title {{ subcontrol-origin: margin; left: 8px; padding: 0 4px; color: {t.text_dim}; }}
QLabel#optionsLabel {{ color: {t.text_faint}; }}
QSplitter::handle {{ background: {t.separator}; }}
"""


def apply_palette(app, t):
    """Token-driven QPalette under the QSS — Fusion paints QTabBar bases,
    viewports and popup chrome from the palette, not the stylesheet."""
    from PySide6.QtGui import QPalette, QColor
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(t.chrome))
    pal.setColor(QPalette.WindowText, QColor(t.text))
    pal.setColor(QPalette.Base, QColor(t.field))
    pal.setColor(QPalette.AlternateBase, QColor(t.card))
    pal.setColor(QPalette.Button, QColor(t.card))
    pal.setColor(QPalette.ButtonText, QColor(t.text))
    pal.setColor(QPalette.ToolTipBase, QColor(t.card))
    pal.setColor(QPalette.ToolTipText, QColor(t.text))
    pal.setColor(QPalette.Highlight, QColor(t.accent))
    pal.setColor(QPalette.HighlightedText, QColor(t.accent_text))
    pal.setColor(QPalette.Link, QColor(t.accent))
    pal.setColor(QPalette.PlaceholderText, QColor(t.text_faint))
    pal.setColor(QPalette.Light, QColor(t.hover))
    pal.setColor(QPalette.Midlight, QColor(t.hover))
    pal.setColor(QPalette.Dark, QColor(t.pressed))
    pal.setColor(QPalette.Mid, QColor(t.card_border))
    pal.setColor(QPalette.Shadow, QColor(t.card_border))
    pal.setColor(QPalette.Disabled, QPalette.WindowText, QColor(t.text_faint))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(t.text_faint))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor(t.text_faint))
    pal.setColor(QPalette.Disabled, QPalette.Base, QColor(t.card))
    app.setPalette(pal)


def apply_theme(app, kind: str = "proMedium"):
    """Set the theme and refresh palette + global stylesheet + fonts."""
    from PySide6.QtGui import QFont, QFontDatabase
    import os
    t = set_theme(kind)
    # bundled UI fonts: Inter + JetBrains Mono (OFL), like PhotoCraft
    fonts_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "fonts")
    if os.path.isdir(fonts_dir):
        for f in os.listdir(fonts_dir):
            if f.lower().endswith((".ttf", ".otf")):
                QFontDatabase.addApplicationFont(os.path.join(fonts_dir, f))
    app.setStyle("Fusion")
    app.setFont(QFont("Inter", 9))
    apply_palette(app, t)
    app.setStyleSheet(qss(t))
    return t
