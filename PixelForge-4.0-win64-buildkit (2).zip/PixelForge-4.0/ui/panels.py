"""Panels v2: Layers tree (visibility, masks, fx badges), History, Color,
Adjustments grid, Brand palette."""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPixmap, QIcon
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTreeWidget,
                               QTreeWidgetItem, QComboBox, QSlider, QLabel,
                               QPushButton, QToolButton, QGridLayout, QSizePolicy,
                               QLineEdit, QInputDialog, QMessageBox, QFileDialog)

from pf import color as C
from . import icons as lx
from pf.doc import (AdjustmentLayer, GroupLayer, PixelLayer, ShapeLayer, TextLayer)

THUMB = 24


def make_thumb(layer) -> QPixmap:
    """Checkerboard + content thumbnail (pixel, or rasterized live layer)."""
    px = None
    if isinstance(layer, PixelLayer):
        px = layer.pixels
    else:
        from pf import compose
        r = compose._rasterize_live(layer)
        px = r[0] if r else None
    if px is None or px.ndim != 3 or px.shape[0] == 0:
        return QPixmap()
    scale = min(THUMB / px.shape[1], THUMB / px.shape[0], 1.0)
    w, h = max(1, int(px.shape[1] * scale)), max(1, int(px.shape[0] * scale))
    img = QImage(px.data, px.shape[1], px.shape[0], px.shape[1] * 4, QImage.Format_RGBA8888)
    img = img.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    base = QPixmap(THUMB, THUMB)
    base.fill(QColor("#707070"))
    p = QPainter(base)
    p.fillRect(0, 0, THUMB // 2, THUMB // 2, QColor("#999"))
    p.fillRect(THUMB // 2, THUMB // 2, THUMB // 2, THUMB // 2, QColor("#999"))
    p.drawPixmap((THUMB - w) // 2, (THUMB - h) // 2, QPixmap.fromImage(img))
    p.end()
    return base


ADJ_ICONS = {
    "brightness_contrast": "◐", "levels": "▤", "curves": "∿", "exposure": "☀",
    "hue_sat": "🌈", "vibrance": "✦", "temperature": "🌡", "invert": "◔",
    "threshold": "◑", "posterize": "▦", "bw": "⬜", "photo_filter": "🔶",
    "gradient_map": "_", "black_white": "⬜",
}


class LayersPanel(QWidget):
    changed = Signal()
    edit_text_requested = Signal(str)
    edit_adjustment_requested = Signal(str)
    layer_style_requested = Signal(str)

    def __init__(self, session, parent=None):
        super().__init__(parent)
        self.session = session
        self._syncing = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(6)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Blend"))
        self.blend = QComboBox()
        self.blend.addItems(C.BLEND_MODES)
        row1.addWidget(self.blend, 1)
        lay.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Opacity"))
        self.opacity = QSlider(Qt.Horizontal)
        self.opacity.setRange(0, 100)
        self.opacity_spin = QLabel("100%")
        row2.addWidget(self.opacity, 1)
        row2.addWidget(self.opacity_spin)
        lay.addLayout(row2)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setIndentation(12)
        self.tree.setIconSize(QPixmap(THUMB, THUMB).size())
        lay.addWidget(self.tree, 1)

        row3 = QHBoxLayout()
        def btn(text, tip, cb):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.setFixedWidth(30)
            b.clicked.connect(cb)
            row3.addWidget(b)
            return b
        from .theme import current as T
        t = T()
        def ibtn(name, tip, cb):
            b = QToolButton()
            b.setToolTip(tip)
            b.setFixedSize(30, 26)
            b.setIcon(lx.icon(name, t.icon, 15))
            b.setIconSize(lx.pixmap(name, t.icon, 15).size())
            b.clicked.connect(cb)
            row3.addWidget(b)
            return b
        ibtn("plus", "New layer", lambda: self._run("layer.add"))
        ibtn("copy", "Duplicate", lambda: self._run("layer.duplicate"))
        ibtn("trash", "Delete layer", lambda: self._run("layer.remove"))
        ibtn("chevron-up", "Bring forward", lambda: self._move(+1))
        ibtn("chevron-down", "Send backward", lambda: self._move(-1))
        ibtn("layer-mask", "Add mask", lambda: self._run("layer.mask.new", mode="reveal"))
        ibtn("sparkles", "Layer style", self._style)
        row3.addStretch(1)
        lay.addLayout(row3)

        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._row_changed)
        self.tree.itemDoubleClicked.connect(self._dbl)
        session.on("doc", self.sync)
        session.on("history", self.sync)

    # ------------------------------------------------------------ actions
    def _run(self, cmd, **params):
        try:
            self.session.execute(cmd, **params)
            self.changed.emit()
        except Exception:
            pass

    def _style(self):
        doc = self.session.doc
        if doc and doc.active_uid:
            self.layer_style_requested.emit(doc.active_uid)

    def _move(self, delta):
        doc = self.session.doc
        if doc is None or doc.active_uid is None:
            return
        try:
            idx = [l.uid for l in doc.layers].index(doc.active_uid)
            self._run("layer.reorder", uid=doc.active_uid, to_flat_index=idx + delta)
        except ValueError:
            pass

    def _dbl(self, item, col):
        uid = item.data(0, Qt.UserRole)
        layer = self.session.doc.find(uid) if self.session.doc else None
        if isinstance(layer, TextLayer):
            self.edit_text_requested.emit(uid)
        elif isinstance(layer, AdjustmentLayer):
            self.edit_adjustment_requested.emit(uid)
        elif isinstance(layer, PixelLayer) and layer.mask is not None:
            pass

    # ----------------------------------------------------------- handlers
    def _blend_changed(self, mode):
        if self._syncing:
            return
        doc = self.session.doc
        if doc and doc.active_uid:
            self._run("layer.setProps", uid=doc.active_uid, blend=mode)

    def _opacity_changed(self, v):
        self.opacity_spin.setText(f"{v}%")
        if self._syncing:
            return
        doc = self.session.doc
        if doc and doc.active_uid:
            self._run("layer.setProps", uid=doc.active_uid, opacity=v / 100.0)

    def _row_changed(self, cur, _prev):
        if self._syncing or cur is None:
            return
        doc = self.session.doc
        uid = cur.data(0, Qt.UserRole)
        if doc is not None and uid and doc.active_uid != uid:
            self.session.execute("layer.select", uid=uid)

    def _item_changed(self, item, col):
        if self._syncing:
            return
        doc = self.session.doc
        uid = item.data(0, Qt.UserRole)
        layer = doc.find(uid) if doc else None
        if layer is None:
            return
        if item.checkState(0) != (Qt.Checked if layer.visible else Qt.Unchecked):
            self._run("layer.setProps", uid=uid, visible=item.checkState(0) == Qt.Checked)
            return

    # ---------------------------------------------------------------- sync
    def sync(self):
        doc = self.session.doc
        self._syncing = True
        try:
            self.tree.clear()
            if doc is None:
                self.blend.setEnabled(False)
                self.opacity.setEnabled(False)
                return
            self.blend.setEnabled(True)
            self.opacity.setEnabled(True)

            def add(layers, parent_item):
                for layer in reversed(layers):   # top first in the UI
                    item = QTreeWidgetItem()
                    item.setText(0, self._label(layer))
                    item.setIcon(0, make_thumb(layer))
                    item.setData(0, Qt.UserRole, layer.uid)
                    item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                    item.setCheckState(0, Qt.Checked if layer.visible else Qt.Unchecked)
                    badges = ""
                    if layer.effects:
                        badges += " fx"
                    if layer.mask is not None:
                        badges += " ⬛"
                    if badges:
                        item.setText(0, item.text(0) + badges)
                    if isinstance(layer, GroupLayer):
                        item.setText(0, ("🗂 " if True else "") + item.text(0))
                        add(layer.children, item)
                    if parent_item is None:
                        self.tree.addTopLevelItem(item)
                    else:
                        parent_item.addChild(item)
                    if layer.uid == doc.active_uid:
                        self.tree.setCurrentItem(item)

            add(doc.layers, None)
            active = doc.active
            if active is not None:
                bi = self.blend.findText(active.blend)
                self.blend.setCurrentIndex(max(0, bi))
                op = int(round(active.opacity * 100))
                self.opacity.setValue(op)
                self.opacity_spin.setText(f"{op}%")
        finally:
            self._syncing = False

    @staticmethod
    def _label(layer) -> str:
        if isinstance(layer, AdjustmentLayer):
            return layer.name
        if isinstance(layer, TextLayer):
            t = str(layer.params.get("text", "")).split("\n")[0][:18]
            return f"T {t}"
        if isinstance(layer, ShapeLayer):
            return f"◼ {layer.name}"
        return layer.name


class HistoryPanel(QWidget):
    def __init__(self, session, parent=None):
        super().__init__(parent)
        self.session = session
        self._syncing = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        self.list = QTreeWidget()
        self.list.setHeaderHidden(True)
        lay.addWidget(self.list, 1)
        self.list.itemClicked.connect(self._clicked)
        session.on("history", self.sync)
        session.on("doc", self.sync)

    def sync(self):
        self._syncing = True
        try:
            self.list.clear()
            for label in self.session.history_labels():
                QTreeWidgetItem(self.list, [label])
            if self.list.topLevelItemCount():
                self.list.setCurrentItem(self.list.topLevelItem(self.list.topLevelItemCount() - 1))
        finally:
            self._syncing = False

    def _clicked(self, item, _col):
        if self._syncing:
            return
        row = self.list.indexOfTopLevelItem(item)
        target = row + 1 - len(self.session.undo_stack)
        for _ in range(-target):
            self.session.undo()
        for _ in range(target):
            self.session.redo()


class ColorPanel(QWidget):
    fg_changed = Signal(tuple)

    def __init__(self, session, parent=None):
        super().__init__(parent)
        self.fg = (0, 0, 0, 255)
        self.bg = (255, 255, 255, 255)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        self.fg_btn = QToolButton()
        self.bg_btn = QToolButton()
        for b in (self.fg_btn, self.bg_btn):
            b.setFixedSize(34, 34)
        self.fg_btn.clicked.connect(lambda: self._pick("fg"))
        self.bg_btn.clicked.connect(lambda: self._pick("bg"))
        lay.addWidget(self.fg_btn)
        lay.addWidget(self.bg_btn)
        lay.addStretch(1)
        self._refresh()

    def _pick(self, which):
        from PySide6.QtWidgets import QColorDialog
        current = getattr(self, which)
        color = QColorDialog.getColor(QColor(*current[:3]), self, "Pick color")
        if color.isValid():
            setattr(self, which, (color.red(), color.green(), color.blue(), 255))
            self._refresh()
            if which == "fg":
                self.fg_changed.emit(self.fg)

    def set_fg(self, rgba):
        self.fg = tuple(rgba)
        self._refresh()

    def _refresh(self):
        for btn, rgba in ((self.fg_btn, self.fg), (self.bg_btn, self.bg)):
            pm = QPixmap(28, 28)
            pm.fill(QColor(*rgba[:3]))
            btn.setIcon(pm)
            btn.setIconSize(pm.size())


class AdjustmentsPanel(QWidget):
    """Canva/Photoshop-style adjustments grid: click to add a live layer."""
    add_requested = Signal(str)

    KINDS = ["brightness_contrast", "levels", "curves", "exposure", "hue_sat",
             "vibrance", "temperature", "invert", "threshold", "posterize",
             "bw", "photo_filter", "gradient_map",
             "clarity", "dehaze", "grain"]

    def __init__(self, session, parent=None):
        super().__init__(parent)
        lay = QGridLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)
        from .theme import current as T
        t = T()
        icons = {"brightness_contrast": "contrast", "levels": "sliders-horizontal",
                 "curves": "spline", "exposure": "sun", "hue_sat": "palette",
                 "vibrance": "sparkles", "temperature": "flame", "invert": "circle-dashed",
                 "threshold": "circle-dot", "posterize": "grid-3x3", "bw": "moon",
                 "photo_filter": "image", "gradient_map": "align-justify"}
        from pf.doc import ADJUSTMENT_KINDS
        for i, kind in enumerate(self.KINDS):
            b = QToolButton()
            b.setIcon(lx.icon(icons.get(kind, "wand-sparkles"), t.icon, 16))
            b.setIconSize(lx.pixmap(icons.get(kind, "wand-sparkles"), t.icon, 16).size())
            b.setToolTip(ADJUSTMENT_KINDS[kind])
            b.setFixedSize(34, 30)
            b.clicked.connect(lambda _=False, k=kind: self.add_requested.emit(k))
            lay.addWidget(b, i // 5, i % 5)


class BrandPanel(QWidget):
    """Saved palettes (persisted via QSettings by the main window)."""
    color_picked = Signal(tuple)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(8, 4, 8, 4)
        self._layout.setSpacing(4)
        self.set_colors([])

    def set_colors(self, colors):
        while self._layout.count():
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for c in colors[:14]:
            b = QToolButton()
            b.setFixedSize(20, 20)
            pm = QPixmap(16, 16)
            pm.fill(QColor(*c))
            b.setIcon(pm)
            b.setIconSize(pm.size())
            b.setToolTip(f"#{c[0]:02x}{c[1]:02x}{c[2]:02x}")
            b.clicked.connect(lambda _=False, cc=tuple(c): self.color_picked.emit(cc))
            self._layout.addWidget(b)
        self._layout.addStretch(1)

def _gray_thumb(arr, size=44):
    from PySide6.QtGui import QImage, QPixmap
    h, w = arr.shape[:2]
    img = QImage(arr.tobytes(), w, h, w, QImage.Format_Grayscale8)
    return QPixmap.fromImage(img).scaled(size, size, Qt.KeepAspectRatio,
                                         Qt.SmoothTransformation)


class ChannelsPanel(QWidget):
    """Live RGB(A) channels of the composite: click to view a channel in
    grayscale, Ctrl+click to load its luminance as a selection."""

    def __init__(self, session, parent=None):
        super().__init__(parent)
        self.session = session
        self.canvas = None  # set by the main window
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(2)
        self._rows = []
        from pf import compose as _c
        for name in ("RGB", "Red", "Green", "Blue", "Alpha"):
            b = QToolButton()
            b.setText(name)
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setFixedHeight(30)
            b.clicked.connect(lambda _=False, n=name: self._clicked(n))
            lay.addWidget(b)
            self._rows.append(b)
        lay.addStretch(1)
        self._thumbs = {}
        session.on("doc", self._sync)
        self._sync()

    def _sync(self, **_):
        from pf import compose as _c
        doc = self.session.doc
        if doc is None:
            for b in self._rows:
                b.setIcon(QIcon())
            return
        comp = _c.composite_rgba8(doc)
        if comp is None:
            return
        import numpy as np
        gray = (comp[..., :3].mean(-1)).astype(np.uint8)
        chans = {"RGB": gray, "Red": comp[..., 0], "Green": comp[..., 1],
                 "Blue": comp[..., 2], "Alpha": comp[..., 3]}
        for b in self._rows:
            arr = chans[b.text()]
            if arr.dtype != np.uint8:
                arr = arr.astype(np.uint8)
            small = arr[::max(1, arr.shape[0] // 44), ::max(1, arr.shape[1] // 44)]
            b.setIcon(QIcon(_gray_thumb(np.ascontiguousarray(small))))
            b.setIconSize(QPixmap(20, 20).size())

    def _clicked(self, name):
        import numpy as np
        from PySide6.QtGui import QGuiApplication
        ctrl = bool(QGuiApplication.keyboardModifiers() & Qt.ControlModifier)
        win = self.window()
        canvas = getattr(win, "canvas", None)
        if canvas is None or self.session.doc is None:
            return
        if ctrl:
            from pf import compose as _c
            comp = _c.composite_rgba8(self.session.doc)
            ch = {"Red": 0, "Green": 1, "Blue": 2, "Alpha": 3}.get(name)
            if ch is None:
                return
            lum = comp[..., ch] > 127
            self.session.execute("selection.setMask", mask=lum)
            self.session.emit("doc")
        else:
            key = {"Red": "r", "Green": "g", "Blue": "b", "Alpha": "a", "RGB": None}[name]
            canvas.display_channel = key
            canvas.update()


class PathsPanel(QWidget):
    """Vector paths drawn with the Pen tool: load as selection, delete."""

    def __init__(self, win, parent=None):
        super().__init__(parent)
        self.win = win
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)
        self.list = QTreeWidget()
        self.list.setHeaderHidden(True)
        self.list.setRootIsDecorated(False)
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        from .theme import current as T
        from . import icons as lx
        t = T()
        def ibtn(name, tip, cb):
            b = QToolButton()
            b.setToolTip(tip)
            b.setIcon(lx.icon(name, t.icon, 15))
            b.clicked.connect(cb)
            row.addWidget(b)
            return b
        ibtn("wand-sparkles", "Load path as selection", self._load_sel)
        ibtn("trash", "Delete path", self._del)
        row.addStretch(1)
        lay.addLayout(row)
        win.paths_changed.append(self.sync)
        self.sync()

    def sync(self):
        self.list.clear()
        for p in getattr(self.win, "paths", []):
            it = QTreeWidgetItem([f"{p['name']}  ({len(p['points'])} pts)"])
            self.list.addTopLevelItem(it)
        if getattr(self.win, "paths", []):
            self.list.setCurrentItem(self.list.topLevelItem(self.win._active_path))

    def _current(self):
        it = self.list.currentItem()
        i = self.list.indexOfTopLevelItem(it) if it is not None else -1
        if 0 <= i < len(self.win.paths):
            self.win._active_path = i
            return i
        return None

    def _load_sel(self):
        i = self._current()
        if i is None:
            return
        pts = [tuple(p) for p in self.win.paths[i]["points"]]
        if len(pts) >= 3:
            self.win.session.execute("selection.polygon", points=pts)
            self.win.canvas.invalidate()

    def _del(self):
        i = self._current()
        if i is None:
            return
        self.win.paths.pop(i)
        self.win._active_path = max(0, min(self.win._active_path, len(self.win.paths) - 1))
        self.win.paths_changed_notify()
        self.sync()


class ActionsPanel(QWidget):
    """Photoshop 27.11-style Actions panel: record / stop / play engine
    command sets, natural-language search, Batch hand-off."""

    played = Signal(str)
    record_toggled = Signal(bool)

    def __init__(self, session, win=None, parent=None):
        super().__init__(parent)
        from pf import actions as ACT
        self.session = session
        self.win = win
        self.ACT = ACT
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)

        self.search = QLineEdit()
        self.search.setPlaceholderText('Search actions — try "smooth skin" or "product"')
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.sync)
        lay.addWidget(self.search)

        self.list = QTreeWidget()
        self.list.setHeaderHidden(True)
        self.list.itemDoubleClicked.connect(lambda *_: self.play_selected())
        lay.addWidget(self.list, 1)

        row = QHBoxLayout()
        row.setSpacing(4)
        self.rec_btn = QPushButton("● Record")
        self.rec_btn.setCheckable(True)
        self.rec_btn.setToolTip("Record every command you run into a new action set")
        self.rec_btn.toggled.connect(self._toggle_record)
        self.play_btn = QPushButton("▶ Play")
        self.play_btn.clicked.connect(self.play_selected)
        self.new_btn = QPushButton("New Set")
        self.new_btn.clicked.connect(self._new_set)
        self.del_btn = QPushButton("Delete")
        self.del_btn.clicked.connect(self._delete_set)
        for b in (self.rec_btn, self.play_btn, self.new_btn, self.del_btn):
            row.addWidget(b)
        lay.addLayout(row)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self.sync()

    # ------------------------------------------------------------- sync
    def sync(self):
        self.list.clear()
        query = self.search.text().strip()
        scored = []
        for name in self.ACT.list_sets():
            s = self.ACT.search_score(query, name)
            if s > 0:
                scored.append((s, name))
        scored.sort(key=lambda t: (-t[0], t[1].lower()))
        for score, name in scored:
            top = QTreeWidgetItem([f"▸ {name}"])
            top.setData(0, Qt.UserRole, name)
            self.list.addTopLevelItem(top)
            if query:  # expanded while searching to show why it matched
                top.setExpanded(True)
            try:
                steps = self.ACT.load_set(name)
            except Exception:
                continue
            for i, st in enumerate(steps, 1):
                params = ", ".join(f"{k}={v}" for k, v in (st.get("params") or {}).items())
                child = QTreeWidgetItem([f"{i}. {st.get('cmd','?').split('.')[-1]}  {params}"])
                child.setDisabled(True)
                top.addChild(child)
            note = QTreeWidgetItem([self.ACT.describe_set(name)])
            note.setDisabled(True)
            top.addChild(note)

    # ------------------------------------------------------------- record
    def _toggle_record(self, on):
        if on:
            self.session.record_buffer = []
            self.session.recording = True
            self.rec_btn.setText("■ Stop")
            self.status.setText("Recording — every command you run is captured. "
                                "Press Stop to save the set.")
        else:
            self.session.recording = False
            self.rec_btn.setText("● Record")
            steps = list(self.session.record_buffer)
            if steps:
                self._save_recorded(steps)
            else:
                self.status.setText("Nothing recorded.")
        self.record_toggled.emit(self.session.recording)

    def _save_recorded(self, steps):
        default = f"My Action {len(self.ACT.list_sets()) + 1}"
        name, ok = QInputDialog.getText(self, "Save Action Set",
                                        "Name for the recorded action set:", text=default)
        if not ok or not name.strip():
            self.status.setText("Recording discarded.")
            return
        self.ACT.save_set(name.strip(), steps)
        self.status.setText(f'Saved "{name.strip()}" ({len(steps)} steps). Select it and press Play.')
        self.sync()

    # ------------------------------------------------------------- play / sets
    def _current_name(self):
        it = self.list.currentItem()
        while it is not None:
            name = it.data(0, Qt.UserRole)
            if name:
                return name
            it = it.parent()
        return None

    def play_selected(self):
        name = self._current_name()
        if name is None:
            self.status.setText("Select an action set first.")
            return
        return self.play_set(name)

    def play_set(self, name):
        try:
            steps = self.ACT.load_set(name)
        except Exception as exc:
            self.status.setText(f"Cannot load '{name}': {exc}")
            return 0, [str(exc)]
        applied, errors = self.ACT.run_steps(self.session, steps)
        self.status.setText(f"Played '{name}': {applied} step(s) applied"
                            + (f", {len(errors)} skipped" if errors else ""))
        self.played.emit(name)
        return applied, errors

    def _new_set(self):
        name, ok = QInputDialog.getText(self, "New Action Set", "Set name:")
        if not ok or not name.strip():
            return
        self.ACT.save_set(name.strip(), [])
        self.sync()

    def _delete_set(self):
        name = self._current_name()
        if name is None:
            return
        if QMessageBox.question(self, "Delete Action Set",
                                f"Delete '{name}'?") != QMessageBox.Yes:
            return
        self.ACT.delete_set(name)
        self.sync()
