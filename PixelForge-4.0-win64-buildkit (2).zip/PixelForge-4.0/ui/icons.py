"""Lucide icon system — the same ISC-licensed SVGs PhotoCraft embeds
(assets/icons, ISC licence kept alongside), tinted at runtime like their
`icons.rs`. QIcon/QPixmap cache keyed by (name, color, size)."""

from __future__ import annotations

import os

from PySide6.QtCore import QByteArray, QRectF, Qt
from PySide6.QtGui import QIcon, QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

ICON_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "icons")

_CACHE: dict = {}
_SVG: dict = {}


def _svg_bytes(name: str, color: str) -> QByteArray:
    key = (name, color)
    if key not in _SVG:
        path = os.path.join(ICON_DIR, name + ".svg")
        with open(path, "r", encoding="utf-8") as f:
            svg = f.read()
        svg = svg.replace('stroke="currentColor"', f'stroke="{color}"')
        _SVG[key] = QByteArray(svg.encode("utf-8"))
    return _SVG[key]


def pixmap(name: str, color: str = "#e2e2e2", size: int = 16) -> QPixmap:
    key = ("pm", name, color, size)
    if key not in _CACHE:
        img = QImage(size, size, QImage.Format_ARGB32_Premultiplied)
        img.fill(Qt.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        renderer = QSvgRenderer(_svg_bytes(name, color))
        renderer.render(p, QRectF(0, 0, size, size))
        p.end()
        _CACHE[key] = QPixmap.fromImage(img)
    return _CACHE[key]


def icon(name: str, color: str = "#e2e2e2", size: int = 16) -> QIcon:
    key = ("ic", name, color, size)
    if key not in _CACHE:
        _CACHE[key] = QIcon(pixmap(name, color, size))
    return _CACHE[key]


def has(name: str) -> bool:
    return os.path.exists(os.path.join(ICON_DIR, name + ".svg"))


# PhotoCraft's tool -> Lucide icon table (MIT, crates/ui-egui/src/icons.rs)
TOOL_ICONS = {
    # their exact tool -> Lucide mapping (crates/ui-egui/src/icons.rs)
    "move": "move",
    "marquee": "square-dashed", "ellipse_marquee": "circle-dashed",
    "lasso": "lasso", "lasso_poly": "pentagon", "lasso_magnetic": "lasso-magnetic",
    "objsel": "square-dashed-mouse-pointer", "quicksel": "circle-dashed", "wand": "wand-sparkles",
    "crop": "crop", "slice": "slice-knife", "sliceselect": "square-dashed-mouse-pointer",
    "eyedropper": "pipette", "ruler": "ruler", "note": "message-square", "count": "circle-dot",
    "spotheal": "bandage", "heal": "bandage", "patch": "lasso-select",
    "camove": "arrow-left-right", "redeye": "eye",
    "brush": "brush", "pencil": "pencil", "mixer": "palette",
    "clone": "stamp", "patternstamp": "grid-3x3",
    "historybrush": "clock",
    "eraser": "eraser", "bgeraser": "eraser-background", "magiceraser": "eraser-magic",
    "gradient": "blend", "bucket": "paint-bucket",
    "blur": "droplet", "sharpen": "triangle", "smudge": "pointer",
    "dodge": "lollipop", "burn": "flame", "sponge": "cloud",
    "pen": "pen-tool",
    "text": "type", "text_vert": "type",
    "pathsel": "mouse-pointer-2", "directsel": "direct-select",
    "shape_rect": "rectangle-horizontal", "shape_ellipse": "circle", "shape_triangle": "triangle",
    "shape_polygon": "pentagon", "shape_line": "slash", "shape_custom": "cloud",
    "hand": "hand", "rotateview": "compass", "zoom": "zoom-in",
}
