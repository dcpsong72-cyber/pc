"""Catalog command-id → PixelForge handler mapping.

PhotoCraft's rule (MIT): menu items whose id matches a command are live;
the rest render disabled until implemented. This module is our implementation
table over the generated Photoshop catalog (ui/menu_catalog.py).
"""

# their filter command id -> our filter registry id
FILTER_MAP = {
    "filter.blur.gaussianBlur": "gaussianBlur",
    "filter.blur.motionBlur": "motionBlur",
    "filter.blur.radialBlur": "radialBlur",
    "filter.sharpen.sharpen": "sharpen",
    "filter.sharpen.sharpenMore": "sharpen",
    "filter.sharpen.unsharpMask": "unsharpMask",
    "filter.other.highPass": "highPass",
    "filter.noise.addNoise": "addNoise",
    "filter.noise.median": "median",
    "filter.noise.reduceNoise": "reduceNoise",
    "filter.pixelate.mosaic": "mosaic",
    "filter.pixelate.crystallize": "crystallize",
    "filter.distort.pinch": "pinch",
    "filter.distort.spherize": "spherize",
    "filter.distort.twirl": "twirl",
    "filter.distort.wave": "wave",
    "filter.stylize.emboss": "emboss",
    "filter.stylize.findEdges": "findEdges",
    "filter.stylize.oilPaint": "oilPaint",
    "filter.render.lensFlare": "lensFlare",
    "filter.render.differenceClouds": "differenceClouds",
    "filter.render.vignette": "vignette",
    "filter.other.duotone": "duotone",
    "filter.other.sepia": "sepia",
    "filter.other.warm": "warm",
    "filter.other.cool": "cool",
    "filter.other.autoEnhance": "autoEnhance",
    "filter.other.pencilSketch": "pencilSketch",
    "filter.other.zoomBlur": "zoomBlur",
    # --- Blur Gallery (2026) ---
    "filter.blurGallery.irisBlur": "irisBlur",
    "filter.blurGallery.tiltShift": "tiltShift",
    "filter.blurGallery.fieldBlur": "fieldBlur",
    # --- newly live 2026-era filters ---
    "filter.pixelate.colorHalftone": "colorHalftone",
    "filter.noise.dustAndScratches": "dustAndScratches",
    "filter.sharpen.smartSharpen": "smartSharpen",
}

# destructive image adjustments (Image > Adjustments bottom half)
IMAGE_ADJ_DIRECT = {
    "image.adjustments.invert": "Invert",
    "image.adjustments.desaturate": "Desaturate",
    "image.autoTone": "autoTone",
    "image.autoContrast": "autoContrast",
    "image.autoColor": "autoEnhance",
}

# dialog adjustments: open as live adjustment layers
IMAGE_ADJ_LIVE = {
    "image.adjustments.brightnessContrast": "brightness_contrast",
    "image.adjustments.levels": "levels",
    "image.adjustments.curves": "curves",
    "image.adjustments.exposure": "exposure",
    "image.adjustments.vibrance": "vibrance",
    "image.adjustments.hueSaturation": "hue_sat",
    "image.adjustments.colorBalance": "temperature",
    "image.adjustments.blackWhite": "bw",
    "image.adjustments.photoFilter": "photo_filter",
    "image.adjustments.posterize": "posterize",
    "image.adjustments.threshold": "threshold",
    "image.adjustments.gradientMap": "gradient_map",
}

EXTRA_FILTERS = ["autoEnhance", "warm", "cool", "sepia", "duotone", "pencilSketch",
                 "zoomBlur", "differenceClouds", "vignette", "gradientMap"]
