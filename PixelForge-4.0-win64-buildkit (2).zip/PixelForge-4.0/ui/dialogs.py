"""Dialogs: templates (Canva), filter gallery, collage maker, magic resize,
layer style, text editor, brand kit, magic grab-cut background remover."""

from __future__ import annotations

import os

import numpy as np
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QColor, QImage, QPainter, QPixmap, QFont
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
                               QLabel, QListWidget, QListWidgetItem, QPushButton,
                               QSlider, QDoubleSpinBox, QSpinBox, QComboBox,
                               QCheckBox, QLineEdit, QFileDialog, QToolButton,
                               QGroupBox, QColorDialog, QDialogButtonBox,
                               QPlainTextEdit, QFormLayout, QWidget, QMessageBox)

TEMPLATES = [
    ("Instagram Post", 1080, 1080), ("Instagram Story", 1080, 1920),
    ("Facebook Cover", 1640, 624), ("YouTube Thumbnail", 1280, 720),
    ("YouTube Banner", 2048, 1152), ("Presentation 16:9", 1920, 1080),
    ("Poster A4 @150dpi", 1240, 1754), ("Flyer US Letter", 1275, 1650),
    ("Business Card", 1050, 600), ("Logo Canvas", 800, 800),
    ("Pinterest Pin", 1000, 1500), ("Twitter/X Post", 1600, 900),
    ("LinkedIn Banner", 1584, 396), ("Wallpaper FHD", 1920, 1080),
]

CANVA_PRESETS = [
    ("Vivid", {"filter.run:brightness_contrast_adj": None}),  # placeholder
]

FILTER_CATEGORIES = {
    "Blur": ["gaussianBlur", "motionBlur", "zoomBlur", "radialBlur"],
    "Sharpen": ["sharpen", "unsharpMask", "highPass"],
    "Noise": ["addNoise", "median", "reduceNoise"],
    "Pixelate": ["mosaic", "crystallize"],
    "Distort": ["twirl", "wave", "pinch", "spherize"],
    "Stylize": ["emboss", "findEdges", "oilPaint", "pencilSketch"],
    "Render": ["lensFlare", "vignette", "differenceClouds"],
    "Adjust": ["autoEnhance", "autoTone", "autoContrast", "warm", "cool", "sepia",
               "duotone", "gradientMap"],
}


class TemplateDialog(QDialog):
    """Canva-style 'create a design' picker."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Create a Design — Templates")
        self.resize(560, 420)
        self.selected = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Start with a perfectly-sized canvas:"))
        self.list = QListWidget()
        self.list.setViewMode(QListWidget.IconMode)
        self.list.setIconSize(QSize(96, 64))
        self.list.setResizeMode(QListWidget.Adjust)
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        w_spin = QSpinBox(); w_spin.setRange(1, 20000); w_spin.setValue(1080)
        h_spin = QSpinBox(); h_spin.setRange(1, 20000); h_spin.setValue(1080)
        row.addWidget(QLabel("W")); row.addWidget(w_spin)
        row.addWidget(QLabel("H")); row.addWidget(h_spin)
        row.addStretch(1)
        ok = QPushButton("Create"); cancel = QPushButton("Cancel")
        ok.clicked.connect(self._ok); cancel.clicked.connect(self.reject)
        row.addWidget(cancel); row.addWidget(ok)
        lay.addLayout(row)
        self.w_spin, self.h_spin = w_spin, h_spin
        for name, w, h in TEMPLATES:
            item = QListWidgetItem(name)
            pm = QPixmap(96, 64)
            pm.fill(QColor("#2e5c8a"))
            p = QPainter(pm)
            p.setPen(QColor("white"))
            p.drawText(pm.rect(), Qt.AlignCenter, f"{w}×{h}")
            p.end()
            item.setIcon(pm)
            item.setData(Qt.UserRole, (w, h))
            self.list.addItem(item)
        self.list.itemDoubleClicked.connect(lambda *_: self._ok())
        self.list.currentItemChanged.connect(self._pick)

    def _pick(self, item, _):
        if item:
            w, h = item.data(Qt.UserRole)
            self.w_spin.setValue(w)
            self.h_spin.setValue(h)

    def _ok(self):
        self.selected = (self.w_spin.value(), self.h_spin.value())
        self.accept()


class FilterGalleryDialog(QDialog):
    """Live-preview filter browser with intensity."""

    def __init__(self, parent, mainwin):
        super().__init__(parent)
        self.win = mainwin
        self.setWindowTitle("Filter Gallery")
        self.resize(760, 560)
        self.selected = None
        lay = QHBoxLayout(self)
        left = QVBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search filters…")
        left.addWidget(self.search)
        self.list = QListWidget()
        left.addWidget(self.list, 1)
        lay.addLayout(left, 0)

        right = QVBoxLayout()
        self.preview = QLabel("preview")
        self.preview.setMinimumSize(420, 360)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet("background:#141414; border:1px solid #333;")
        right.addWidget(self.preview, 1)
        row = QHBoxLayout()
        row.addWidget(QLabel("Intensity"))
        self.intensity = QSlider(Qt.Horizontal)
        self.intensity.setRange(10, 200)
        self.intensity.setValue(100)
        row.addWidget(self.intensity, 1)
        right.addLayout(row)
        btns = QHBoxLayout()
        apply_btn = QPushButton("Apply")
        apply_btn.clicked.connect(self._apply)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        btns.addStretch(1)
        btns.addWidget(cancel)
        btns.addWidget(apply_btn)
        right.addLayout(btns)
        lay.addLayout(right, 1)

        self.search.textChanged.connect(self._refill)
        self.list.currentItemChanged.connect(lambda *_: self._preview())
        self.intensity.valueChanged.connect(self._preview)
        self._all = []
        from pf import filters as F
        for fid, (fn, defaults, label, cat) in F.REGISTRY.items():
            self._all.append((fid, label, cat))
        self._refill("")

    def _refill(self, text):
        self.list.clear()
        text = (text or "").lower()
        bycat = {}
        for fid, label, cat in self._all:
            if text in f"{fid} {label} {cat}".lower():
                bycat.setdefault(cat, []).append((fid, label))
        for cat in sorted(bycat):
            head = QListWidgetItem(f"— {cat} —")
            head.setFlags(Qt.NoItemFlags)
            self.list.addItem(head)
            for fid, label in bycat[cat]:
                item = QListWidgetItem(label)
                item.setData(Qt.UserRole, fid)
                self.list.addItem(item)

    def _blended(self, fid):
        import tempfile
        from pf import filters as F
        fn, defaults, _, _ = F.REGISTRY[fid]
        comp = self._base_comp.copy()
        k = self.intensity.value() / 100.0
        try:
            filtered = fn(comp, **{k2: v for k2, v in defaults.items()})
        except TypeError:
            filtered = fn(comp)
        if k < 0.99:
            filtered = np.clip(comp * (1 - k) + filtered * k, 0, 255).astype(np.uint8)
        return filtered

    def _preview(self):
        item = self.list.currentItem()
        if item is None or item.data(Qt.UserRole) is None:
            return
        if not hasattr(self, "_base_comp"):
            self._make_base()
        filtered = self._blended(item.data(Qt.UserRole))
        img = QImage(filtered.data, filtered.shape[1], filtered.shape[0],
                     filtered.shape[1] * 4, QImage.Format_RGBA8888)
        pm = QPixmap.fromImage(img).scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.preview.setPixmap(pm)

    def _make_base(self):
        from pf import compose
        comp = compose.composite_rgba8(self.win.session.doc)
        # downscale for preview speed
        h, w = comp.shape[:2]
        s = min(1.0, 480 / max(h, w))
        from PIL import Image
        small = Image.fromarray(comp).resize((max(2, int(w * s)), max(2, int(h * s))))
        self._base_comp = np.asarray(small, np.uint8)

    def _apply(self):
        item = self.list.currentItem()
        if item is None or item.data(Qt.UserRole) is None:
            return
        self.selected = item.data(Qt.UserRole)
        self.accept()


class LayerStyleDialog(QDialog):
    """Photoshop-style layer style: drop shadow, outer glow, stroke."""

    def __init__(self, parent, effects):
        super().__init__(parent)
        self.setWindowTitle("Layer Style")
        self.resize(420, 420)
        lay = QVBoxLayout(self)
        self.groups = {}
        for key, title, fields in (
            ("shadow", "Drop Shadow", [("dx", "Offset X", -60, 60, 6), ("dy", "Offset Y", -60, 60, 6),
                                       ("blur", "Blur", 0, 80, 10), ("opacity", "Opacity %", 0, 100, 55)]),
            ("glow", "Outer Glow", [("blur", "Blur", 1, 80, 14), ("opacity", "Opacity %", 0, 100, 70)]),
            ("stroke", "Stroke", [("width", "Width", 1, 40, 3), ("opacity", "Opacity %", 0, 100, 100)]),
        ):
            box = QGroupBox(title)
            box.setCheckable(True)
            box.setChecked(key in (effects or {}))
            form = QFormLayout(box)
            spins = {}
            for fname, flabel, lo, hi, default in fields:
                sp = QDoubleSpinBox()
                sp.setRange(lo, hi)
                sp.setValue(float((effects or {}).get(key, {}).get(fname, default)))
                form.addRow(flabel, sp)
                spins[fname] = sp
            color_btn = QToolButton()
            color_btn.setFixedSize(40, 22)
            self.groups[key] = (box, spins, color_btn, QColor(*(effects or {}).get(key, {}).get("color", {"shadow": (0, 0, 0), "glow": (255, 240, 180), "stroke": (255, 255, 255)})[key]))
            self.groups[key] = (box, spins, color_btn, QColor(*(effects or {}).get(key, {}).get("color") or {"shadow": (0, 0, 0), "glow": (255, 240, 180), "stroke": (255, 255, 255)}[key]))
            self._paint_swatch(key)
            color_btn.clicked.connect(lambda _=False, k=key: self._pick_color(k))
            form.addRow("Color", color_btn)
            lay.addWidget(box)
        row = QHBoxLayout()
        ok = QPushButton("OK"); cancel = QPushButton("Cancel"); clear = QPushButton("Clear All")
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        clear.clicked.connect(self._clear)
        row.addWidget(clear); row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        lay.addLayout(row)
        self._cleared = False

    def _clear(self):
        self._cleared = True
        self.reject()

    def _pick_color(self, key):
        box, spins, btn, color = self.groups[key]
        c = QColorDialog.getColor(color, self, "Effect color")
        if c.isValid():
            self.groups[key] = (box, spins, btn, c)
            self._paint_swatch(key)

    def _paint_swatch(self, key):
        _, _, btn, color = self.groups[key]
        pm = QPixmap(36, 18)
        pm.fill(color)
        btn.setIcon(pm)
        btn.setIconSize(pm.size())

    def result_effects(self):
        if self._cleared:
            return {}
        out = {}
        colors = {"shadow": (0, 0, 0), "glow": (255, 240, 180), "stroke": (255, 255, 255)}
        for key, (box, spins, _, color) in self.groups.items():
            if box.isChecked():
                out[key] = {name: sp.value() for name, sp in spins.items()}
                out[key]["color"] = [color.red(), color.green(), color.blue()]
                if "opacity" in out[key]:
                    out[key]["opacity"] = out[key]["opacity"] / 100.0
        return out


class TextDialog(QDialog):
    def __init__(self, parent, params=None, pf_fonts=None):
        super().__init__(parent)
        self.setWindowTitle("Text")
        self.resize(480, 380)
        params = params or {}
        lay = QVBoxLayout(self)
        self.edit = QPlainTextEdit(params.get("text", "Your text here"))
        self.edit.setMinimumHeight(90)
        lay.addWidget(self.edit)
        form = QFormLayout()
        self.font_combo = QComboBox()
        self.font_combo.addItems(pf_fonts or ["DejaVu Sans"])
        cur = params.get("font", "DejaVu Sans")
        i = self.font_combo.findText(cur)
        self.font_combo.setCurrentIndex(max(0, i))
        form.addRow("Font", self.font_combo)
        self.size_spin = QSpinBox()
        self.size_spin.setRange(6, 800)
        self.size_spin.setValue(int(params.get("size", 64)))
        form.addRow("Size", self.size_spin)
        style_row = QHBoxLayout()
        self.bold_cb = QCheckBox("Bold"); self.bold_cb.setChecked(bool(params.get("bold")))
        self.italic_cb = QCheckBox("Italic"); self.italic_cb.setChecked(bool(params.get("italic")))
        self.align_combo = QComboBox(); self.align_combo.addItems(["left", "center", "right"])
        self.align_combo.setCurrentText(params.get("align", "left"))
        style_row.addWidget(self.bold_cb); style_row.addWidget(self.italic_cb)
        style_row.addWidget(QLabel("Align")); style_row.addWidget(self.align_combo)
        style_row.addStretch(1)
        form.addRow("Style", style_row)
        color_row = QHBoxLayout()
        self.color = QColor(*(params.get("color") or [26, 26, 26])[:3])
        self.color_btn = QToolButton()
        self.color_btn.setFixedSize(50, 22)
        self._paint()
        self.color_btn.clicked.connect(self._pick)
        color_row.addWidget(self.color_btn)
        color_row.addStretch(1)
        form.addRow("Color", color_row)
        lay.addLayout(form)
        row = QHBoxLayout()
        ok = QPushButton("Apply"); cancel = QPushButton("Cancel")
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(ok)
        lay.addLayout(row)

    def _paint(self):
        pm = QPixmap(44, 18)
        pm.fill(self.color)
        self.color_btn.setIcon(pm)
        self.color_btn.setIconSize(pm.size())

    def _pick(self):
        from PySide6.QtWidgets import QColorDialog
        c = QColorDialog.getColor(self.color, self, "Text color")
        if c.isValid():
            self.color = c
            self._paint()

    def params(self):
        return {"text": self.edit.toPlainText(), "font": self.font_combo.currentText(),
                "size": self.size_spin.value(), "bold": self.bold_cb.isChecked(),
                "italic": self.italic_cb.isChecked(), "align": self.align_combo.currentText(),
                "color": [self.color.red(), self.color.green(), self.color.blue(), 255]}


class CollageDialog(QDialog):
    """Canva-style grid collage maker."""

    LAYOUTS = {
        "2 vertical": [(0, 0, .5, 1), (.5, 0, .5, 1)],
        "2 horizontal": [(0, 0, 1, .5), (0, .5, 1, .5)],
        "3 grid (1 big + 2)": [(0, 0, .62, 1), (.62, 0, .38, .5), (.62, .5, .38, .5)],
        "3 horizontal": [(0, 0, 1 / 3, 1), (1 / 3, 0, 1 / 3, 1), (2 / 3, 0, 1 / 3, 1)],
        "4 grid": [(0, 0, .5, .5), (.5, 0, .5, .5), (0, .5, .5, .5), (.5, .5, .5, .5)],
        "4 mosaic": [(0, 0, .6, .6), (.6, 0, .4, .6), (0, .6, .5, .4), (.5, .6, .5, .4)],
        "5 grid": [(0, 0, .5, .5), (.5, 0, .5, .5), (0, .5, 1 / 3, .5),
                   (1 / 3, .5, 1 / 3, .5), (2 / 3, .5, 1 / 3, .5)],
    }

    def __init__(self, parent, win):
        super().__init__(parent)
        self.win = win
        self.setWindowTitle("Collage Maker")
        self.resize(560, 480)
        self.images = []
        lay = QHBoxLayout(self)
        left = QVBoxLayout()
        add = QPushButton("Add Images…")
        add.clicked.connect(self._add)
        left.addWidget(add)
        self.list = QListWidget()
        left.addWidget(self.list, 1)
        rem = QPushButton("Remove Selected")
        rem.clicked.connect(self._remove)
        left.addWidget(rem)
        lay.addLayout(left, 0)

        right = QVBoxLayout()
        form = QFormLayout()
        self.layout_combo = QComboBox()
        self.layout_combo.addItems(self.LAYOUTS.keys())
        form.addRow("Layout", self.layout_combo)
        self.w_spin = QSpinBox(); self.w_spin.setRange(200, 6000); self.w_spin.setValue(1600)
        self.h_spin = QSpinBox(); self.h_spin.setRange(200, 6000); self.h_spin.setValue(1200)
        form.addRow("Size", self.h_spin)
        form.addRow("Width", self.w_spin)
        self.gap_spin = QSpinBox(); self.gap_spin.setRange(0, 80); self.gap_spin.setValue(8)
        form.addRow("Gap", self.gap_spin)
        self.margin_spin = QSpinBox(); self.margin_spin.setRange(0, 120); self.margin_spin.setValue(12)
        form.addRow("Margin", self.margin_spin)
        self.bg_btn = QToolButton(); self.bg_btn.setFixedSize(46, 22)
        self.bg_color = QColor(255, 255, 255)
        pm = QPixmap(40, 16); pm.fill(self.bg_color)
        self.bg_btn.setIcon(pm); self.bg_btn.setIconSize(pm.size())
        self.bg_btn.clicked.connect(self._pick_bg)
        form.addRow("Background", self.bg_btn)
        self.round_cb = QCheckBox("Fit (crop to fill cells)")
        self.round_cb.setChecked(True)
        form.addRow("", self.round_cb)
        right.addLayout(form)
        self.preview = QLabel()
        self.preview.setMinimumSize(300, 280)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet("background:#141414;border:1px solid #333;")
        right.addWidget(self.preview, 1)
        row = QHBoxLayout()
        create = QPushButton("Create as New Document")
        create.clicked.connect(self._create)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(cancel); row.addWidget(create)
        right.addLayout(row)
        lay.addLayout(right, 1)

        for sig in (self.layout_combo.currentIndexChanged, self.w_spin.valueChanged,
                    self.h_spin.valueChanged, self.gap_spin.valueChanged,
                    self.margin_spin.valueChanged):
            sig.connect(self._preview_update)

    def _pick_bg(self):
        c = QColorDialog.getColor(self.bg_color, self, "Background")
        if c.isValid():
            self.bg_color = c
            pm = QPixmap(40, 16); pm.fill(c)
            self.bg_btn.setIcon(pm); self.bg_btn.setIconSize(pm.size())
            self._preview_update()

    def _add(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Add images", "",
                                                "Images (*.png *.jpg *.jpeg *.webp *.bmp *.psd)")
        from pf import psdio
        from pf import compose
        for p in paths:
            try:
                d = psdio.read(p)
                self.images.append(compose.composite_rgba8(d))
                self.list.addItem(os.path.basename(p))
            except Exception as exc:
                QMessageBox.warning(self, "Could not load", f"{p}\n{exc}")
        self._preview_update()

    def _remove(self):
        row = self.list.currentRow()
        if row >= 0:
            self.list.takeItem(row)
            self.images.pop(row)
            self._preview_update()

    def _cells(self):
        cells = self.LAYOUTS[self.layout_combo.currentText()]
        W, H = self.w_spin.value(), self.h_spin.value()
        gap, margin = self.gap_spin.value(), self.margin_spin.value()
        out = []
        for fx, fy, fw, fh in cells:
            x = margin + fx * W
            y = margin + fy * H
            w = fw * W - gap - (margin if fx == 0 else 0)
            h = fh * H - gap - (margin if fy == 0 else 0)
            out.append((int(x), int(y), int(w), int(h)))
        return out

    def _render(self):
        W, H = self.w_spin.value(), self.h_spin.value()
        canvas = np.zeros((H, W, 4), np.uint8)
        canvas[..., :3] = self.bg_color.red(), self.bg_color.green(), self.bg_color.blue()
        canvas[..., 3] = 255
        cells = self._cells()
        for i, (x, y, w, h) in enumerate(cells):
            if i >= len(self.images):
                break
            img = self.images[i]
            from PIL import Image
            im = Image.fromarray(img)
            if self.round_cb.isChecked():
                s = max(w / im.width, h / im.height)
                im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
                left = (im.width - w) // 2
                top = (im.height - h) // 2
                arr = np.asarray(im)[top:top + h, left:left + w]
            else:
                s = min(w / im.width, h / im.height)
                im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
                arr = np.asarray(im)
                ph, pw = arr.shape[:2]
                arr_full = np.zeros((h, w, 4), np.uint8)
                arr_full[:min(h, ph), :min(w, pw)] = arr[:h, :w]
                arr = arr_full
            canvas[y:y + arr.shape[0], x:x + arr.shape[1]] = arr
        return canvas

    def _preview_update(self):
        try:
            canvas = self._render()
        except Exception:
            return
        img = QImage(canvas.data, canvas.shape[1], canvas.shape[0], canvas.shape[1] * 4, QImage.Format_RGBA8888)
        self.preview.setPixmap(QPixmap.fromImage(img).scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _create(self):
        canvas = self._render()
        import tempfile
        tmp = tempfile.mktemp(suffix=".png")
        from PIL import Image
        Image.fromarray(canvas).save(tmp)
        self.win.load_path(tmp)
        self.accept()


class ResizeDialog(QDialog):
    """Magic resize: export current design at many social sizes."""

    def __init__(self, parent, win):
        super().__init__(parent)
        self.win = win
        self.setWindowTitle("Magic Resize")
        self.resize(420, 460)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Export the current design at multiple sizes:"))
        self.checks = {}
        for name, w, h in TEMPLATES:
            cb = QCheckBox(f"{name}  ({w}×{h})")
            cb.setData = (w, h)
            self.checks[name] = (cb, w, h)
            lay.addWidget(cb)
        row = QHBoxLayout()
        self.mode = QComboBox()
        self.mode.addItems(["Export copies (files)", "Scale document (in place)"])
        row.addWidget(self.mode, 1)
        go = QPushButton("Go")
        go.clicked.connect(self._go)
        row.addWidget(go)
        lay.addLayout(row)

    def _go(self):
        chosen = [(w, h, name) for name, (cb, w, h) in self.checks.items() if cb.isChecked()]
        if not chosen:
            return
        self.selected = (chosen, self.mode.currentText())
        self.accept()
