#!/usr/bin/env python3
"""v4 demo — PS 27.6/27.11 + market pass: engine feature card + Actions panel.

Run: QT_QPA_PLATFORM=offscreen LD_LIBRARY_PATH=/home/user/runtime/lib python3 scripts/demo4.py
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from pf.engine import Session

OUT = os.path.join(ROOT, "demo")
FONT_DIR = os.path.join(ROOT, "assets", "fonts")


def font(size):
    for name in ("Inter-SemiBold.ttf", "Inter-Regular.ttf"):
        p = os.path.join(FONT_DIR, name)
        if os.path.isfile(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


# ------------------------------------------------------------------ scene art
def synth_product(w=420, h=340):
    """A 'photo' of a product on a cluttered desk."""
    rng = np.random.default_rng(11)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    img = np.zeros((h, w, 4), np.uint8)
    # cluttered wooden desk backdrop
    base = np.stack([150 + 30 * np.sin(xx / 37), 110 + 22 * np.sin(yy / 29 + 2),
                     74 + 16 * np.sin((xx + yy) / 23)], -1)
    base += rng.normal(0, 9, base.shape)
    img[..., :3] = np.clip(base, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    # the product: a cosmetic bottle (rounded rect + cap)
    x0, y0, x1, y1 = int(w * 0.36), int(h * 0.28), int(w * 0.64), int(h * 0.86)
    img[y0:y1, x0:x1, :3] = (208, 92, 60)
    img[y0:y1, x0:x1, 3] = 255
    img[y0 - 28:y0, x0 + 18:x1 - 18, :3] = (40, 36, 38)      # cap
    img[y0 - 28:y0, x0 + 18:x1 - 18, 3] = 255
    img[y0 + 40:y0 + 150, x0 + 16:x1 - 16, :3] = (240, 226, 214)  # label
    # distracting specks
    for _ in range(26):
        x, y = int(rng.integers(8, w - 8)), int(rng.integers(8, h - 8))
        img[y:y + 2, x:x + 2, :3] = (252, 250, 246)
    return img


def synth_old(w=420, h=320):
    """Faded, dusty, noisy scan of a portrait-ish scene."""
    rng = np.random.default_rng(4)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    scene = np.stack([120 + 55 * np.sin(yy / 55), 96 + 40 * np.sin(xx / 61),
                      84 + 30 * np.cos(yy / 43)], -1)
    scene = np.clip(scene + rng.normal(0, 7, scene.shape), 0, 255)
    faded = scene * 0.55 + 90                                # washed out
    faded += rng.normal(0, 9, faded.shape)
    img = np.zeros((h, w, 4), np.uint8)
    img[..., :3] = np.clip(faded, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    for _ in range(50):                                      # dust & scratches
        x, y = int(rng.integers(4, w - 4)), int(rng.integers(4, h - 4))
        ln = int(rng.integers(1, 4))
        img[y:y + ln, x:x + 2, :3] = (250, 248, 240)
    return img


def to_doc(session, arr):
    h, w = arr.shape[:2]
    session.execute("doc.new", width=w, height=h, background=(0, 0, 0))
    px = session.doc.layers[0].pixels
    px[...] = arr
    return session.doc.layers[0]


def panel(img_arr, title, note=""):
    """Square-ish panel with caption strip."""
    scale = 300 / max(img_arr.shape[:2])
    h, w = img_arr.shape[:2]
    im = Image.fromarray(img_arr[..., :3]).resize((int(w * scale), int(h * scale)))
    card = Image.new("RGB", (340, im.height + 74), (16, 16, 18))
    card.paste(im, (20, 20))
    d = ImageDraw.Draw(card)
    d.text((20, im.height + 34), title, font=font(21), fill=(240, 240, 244))
    if note:
        d.text((20, im.height + 56), note, font=font(13), fill=(130, 130, 138))
    return card


def v4_card():
    s = Session()
    tiles = []

    # 1) Restore Old Photo
    old = synth_old()
    to_doc(s, old)
    s.execute("image.restoreOld", denoise=9, colorize=False)
    tiles.append((old, s.doc.layers[0].pixels.copy(), "Restore Old Photo",
                  "dust · denoise · contrast recovery"))

    # 2) Product Shot
    prod = synth_product()
    to_doc(s, prod)
    try:
        s.execute("image.productShot", style="studio", shadow=True,
                  color=(244, 244, 247))
        s.execute("image.findDistractions", heal_tiny=True)   # dust-free backdrop
        tiles.append((prod, s.doc.layers[0].pixels.copy(), "Product Shot",
                      "matte → backdrop → AI shadow → speck heal"))
    except Exception:
        tiles.append((prod, prod, "Product Shot", "unavailable"))

    # 3) Relight
    base = synth_product()
    base[..., :3] = np.clip(base[..., :3].astype(int) * 0.72 + 30, 0, 255).astype(np.uint8)
    to_doc(s, base)
    s.execute("image.relight", angle=315, strength=0.85)
    tiles.append((base, s.doc.layers[0].pixels.copy(), "Relight",
                  "directional scene light from depth"))

    # 4) Watermark
    photo = synth_product()
    photo[..., :3] = np.clip(photo[..., :3].astype(int) // 2 + 60, 0, 255).astype(np.uint8)
    to_doc(s, photo)
    s.execute("image.watermark", text="© PixelForge", corner="bottom-right",
              opacity=0.85)
    from pf import compose as _compose
    tiles.append((photo, _compose.composite_rgba8(s.doc), "Watermark",
                  "own layer · corners or tiled"))

    # compose 2×2 before→after rows
    GAP, M = 14, 26
    rows = []
    for before, after, title, note in tiles:
        b = panel(before, "before", "")
        a = panel(after, title, note)
        row = Image.new("RGB", (b.width + GAP + a.width + M * 2,
                                max(b.height, a.height) + M * 2), (10, 10, 12))
        row.paste(b, (M, M))
        row.paste(a, (M + b.width + GAP, M))
        # arrow
        d = ImageDraw.Draw(row)
        ax = M + b.width + GAP // 2
        ay = row.height // 2
        d.polygon([(ax - 6, ay - 7), (ax - 6, ay + 7), (ax + 6, ay)],
                  fill=(90, 200, 255))
        rows.append(row)
    title = "PixelForge 4.0 — the 2026 automation & restoration pass"
    tf = font(30)
    tw = int(ImageDraw.Draw(Image.new("RGB", (8, 8))).textlength(title, font=tf))
    W = max([r.width for r in rows] + [tw + M * 2])
    H = sum(r.height for r in rows) + GAP + 66
    card = Image.new("RGB", (W + M * 2, H + M), (10, 10, 12))
    d = ImageDraw.Draw(card)
    d.text((M, 14), title, font=tf, fill=(250, 250, 252))
    y = 66
    for r in rows:
        card.paste(r, (M, y))
        y += r.height + GAP
    card.save(os.path.join(OUT, "25_v4_features.png"))
    print("demo/25_v4_features.png")


# ------------------------------------------------------------------ window UI
def ui_shot():
    from PySide6.QtWidgets import QApplication
    from pf.engine import Session as S
    from ui.main_window import MainWindow

    app = QApplication.instance() or QApplication([])
    session = S()
    win = MainWindow(session)
    win.switch_theme("amoled")
    win.resize(1680, 1020)
    win.show()
    for _ in range(6):
        app.processEvents()

    session.execute("doc.open", path=os.path.join(ROOT, "assets", "sample.png"))
    session.execute("filter.run", filter_id="lookVivid")
    session.execute("image.relight", angle=315, strength=0.35)
    session.execute("image.watermark", text="© PixelForge", corner="bottom-right",
                    opacity=0.5)
    for _ in range(4):
        app.processEvents()

    # Actions tab front and center, one set selected, search demo text
    tabs = win.dock_history
    for i in range(tabs.count()):
        if tabs.tabText(i) == "Actions":
            tabs.setCurrentIndex(i)
    p = win.actions_panel
    p.search.setText("")
    for i in range(p.list.topLevelItemCount()):
        it = p.list.topLevelItem(i)
        if "Studio Product" in it.text(0):
            p.list.setCurrentItem(it)
            it.setExpanded(True)
            break
    p.status.setText('Playing "Studio Product": 2 step(s) applied')
    for _ in range(6):
        app.processEvents()
    win.grab().save(os.path.join(OUT, "26_actions_panel.png"))
    print("demo/26_actions_panel.png")
    win.bridge.close()


if __name__ == "__main__":
    v4_card()
    ui_shot()
    print("demo4 complete")
