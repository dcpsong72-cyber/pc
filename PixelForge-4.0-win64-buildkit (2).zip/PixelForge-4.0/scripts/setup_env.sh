#!/usr/bin/env bash
# PixelForge dev environment setup (idempotent).
# Python site-packages don't persist between sandbox sessions — rerun this.
set -e
cd "$(dirname "$0")/.."

pip install -q -r requirements.txt

# Bundled xkbcommon for Qt on stripped containers (copied once, lives in runtime/lib)
mkdir -p runtime/lib
XKB=$(find /usr/local/lib/python3.13/site-packages -name "libxkbcommon-*.so.0.0.0" 2>/dev/null | head -1)
XKBX11=$(find /usr/local/lib/python3.13/site-packages -name "libxkbcommon-x11-*.so.0.0.0" 2>/dev/null | head -1)
[ -f runtime/lib/libxkbcommon.so.0 ] || [ -n "$XKB" ] && cp -n "$XKB" runtime/lib/libxkbcommon.so.0 2>/dev/null || true
[ -f runtime/lib/libxkbcommon-x11.so.0 ] || [ -n "$XKBX11" ] && cp -n "$XKBX11" runtime/lib/libxkbcommon-x11.so.0 2>/dev/null || true

echo "✅ Environment ready. Run: python3 main.py"
