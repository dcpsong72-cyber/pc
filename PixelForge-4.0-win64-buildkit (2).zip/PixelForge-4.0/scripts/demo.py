#!/usr/bin/env python3
"""Offscreen demo: drives the app like a user and captures screenshots.

    QT_QPA_PLATFORM=offscreen python3 scripts/demo.py
"""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from ui.qt_boot import create_app  # noqa: E402

OUT = os.path.join(ROOT, "demo")
os.makedirs(OUT, exist_ok=True)


def snap(win, name):
    pm = win.grab()
    path = os.path.join(OUT, name)
    pm.save(path)
    print("saved", path)


def main():
    app = create_app(sys.argv)
    from pf.engine import Session
    from pf import color as C
    from ui.main_window import MainWindow

    session = Session()
    win = MainWindow(session)
    win.resize(1440, 900)
    win.show()
    app.processEvents()

    # 1. open the sample photo
    win.load_path(os.path.join(ROOT, "assets", "sample.png"))
    for _ in range(6):
        app.processEvents()

    # 2. add a selection + fill layer via engine commands
    win.session.execute("selection.set", rect=(90, 480, 700, 780))
    win.session.execute("layer.add", name="Accent")
    win.session.execute("edit.fill", color=(242, 148, 40, 255), only_selection=True)
    win.session.execute("selection.deselect")
    win.session.execute("layer.setProps", opacity=0.75, blend=C.SCREEN)

    # 3. add a semi-transparent title layer with a painted stripe
    win.session.execute("layer.add", name="Brushwork")
    win.session.execute("paint.stroke",
                        points=[(60 + i * 8, 90 + (i % 3) * 4) for i in range(40)],
                        size=42, hardness=0.6, color=(20, 24, 38, 230))

    # 4. move tool demo: shift Brushwork
    win.session.execute("layer.translate", dx=14, dy=8)
    for _ in range(6):
        app.processEvents()
    snap(win, "01_main_editor.png")

    # 5. blend-mode comparison strip: same doc, multiply vs screen vs overlay
    win.session.execute("layer.setProps", blend=C.MULTIPLY, opacity=0.9)
    for _ in range(3):
        app.processEvents()
    snap(win, "02_blend_multiply.png")
    win.session.execute("layer.setProps", blend=C.OVERLAY, opacity=0.85)
    for _ in range(3):
        app.processEvents()
    snap(win, "03_blend_overlay.png")
    win.session.execute("layer.setProps", blend=C.SCREEN, opacity=0.75)

    # 6. history rollback demo
    while win.session.undo_stack and len(win.session.undo_stack) > 4:
        win.session.undo()
    for _ in range(3):
        app.processEvents()
    snap(win, "04_after_undo.png")
    while win.session.redo_stack:
        win.session.redo()
    for _ in range(3):
        app.processEvents()

    # 7. PSD round trip + engine verification
    psd_out = os.path.join(OUT, "demo_doc.psd")
    win.session.execute("doc.save", path=psd_out)
    print("PSD saved:", psd_out, os.path.getsize(psd_out), "bytes")

    try:
        with __import__("tempfile").TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "v.psd")
            win.session.execute("doc.save", path=src)
            from pf import compose
            a = compose.composite_rgba8(win.session.doc).astype("int16")
            b = win.bridge.render_file(src).astype("int16")
            close = (abs(a - b) <= 6).mean() * 100 if a.shape == b.shape else 0
            print(f"PhotoCraft engine verification: pixels within ±6: {close:.2f}%")
    except Exception as exc:
        print("engine verify skipped:", exc)
    win.bridge.close()

    # 8. final screenshot
    for _ in range(3):
        app.processEvents()
    snap(win, "05_final.png")
    print("demo complete")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
