#!/usr/bin/env python3
"""PixelForge 2.0 showcase: photo editing + Canva-style design, headless."""
import os, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from ui.qt_boot import create_app
app = create_app(sys.argv)
from pf.engine import Session
from pf import compose, psdio, color as C
from ui.main_window import MainWindow

OUT = os.path.join(ROOT, "demo")
os.makedirs(OUT, exist_ok=True)

session = Session()
win = MainWindow(session)
win.show()
app.processEvents()

# ---- 1. photo document: cinematic grade
win.load_path(os.path.join(ROOT, "assets", "sample.png"))
app.processEvents()
session.execute("layer.newAdjustment", kind="hue_sat", hue=-8, sat=0.35, light=0.02)
session.execute("layer.newAdjustment", kind="temperature", temp=0.35, tint=0.05)
session.execute("layer.newAdjustment", kind="vibrance", amount=0.45)
session.execute("selection.subject")  # GrabCut subject selection (marching ants)
app.processEvents()
win.grab().save(os.path.join(OUT, "20_photo_adjustments.png"))
print("1/4 photo adjustments captured")

# ---- 2. Canva-style design: text + shapes + effects + brand colors
session.execute("doc.new", width=1080, height=1080, background=(247, 243, 238))
# gradient background wash
session.execute("layer.add", name="wash")
session.execute("paint.gradient", p0=(0, 0), p1=(1080, 1080), kind="linear",
                color0=(94, 96, 206), color1=(240, 98, 146), transparency=False)
session.execute("layer.newShape", x=690, y=640, shape="star", w=230, h=230,
                fill=[255, 202, 58, 255], stroke=[23, 32, 42, 255], stroke_w=6, points=5)
session.execute("layer.setEffects", effects={
    "shadow": {"dx": 14, "dy": 14, "blur": 18, "opacity": 0.35, "color": [40, 30, 80]}})
session.execute("layer.newText", x=70, y=120, text="PIXELFORGE", size=110, bold=True,
                color=[23, 32, 42, 255], font="Inter")
session.execute("layer.setEffects", effects={
    "shadow": {"dx": 0, "dy": 10, "blur": 24, "opacity": 0.30, "color": [20, 20, 60]}})
session.execute("layer.newText", x=72, y=300, text="Photoshop-grade editing.\nCanva-style creation.\nOne app.", size=44,
                color=[46, 42, 60, 255], font="Inter", line_height=1.35)
session.execute("layer.newShape", x=72, y=620, shape="roundrect", w=330, h=96, radius=0.5,
                fill=[6, 214, 160, 255], stroke=[23, 32, 42, 255], stroke_w=5)
session.execute("layer.newText", x=112, y=648, text="Try it free", size=40, bold=True,
                color=[255, 255, 255, 255], font="Inter")
for _ in range(4):
    app.processEvents()
win.grab().save(os.path.join(OUT, "21_canva_design.png"))
print("2/4 canva design captured")

# ---- 3. magic wand + mask demo on the design
session.execute("selection.colorRange", color=(255, 202, 58), tolerance=60)
psd_path = os.path.join(OUT, "showcase.psd")
session.execute("doc.save", path=psd_path)
print("PSD:", psd_path, os.path.getsize(psd_path), "bytes")

# engine verification
try:
    with tempfile.TemporaryDirectory() as tmp:
        src = os.path.join(tmp, "v.psd")
        session.execute("doc.save", path=src)
        d = psdio.read(src)
        a = compose.composite_rgba8(d).astype(int)
        b = win.bridge.render_file(src).astype(int)
        close = (abs(a - b) <= 6).mean() * 100 if a.shape == b.shape else 0
        print(f"engine verify: {close:.2f}% within ±6")
except Exception as e:
    print("engine verify skipped:", e)

# ---- 4. photo editing: subject cutout on white -> product style
session.execute("doc.new", width=900, height=700, background=(255, 255, 255))
session.execute("doc.place", path=os.path.join(ROOT, "assets", "sample.png"))
# scale to fit nicely
lay = session.doc.active
s = min(760 / lay.w, 520 / lay.h)
session.execute("layer.transform", scale_x=s, scale_y=s)
session.execute("layer.translate", dx=(900 - lay.w) // 2, dy=(700 - lay.h) // 2)
session.execute("layer.setEffects", effects={
    "shadow": {"dx": 0, "dy": 18, "blur": 30, "opacity": 0.45, "color": [30, 30, 60]},
    "stroke": {"width": 6, "opacity": 1.0, "color": [255, 255, 255]}})
session.execute("layer.newText", x=40, y=610, text="Mountains at golden hour", size=36,
                bold=True, color=[40, 40, 60, 255], font="Inter")
for _ in range(4):
    app.processEvents()
win.grab().save(os.path.join(OUT, "22_photo_card.png"))
print("3/4 photo card captured")

# history rollback shot
while len(session.undo_stack) > 2:
    session.undo()
app.processEvents()
win.grab().save(os.path.join(OUT, "23_after_undo.png"))
print("4/4 undo captured")
win.bridge.close()
print("demo2 complete")
