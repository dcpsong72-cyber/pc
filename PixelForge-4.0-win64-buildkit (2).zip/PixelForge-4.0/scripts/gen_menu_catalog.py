#!/usr/bin/env python3
"""Generate ui/menu_catalog.py from PhotoCraft's MIT-licensed menu_catalog.rs.
Run from the pixelforge root:  python3 scripts/gen_menu_catalog.py
"""
import os
import re

SRC = os.path.join("..", "photocraft", "crates", "ui-egui", "src", "menu_catalog.rs")
OUT = os.path.join(os.path.dirname(__file__), "..", "ui", "menu_catalog.py")

src = open(SRC, encoding="utf-8").read()
body = src[src.index("CATALOG"):]

entry_re = re.compile(
    r'\(&\[([^\]]*)\],\s*"((?:[^"\\]|\\.)*)",\s*(None|Some\("(?:[^"\\]|\\.)*"\)),\s*"([^"]+)"\),')
path_re = re.compile(r'"((?:[^"\\]|\\.)*)"')

entries = []
for m in entry_re.finditer(body):
    path_raw, label, shortcut, cmd = m.group(1), m.group(2), m.group(3), m.group(4)
    path = tuple(p.replace('\\"', '"') for p in path_re.findall(path_raw))
    if shortcut.startswith("Some("):
        sc = shortcut[5:-1].replace("Cmd", "Ctrl")
    else:
        sc = None
    entries.append((path, label, sc, cmd))

lines = ['"""Photoshop menu catalog — generated from PhotoCraft\'s MIT-licensed',
         'menu_catalog.rs (scripts/gen_menu_catalog.py). Structure, labels, order,',
         'separators ("---") and default shortcuts match PhotoCraft exactly.',
         'Items whose command id has no PixelForge implementation render disabled.',
         '"""', '', 'CATALOG = [']
for path, label, sc, cmd in entries:
    lines.append(f"    ({path!r}, {label!r}, {sc!r}, {cmd!r}),")
lines.append("]")
open(OUT, "w", encoding="utf-8").write("\n".join(lines) + "\n")
print(f"wrote {len(entries)} menu entries -> {OUT}")
