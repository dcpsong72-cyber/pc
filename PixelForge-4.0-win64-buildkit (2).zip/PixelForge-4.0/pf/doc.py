"""L1 — document model v2: pixel/text/shape/adjustment layers, groups, masks,
arbitrary selection masks, layer effects. Pure data, no I/O, no Qt."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field

import numpy as np

from . import color as C


def _new_uid() -> str:
    return uuid.uuid4().hex[:12]


@dataclass(eq=False)
class Layer:
    kind: str
    name: str = "Layer"
    visible: bool = True
    opacity: float = 1.0
    blend: str = C.NORMAL
    x: int = 0
    y: int = 0
    uid: str = field(default_factory=_new_uid, init=False)
    clipped: bool = False
    mask: np.ndarray | None = None      # HxW uint8 canvas-aligned (255 reveal)
    mask_enabled: bool = True
    effects: dict = field(default_factory=dict)
    # effects: {"shadow": {dx,dy,blur,color,opacity}, "glow": {blur,color,opacity},
    #           "stroke": {width,color,opacity}}

    @property
    def w(self) -> int:
        return 0

    @property
    def h(self) -> int:
        return 0


@dataclass(eq=False)
class PixelLayer(Layer):
    kind: str = "pixel"
    pixels: np.ndarray | None = None    # HxWx4 uint8

    @property
    def w(self) -> int:
        return 0 if self.pixels is None else int(self.pixels.shape[1])

    @property
    def h(self) -> int:
        return 0 if self.pixels is None else int(self.pixels.shape[0])

    def bbox(self):
        if self.pixels is None:
            return None
        a = self.pixels[..., 3]
        ys, xs = np.nonzero(a)
        if ys.size == 0:
            return None
        return (self.x + int(xs.min()), self.y + int(ys.min()),
                self.x + int(xs.max()) + 1, self.y + int(ys.max()) + 1)


@dataclass(eq=False)
class TextLayer(Layer):
    """Live text: rasterized at compose time from params."""
    kind: str = "text"
    params: dict = field(default_factory=lambda: {
        "text": "Your text", "font": "Inter", "size": 64, "color": [26, 26, 26, 255],
        "bold": False, "italic": False, "align": "left", "line_height": 1.2,
    })
    anchor: str = "left-top"            # where x,y sits


@dataclass(eq=False)
class ShapeLayer(Layer):
    """Live vector-ish shape rasterized from params."""
    kind: str = "shape"
    params: dict = field(default_factory=lambda: {
        "shape": "rect", "w": 200, "h": 200, "fill": [90, 140, 230, 255],
        "stroke": [20, 20, 20, 255], "stroke_w": 0, "radius": 0.15, "points": 5,
    })


ADJUSTMENT_KINDS = {
    "brightness_contrast": "Brightness/Contrast",
    "levels": "Levels",
    "curves": "Curves",
    "exposure": "Exposure",
    "hue_sat": "Hue/Saturation",
    "vibrance": "Vibrance",
    "temperature": "Color Balance",
    "invert": "Invert",
    "threshold": "Threshold",
    "posterize": "Posterize",
    "bw": "Black & White",
    "photo_filter": "Photo Filter",
    "gradient_map": "Gradient Map",
    "clarity": "Clarity",
    "dehaze": "Dehaze",
    "grain": "Grain",
}

DEFAULT_ADJ_PARAMS = {
    "brightness_contrast": {"brightness": 0.0, "contrast": 0.0},
    "levels": {"black": 0.0, "white": 1.0, "gamma": 1.0},
    "curves": {"points": [[0, 0], [255, 255]]},
    "exposure": {"ev": 0.0},
    "hue_sat": {"hue": 0.0, "sat": 0.0, "light": 0.0},
    "vibrance": {"amount": 0.3},
    "temperature": {"temp": 0.0, "tint": 0.0},
    "invert": {},
    "threshold": {"level": 0.5},
    "posterize": {"levels": 4},
    "bw": {},
    "photo_filter": {"color": [255, 160, 40], "density": 0.25},
    "gradient_map": {"shadow": [20, 24, 60], "highlight": [255, 220, 160]},
    "clarity": {"amount": 0.4},
    "dehaze": {"strength": 0.5},
    "grain": {"amount": 0.15, "size": 1.0, "monochrome": True},
}


@dataclass(eq=False)
class AdjustmentLayer(Layer):
    """Non-destructive adjustment applied to the composite below it."""
    kind: str = "adjustment"
    adjustment: str = "brightness_contrast"
    params: dict = field(default_factory=dict)

    def __post_init__(self):
        base = DEFAULT_ADJ_PARAMS.get(self.adjustment, {})
        merged = dict(base)
        merged.update(self.params or {})
        self.params = merged


@dataclass(eq=False)
class GroupLayer(Layer):
    kind: str = "group"
    children: list = field(default_factory=list)
    passthrough: bool = False

    @property
    def w(self) -> int:
        return 0

    @property
    def h(self) -> int:
        return 0


@dataclass(eq=False)
class Document:
    width: int
    height: int
    layers: list = field(default_factory=list)       # bottom-to-top
    active_uid: str | None = None
    mode: str = "RGB"
    depth: int = 8
    selection: np.ndarray | None = None              # HxW bool, canvas space
    path: str | None = None
    dirty: bool = False
    warnings: list = field(default_factory=list)

    def find(self, uid: str):
        for layer, _ in self.walk():
            if layer.uid == uid:
                return layer
        return None

    def walk(self):
        def _walk(layers):
            for layer in layers:
                yield layer, layers
                if isinstance(layer, GroupLayer):
                    yield from _walk(layer.children)
        yield from _walk(self.layers)

    @property
    def active(self):
        return self.find(self.active_uid) if self.active_uid else None

    def layer_list(self) -> list:
        return [layer for layer, _ in self.walk()]

    def selection_bbox(self):
        """(x0,y0,x1,y1) of the selection mask, or None."""
        if self.selection is None or not self.selection.any():
            return None
        ys, xs = np.nonzero(self.selection)
        return (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)

    def flat_composite_list(self) -> list:
        out: list = []

        def add(layer):
            if isinstance(layer, GroupLayer):
                if layer.passthrough:
                    for child in layer.children:
                        add(child)
                    return
                from .compose import compose_children
                buffer = compose_children(layer.children, self.width, self.height)
                if buffer is not None:
                    flat = PixelLayer(name=layer.name, visible=layer.visible,
                                      opacity=layer.opacity, blend=layer.blend,
                                      x=0, y=0, pixels=buffer)
                    flat.mask = layer.mask
                    out.append(flat)
                return
            out.append(layer)

        for layer in self.layers:
            add(layer)
        return out
