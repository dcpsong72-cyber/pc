"""L0 — geometry primitives (mirror of photocraft-geom, tiny subset)."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Rect:
    x: int
    y: int
    w: int
    h: int

    @staticmethod
    def from_points(x0: int, y0: int, x1: int, y1: int) -> "Rect":
        """Normalize any two corners into a positive rect."""
        return Rect(min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0))

    @property
    def x2(self) -> int:
        return self.x + self.w

    @property
    def y2(self) -> int:
        return self.y + self.h

    def intersect(self, other: "Rect") -> "Rect | None":
        x0, y0 = max(self.x, other.x), max(self.y, other.y)
        x1, y1 = min(self.x2, other.x2), min(self.y2, other.y2)
        if x1 <= x0 or y1 <= y0:
            return None
        return Rect(x0, y0, x1 - x0, y1 - y0)

    def union(self, other: "Rect") -> "Rect":
        if other is None:
            return self
        x0, y0 = min(self.x, other.x), min(self.y, other.y)
        x1, y1 = max(self.x2, other.x2), max(self.y2, other.y2)
        return Rect(x0, y0, x1 - x0, y1 - y0)

    def is_empty(self) -> bool:
        return self.w <= 0 or self.h <= 0
