"""L4 — document I/O v2: layered PSD with masks; text/shape/adjustment layers
are rasterized (pixel-faithful) on save; PNG/JPEG/WEBP/TIFF/BMP via Pillow."""

from __future__ import annotations

import os

import numpy as np
from PIL import Image

from . import color as C
from . import compose
from .doc import (AdjustmentLayer, Document, GroupLayer, PixelLayer, ShapeLayer,
                  TextLayer)

RASTER_EXTS = {".png": "PNG", ".jpg": "JPEG", ".jpeg": "JPEG", ".bmp": "BMP",
               ".webp": "WEBP", ".tif": "TIFF", ".tiff": "TIFF"}


def read(path: str) -> Document:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".psd":
        return _read_psd(path)
    return _read_raster(path)


def _read_raster(path: str) -> Document:
    img = Image.open(path)
    warnings = []
    if img.mode not in ("RGB", "RGBA"):
        if img.mode in ("P", "PA", "L", "LA", "1", "I;16", "I"):
            img = img.convert("RGBA")
        else:
            warnings.append(f"converted from mode {img.mode}")
            img = img.convert("RGB")
    rgba = np.asarray(img.convert("RGBA"), np.uint8)
    doc = Document(width=rgba.shape[1], height=rgba.shape[0], path=path)
    doc.layers.append(PixelLayer(name=_base_name(path), pixels=rgba))
    doc.active_uid = doc.layers[0].uid
    doc.warnings = warnings
    return doc


def _read_psd(path: str) -> Document:
    from psd_tools import PSDImage
    psd = PSDImage.open(path)
    doc = Document(width=psd.width, height=psd.height, path=path)
    if psd.color_mode.name != "RGB":
        doc.warnings.append(f"PSD color mode {psd.color_mode.name} converted to RGB")
    _read_children(psd, doc.layers, doc.warnings, doc.width, doc.height)
    if doc.layers:
        doc.active_uid = doc.layers[0].uid
    return doc


def _read_children(parent, out: list, warnings: list, W: int, H: int) -> None:
    """psd_tools iterates bottom-to-top (verified against the PhotoCraft engine)."""
    from psd_tools.api.layers import Group
    for layer in parent:
        try:
            if isinstance(layer, Group):
                group = GroupLayer(name=layer.name, visible=layer.visible,
                                   opacity=_psd_opacity(layer),
                                   blend=C.PSD_TO_OURS.get(_blend_key(layer), C.NORMAL),
                                   x=int(layer.left), y=int(layer.top),
                                   passthrough=(_blend_key(layer) == "pass"))
                _read_children(layer, group.children, warnings, W, H)
                out.append(group)
            elif layer.kind == "pixel":
                img = layer.topil()
                if img is None:
                    continue
                if img.mode != "RGBA":
                    img = img.convert("RGBA")
                px = np.asarray(img, np.uint8)
                out.append(PixelLayer(name=layer.name, pixels=px, visible=layer.visible,
                                      opacity=_psd_opacity(layer),
                                      blend=C.PSD_TO_OURS.get(_blend_key(layer), C.NORMAL),
                                      x=int(layer.left), y=int(layer.top),
                                      mask=_resolve_mask(layer, W, H)))
            elif layer.kind == "type":
                warnings.append(f"text layer '{layer.name}' imported as raster")
                img = layer.topil()
                if img is not None:
                    if img.mode != "RGBA":
                        img = img.convert("RGBA")
                    out.append(PixelLayer(name=layer.name, pixels=np.asarray(img, np.uint8),
                                          visible=layer.visible, opacity=_psd_opacity(layer),
                                          x=int(layer.left), y=int(layer.top),
                                          blend=C.PSD_TO_OURS.get(_blend_key(layer), C.NORMAL)))
            else:
                warnings.append(f"skipped {layer.kind} layer '{layer.name}'")
        except Exception as exc:
            warnings.append(f"layer '{getattr(layer, 'name', '?')}': {exc}")


def _resolve_mask(layer, W: int, H: int) -> np.ndarray | None:
    """PSD user mask -> canvas-aligned uint8 array."""
    try:
        mask = layer.mask
        if mask is None:
            return None
        img = mask.topil()
        if img is None:
            return None
        m = np.asarray(img.convert("L"), np.uint8)
        ml, mt = int(getattr(mask, "left", 0) or 0), int(getattr(mask, "top", 0) or 0)
        full = np.full((H, W), 255 if getattr(mask, "default_color", 255) >= 128 else 0, np.uint8)
        h, w = m.shape
        x0, y0 = max(0, ml), max(0, mt)
        x1, y1 = min(W, ml + w), min(H, mt + h)
        if x1 > x0 and y1 > y0:
            full[y0:y1, x0:x1] = m[y0 - mt:y1 - mt, x0 - ml:x1 - ml]
        return full
    except Exception:
        return None


def _write_psd(doc: Document, path: str) -> None:
    from psd_tools import PSDImage
    from psd_tools.constants import BlendMode
    from pf import render as R
    blend_by_key = {m.value.decode("ascii", "replace"): m for m in BlendMode}
    psd = PSDImage.new(mode="rgba", size=(doc.width, doc.height), color=0)

    # Adjustment layers can't be expressed by the psd_tools builder; when the
    # doc uses them, write one visually-identical flattened layer instead.
    has_adjust = any(isinstance(l, AdjustmentLayer) for l, _ in doc.walk())
    if has_adjust:
        px = compose.composite_rgba8(doc)
        psd.create_pixel_layer(Image.fromarray(px, "RGBA"), name="Flattened")
        psd._record.image_data = _merged_image_data(psd, doc)
        psd.save(path)
        return

    # first created = bottom, last = top (verified against the PhotoCraft engine)
    for layer in doc.layer_list():
        if isinstance(layer, (TextLayer, ShapeLayer)):
            r = compose._rasterize_live(layer)
            if r is None:
                continue
            px, lx, ly = r
        elif isinstance(layer, PixelLayer):
            if layer.pixels is None:
                continue
            px, lx, ly = layer.pixels, layer.x, layer.y
        else:
            continue
        px = px.copy()
        if layer.mask is not None and layer.mask_enabled:
            a = px[..., 3].astype(np.float32) * (layer.mask / 255.0)
            px[..., 3] = np.clip(a + 0.5, 0, 255).astype(np.uint8)
        if layer.effects:
            rgb = px[..., :3].astype(np.float32) / 255.0
            a = px[..., 3].astype(np.float32) / 255.0
            rgb, a = R.apply_effects(rgb, a, layer.effects)
            px = np.concatenate([np.clip(rgb * 255 + 0.5, 0, 255).astype(np.uint8),
                                 np.clip(a[..., None] * 255 + 0.5, 0, 255).astype(np.uint8)], -1)
        psd.create_pixel_layer(
            Image.fromarray(px, "RGBA"), name=layer.name[:255],
            top=max(0, int(layer.y)), left=max(0, int(layer.x)),
            opacity=int(round(float(np.clip(layer.opacity, 0, 1)) * 255)),
            blend_mode=blend_by_key.get(C.OURS_TO_PSD.get(layer.blend, "norm"), BlendMode.NORMAL),
        )
    psd._record.image_data = _merged_image_data(psd, doc)
    psd.save(path)


def _merged_image_data(psd, doc: Document):
    from psd_tools.constants import Compression
    from psd_tools.psd.image_data import ImageData
    rgb = compose.composite_rgb8(doc)
    h, w = rgb.shape[:2]
    planes = [rgb[..., 0].tobytes(), rgb[..., 1].tobytes(), rgb[..., 2].tobytes()]
    if psd._record.header.channels == 4:
        planes.append(np.full((h, w), 255, np.uint8).tobytes())
    return ImageData(compression=Compression.RAW, data=b"".join(planes))


def write(doc: Document, path: str) -> None:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".psd":
        _write_psd(doc, path)
    elif ext == ".pcraft":
        raise ValueError("export via the PhotoCraft engine bridge for .pcraft")
    elif ext in RASTER_EXTS:
        fmt = RASTER_EXTS[ext]
        img = Image.fromarray(compose.composite_rgba8(doc), "RGBA") \
            if ext in (".png", ".webp", ".tif", ".tiff", ".bmp") else Image.fromarray(compose.composite_rgb8(doc), "RGB")
        save_kw = {"quality": 92} if fmt == "JPEG" else {}
        img.save(path, fmt, **save_kw)
    else:
        raise ValueError(f"unsupported format: {ext}")


def _blend_key(layer) -> str:
    try:
        return layer.blend_mode.value.decode("ascii", "replace")
    except Exception:
        return "norm"


def _psd_opacity(layer) -> float:
    try:
        return float(layer.opacity) / 255.0
    except Exception:
        return 1.0


def _base_name(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0]
