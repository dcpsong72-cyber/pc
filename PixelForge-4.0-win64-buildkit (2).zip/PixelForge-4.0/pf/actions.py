"""Action sets + Batch (Photoshop 27.11 Actions panel redesign, on-device).

An action set is a JSON file in assets/actions/ recording a list of engine
commands (the same dict steps Session.execute replays).  Used by the Actions
panel (record / stop / play / search) and by Batch (folder -> set -> folder).
Kept Qt-free so the engine layer and tests run headless.
"""

from __future__ import annotations

import json
import os
import time

from . import psdio

ACTIONS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "assets", "actions")

# natural-language keywords -> engine command fragments they hint at
KEYWORDS = {
    "portrait": "portraitPro", "skin": "portraitPro", "face": "portraitPro",
    "eye": "portraitPro", "eyes": "portraitPro", "retouch": "portraitPro",
    "product": "productShot", "ecommerce": "productShot", "studio": "productShot",
    "shadow": "productShot", "backdrop": "productShot",
    "light": "relight", "lighting": "relight", "relight": "relight",
    "sun": "relight", "direction": "relight",
    "old": "restoreOld", "restore": "restoreOld", "scratch": "restoreOld",
    "dust": "restoreOld", "fade": "restoreOld", "colorize": "restoreOld",
    "scan": "restoreOld",
    "watermark": "watermark", "copyright": "watermark", "logo": "watermark",
    "panorama": "photomerge", "stitch": "photomerge", "merge": "photomerge",
    "hdr": "hdrMerge", "bracket": "hdrMerge",
    "focus": "focusStack", "stack": "focusStack", "macro": "focusStack",
    "sharp": "focusStack",
    "upscale": "upscaleSmart", " enlarge": "upscaleSmart", "resolution": "upscaleSmart",
    "expand": "expandGen", "widen": "expandGen", "square": "expandGen",
    "sky": "skyReplace", "cleanup": "deleteAllEmptyLayers", "empty": "deleteAllEmptyLayers",
    "tidy": "deleteAllEmptyLayers", "layers": "deleteAllEmptyLayers",
    "distraction": "findDistractions", "spot": "findDistractions", "speck": "findDistractions",
    "rotate": "rotateObject", "blur": "filter", "vintage": "lookVintage",
    "vivid": "lookVivid", "noir": "lookNoir", "black": "lookNoir", "white": "lookNoir",
    "warm": "lookWarmCinema", "cinema": "lookWarmCinema", "teal": "lookTealOrange",
    "orange": "lookTealOrange", "cyberpunk": "lookCyberpunk", "neon": "lookCyberpunk",
}


def _ensure_dir() -> None:
    os.makedirs(ACTIONS_DIR, exist_ok=True)


def list_sets() -> list[str]:
    """Sorted action-set names found in assets/actions/*.json."""
    if not os.path.isdir(ACTIONS_DIR):
        return []
    out = []
    for fn in os.listdir(ACTIONS_DIR):
        if fn.endswith(".json"):
            try:
                with open(os.path.join(ACTIONS_DIR, fn), "r", encoding="utf-8") as f:
                    data = json.load(f)
                out.append(data.get("name", fn[:-5]))
            except Exception:
                out.append(fn[:-5])
    return sorted(out)


def set_path(name: str) -> str:
    safe = "".join(c if c.isalnum() or c in " -_" else "_" for c in name).strip() or "set"
    return os.path.join(ACTIONS_DIR, safe + ".json")


def save_set(name: str, steps: list[dict]) -> str:
    """Write an action set {"name":…, "created":…, "actions":[{cmd,params}…]}."""
    _ensure_dir()
    path = set_path(name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"name": name, "created": time.strftime("%Y-%m-%d"),
                   "actions": [dict(s) for s in steps]}, f, indent=1)
    return path


def load_set(name: str) -> list[dict]:
    """Steps for a set name (or path). Missing file -> KeyError."""
    path = name if os.path.isfile(name) else set_path(name)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f).get("actions", [])


def delete_set(name: str) -> bool:
    path = set_path(name)
    if os.path.isfile(path):
        os.remove(path)
        return True
    return False


def describe_set(name: str) -> str:
    """One-line human summary: '6 steps — Portrait Pro, Watermark, …'."""
    try:
        steps = load_set(name)
    except Exception:
        return "unreadable"
    labels = []
    for s in steps[:4]:
        cmd = s.get("cmd", "?").split(".")[-1]
        labels.append(cmd)
    more = f" …+{len(steps) - 4}" if len(steps) > 4 else ""
    return f"{len(steps)} step{'s' if len(steps) != 1 else ''}: " + ", ".join(labels) + more


def search_score(query: str, name: str) -> int:
    """Natural-language-ish relevance: query words matched against the set name
    (weight 3) and against the engine commands its steps run (weight 2), plus
    the keyword table mapping plain words ('skin', 'product', 'old photo'…)
    to command fragments (weight 1). 0 = no match."""
    q = query.lower().strip()
    if not q:
        return 1  # empty query shows everything
    words = [w for w in q.replace("→", " ").split() if w]
    steps = []
    try:
        steps = load_set(name)
    except Exception:
        pass
    cmds = " ".join(s.get("cmd", "") for s in steps).lower()
    score = 0
    for w in words:
        if w in name.lower():
            score += 3
        if w in cmds:
            score += 2
        if w in KEYWORDS and KEYWORDS[w].lower() in cmds:
            score += 1
        if w in KEYWORDS and any(KEYWORDS[w].lower() in c for c in cmds.split()):
            score += 1
        # partial stems: 'restor' should match restoreOld
        if len(w) >= 4 and w[:4] in cmds:
            score += 1
    return score


def run_steps(session, steps: list[dict], ignore_missing: bool = True) -> tuple[int, list]:
    """Replay recorded steps through session.execute.  Returns (applied, errors)."""
    from .engine import REGISTRY
    applied, errors = 0, []
    for step in steps:
        cmd = step.get("cmd", "")
        if cmd not in REGISTRY:
            if ignore_missing:
                continue
            errors.append(f"{cmd}: unknown command")
            continue
        try:
            session.execute(cmd, **step.get("params", {}))
            applied += 1
        except Exception as exc:  # keep playing, report at the end
            errors.append(f"{cmd}: {exc}")
    return applied, errors


_IMG_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff", ".psd")


def batch(session, paths: list[str], steps: list[dict], out_dir: str,
          fmt: str = "png", prefix: str = "batched") -> tuple[list, list]:
    """Folder -> action set -> folder.  Opens each image, plays the steps,
    saves to out_dir as fmt.  Non-image paths are skipped silently.
    Returns (output paths, per-file errors)."""
    import numpy as np
    os.makedirs(out_dir, exist_ok=True)
    outputs, errors = [], []
    for i, p in enumerate(paths):
        if not p.lower().endswith(_IMG_EXTS):
            continue
        try:
            session.execute("doc.open", path=p)   # session cmd: resets undo, sets doc
            run_steps(session, steps)
            base = os.path.splitext(os.path.basename(p))[0]
            out = os.path.join(out_dir, f"{prefix}_{base}.{fmt}")
            doc = session.doc
            if doc is not None:
                psdio.write(doc, out)
                outputs.append(out)
        except Exception as exc:
            errors.append(f"{os.path.basename(p)}: {exc}")
    return outputs, errors
