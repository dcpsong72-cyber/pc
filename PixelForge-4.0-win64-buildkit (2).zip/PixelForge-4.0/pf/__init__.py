"""PixelForge engine — layered like PhotoCraft's crates.

L0 foundations : color, geom
L1 doc         : document model (pure data, no Qt, no I/O)
L3 compose     : numpy compositor
L4 io          : psdio (PSD via psd-tools, raster via Pillow), bridge (PhotoCraft)
L5 engine      : command registry + history — every action is a command
"""

from . import color, geom, doc, compose, engine, psdio, bridge  # noqa: F401

__version__ = "0.1.0"
