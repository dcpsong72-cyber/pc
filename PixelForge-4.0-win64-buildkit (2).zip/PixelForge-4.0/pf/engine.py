"""L5 — engine v2: command registry + history. Every action is a command.

Protocol: cmd(session, **params) -> (result, undo_fn, redo_fn)
Session-level commands (doc.new/doc.open) manage the document themselves.
"""

from __future__ import annotations

import os

import copy
import uuid
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from scipy import ndimage as _ndi

from . import adjust as ADJ
from . import compose, filters as F, psdio, render as R
from .doc import (ADJUSTMENT_KINDS, AdjustmentLayer, Document, GroupLayer, Layer,
                  PixelLayer, ShapeLayer, TextLayer)

HISTORY_LIMIT = 120


# ------------------------------------------------------------------ session
@dataclass
class Session:
    doc: Document | None = None
    undo_stack: list = field(default_factory=list)
    redo_stack: list = field(default_factory=list)
    listeners: dict = field(default_factory=dict)
    foreground: tuple = (0, 0, 0, 255)
    background: tuple = (255, 255, 255, 255)
    recording: bool = False          # Actions-panel record mode
    record_buffer: list = field(default_factory=list)  # [{cmd, params}, ...]

    def on(self, event: str, cb: Callable) -> None:
        self.listeners.setdefault(event, []).append(cb)

    def emit(self, event: str, **kw) -> None:
        for cb in self.listeners.get(event, []):
            try:
                cb(**kw)
            except Exception:
                pass

    def push(self, label: str, undo_fn: Callable, redo_fn: Callable) -> None:
        self.undo_stack.append((label, undo_fn, redo_fn))
        if len(self.undo_stack) > HISTORY_LIMIT:
            self.undo_stack.pop(0)
        self.redo_stack.clear()
        if self.doc is not None:
            self.doc.dirty = True
        self.emit("history")
        self.emit("doc")

    def undo(self) -> bool:
        if not self.undo_stack or self.doc is None:
            return False
        label, undo_fn, redo_fn = self.undo_stack.pop()
        undo_fn(self)
        self.redo_stack.append((label, undo_fn, redo_fn))
        self.emit("history")
        self.emit("doc")
        return True

    def redo(self) -> bool:
        if not self.redo_stack or self.doc is None:
            return False
        label, undo_fn, redo_fn = self.redo_stack.pop()
        redo_fn(self)
        self.undo_stack.append((label, undo_fn, redo_fn))
        self.emit("history")
        self.emit("doc")
        return True

    def history_labels(self) -> list:
        return [e[0] for e in self.undo_stack]

    def execute(self, cmd_id: str, /, record: bool = True, **params):
        cmd = REGISTRY.get(cmd_id)
        if cmd is None:
            raise KeyError(f"unknown command `{cmd_id}`")
        if getattr(self, "recording", False) and cmd_id != "doc.open":
            clean = {k: v for k, v in params.items()
                     if isinstance(v, (int, float, str, bool, list, tuple))}
            self.record_buffer = getattr(self, "record_buffer", [])
            self.record_buffer.append({"cmd": cmd_id, "params": clean})
        if getattr(cmd, "__session_cmd__", False):
            return cmd(self, **params)
        result, undo_fn, redo_fn = cmd(self, **params)
        if record and undo_fn is not None:
            self.push(cmd.__label__, undo_fn, redo_fn)
        else:
            self.emit("doc")
        return result


# ------------------------------------------------------------- undo helpers
def _snapshot_layers(doc: Document):
    """Shallow structural snapshot: SAME layer objects, copied list.

    Structural commands rebuild doc.layers with clone lists (never mutate
    existing layer objects), so restoring the old list keeps every identity-
    based undo closure valid.
    """
    return list(doc.layers), doc.active_uid


def _restore_layers(session: Session, snapshot) -> None:
    session.doc.layers, session.doc.active_uid = snapshot[0], snapshot[1]


def _sel_mask(doc: Document) -> np.ndarray:
    if doc.selection is not None and doc.selection.any():
        return doc.selection.astype(bool)
    return np.ones((doc.height, doc.width), bool)


def _clone_layer(layer, **overrides):
    """Structural copy for image-wide ops (rotate/flip/canvas/crop)."""
    fields = {f.name: getattr(layer, f.name) for f in type(layer).__dataclass_fields__.values()}
    for key in ("pixels", "mask", "uid", "x", "y"):
        fields.pop(key, None)
    clone = type(layer)(**fields)
    clone.uid = layer.uid
    clone.pixels = getattr(layer, "pixels", None)
    clone.mask = layer.mask
    clone.x = overrides.pop("x", layer.x)
    clone.y = overrides.pop("y", layer.y)
    for k, v in overrides.items():
        setattr(clone, k, v)
    return clone


def _stamp_px(layer: PixelLayer):
    return layer.pixels if layer.pixels is not None else np.zeros((1, 1, 4), np.uint8)


# ---------------------------------------------------------------- documents
def cmd_doc_new(session: Session, width=1200, height=800, background=(255, 255, 255),
                transparent=False) -> Document:
    doc = Document(width=int(width), height=int(height), path=None)
    if transparent or background is None:
        px = np.zeros((int(height), int(width), 4), np.uint8)
    else:
        px = np.zeros((int(height), int(width), 4), np.uint8)
        px[..., :3] = background
        px[..., 3] = 255
    doc.layers.append(PixelLayer(name="Background", pixels=px))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return doc


def cmd_doc_open(session: Session, path: str) -> Document:
    doc = psdio.read(path)
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return doc


def cmd_doc_save(session: Session, path: str):
    psdio.write(session.doc, path)
    session.doc.path = path
    session.doc.dirty = False
    return path, None, None


def cmd_doc_place(session: Session, path: str, x=None, y=None, scale=None):
    """Insert an image file as a new layer (Canva 'upload')."""
    img_doc = psdio.read(path)
    src = compose.composite_rgba8(img_doc)
    doc = session.doc
    s = 1.0
    if scale:
        s = float(scale)
    elif src.shape[0] > doc.height or src.shape[1] > doc.width:
        s = min(doc.height / src.shape[0], doc.width / src.shape[1], 1.0)
    if s != 1.0:
        from PIL import Image
        w2, h2 = max(1, int(src.shape[1] * s)), max(1, int(src.shape[0] * s))
        src = np.asarray(Image.fromarray(src).resize((w2, h2), Image.LANCZOS), np.uint8)
    layer = PixelLayer(name=_base(path), pixels=src,
                       x=int(x if x is not None else (doc.width - src.shape[1]) // 2),
                       y=int(y if y is not None else (doc.height - src.shape[0]) // 2))
    doc.layers.append(layer)
    doc.active_uid = layer.uid
    def undo(s):
        s.doc.layers.remove(layer)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    def redo(s):
        s.doc.layers.append(layer)
        s.doc.active_uid = layer.uid
    return layer.uid, undo, redo


def _base(path):
    import os
    return os.path.splitext(os.path.basename(path))[0]


# ------------------------------------------------------------------ layers
def cmd_layer_add(session: Session, name="Layer", pixels=None, fill=None):
    doc = session.doc
    layer = PixelLayer(name=name, pixels=pixels)
    if pixels is None:
        layer.pixels = np.zeros((doc.height, doc.width, 4), np.uint8)
        if fill is not None:
            layer.pixels[..., :3] = fill
            layer.pixels[..., 3] = 255
    doc.layers.append(layer)
    doc.active_uid = layer.uid
    def undo(s):
        s.doc.layers.remove(layer)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    def redo(s):
        s.doc.layers.append(layer)
        s.doc.active_uid = layer.uid
    return layer.uid, undo, redo


def cmd_layer_add_group(session: Session, name="Group"):
    doc = session.doc
    group = GroupLayer(name=name)
    doc.layers.append(group)
    doc.active_uid = group.uid
    def undo(s):
        s.doc.layers.remove(group)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    def redo(s):
        s.doc.layers.append(group)
        s.doc.active_uid = group.uid
    return group.uid, undo, redo


def cmd_layer_remove(session: Session, uid: str | None = None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None:
        return None, None, None
    top = _top_ancestor(doc, layer)
    idx = doc.layers.index(top)
    doc.layers.remove(top)
    doc.active_uid = doc.layers[-1].uid if doc.layers else None
    def undo(s):
        s.doc.layers.insert(min(idx, len(s.doc.layers)), top)
        s.doc.active_uid = top.uid
    def redo(s):
        if top in s.doc.layers:
            s.doc.layers.remove(top)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    return layer.uid, undo, redo


def cmd_layer_duplicate(session: Session, uid: str | None = None):
    doc = session.doc
    src = doc.find(uid) if uid else doc.active
    if src is None:
        return None, None, None
    dup = copy.deepcopy(src)
    dup.uid = uuid.uuid4().hex[:12]
    dup.name = f"{src.name} copy"
    parent_list, idx = _locate(doc, src)
    parent_list.insert(idx + 1, dup)
    doc.active_uid = dup.uid
    def undo(s):
        d = s.doc.find(dup.uid)
        if d is not None:
            plist, _ = _locate(s.doc, d)
            plist.remove(d)
        s.doc.active_uid = src.uid
    def redo(s):
        target = s.doc.find(src.uid)
        plist, i = _locate(s.doc, target) if target is not None else (s.doc.layers, len(s.doc.layers) - 1)
        plist.insert(i + 1, dup)
        s.doc.active_uid = dup.uid
    return dup.uid, undo, redo


def cmd_layer_select(session: Session, uid: str):
    doc = session.doc
    prev = doc.active_uid
    doc.active_uid = uid
    def undo(s): s.doc.active_uid = prev
    def redo(s): s.doc.active_uid = uid
    session.emit("doc")
    return uid, undo, redo


def cmd_layer_set_props(session: Session, uid: str | None = None, **props):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None:
        return None, None, None
    allowed = {k: v for k, v in props.items()
               if hasattr(layer, k) and k not in ("uid", "kind", "pixels", "children")}
    before = {k: getattr(layer, k) for k in allowed}
    for k, v in allowed.items():
        setattr(layer, k, v)
    def undo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            for k, v in before.items():
                setattr(lay, k, v)
    def redo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            for k, v in allowed.items():
                setattr(lay, k, v)
    return layer.uid, undo, redo


def cmd_layer_reorder(session: Session, uid: str, to_flat_index: int):
    doc = session.doc
    layer = doc.find(uid)
    if layer is None:
        return None, None, None
    top = _top_ancestor(doc, layer)
    from_idx = doc.layers.index(top)
    to_idx = int(np.clip(to_flat_index, 0, len(doc.layers) - 1))
    if from_idx == to_idx:
        return None, None, None
    doc.layers.insert(to_idx, doc.layers.pop(from_idx))
    def undo(s):
        s.doc.layers.insert(from_idx, s.doc.layers.pop(to_idx))
    def redo(s):
        s.doc.layers.insert(to_idx, s.doc.layers.pop(from_idx))
    return uid, undo, redo


def cmd_layer_translate(session: Session, dx=0, dy=0, uid: str | None = None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None or isinstance(layer, (GroupLayer, AdjustmentLayer)):
        return None, None, None
    dx, dy = int(dx), int(dy)
    if dx == 0 and dy == 0:
        return None, None, None
    layer.x += dx
    layer.y += dy
    def undo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            lay.x -= dx
            lay.y -= dy
    def redo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            lay.x += dx
            lay.y += dy
    return layer.uid, undo, redo


def cmd_layer_move_pixels(session: Session, dx=0, dy=0, uid=None):
    """Shift a pixel layer's content (leaves layer.x/y; vacated area transparent)."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    dx, dy = int(dx), int(dy)
    if dx == 0 and dy == 0:
        return None, None, None
    before = layer.pixels.copy()
    h, w = before.shape[:2]
    shifted = np.zeros_like(before)
    sx0, sx1 = max(0, -dx), min(w, w - dx)
    sy0, sy1 = max(0, -dy), min(h, h - dy)
    if sx1 > sx0 and sy1 > sy0:
        shifted[sy0 + dy:sy1 + dy, sx0 + dx:sx1 + dx] = before[sy0:sy1, sx0:sx1]
    layer.pixels = shifted
    def undo(s):
        lay = s.doc.find(layer.uid)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(layer.uid)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = shifted
    return layer.uid, undo, redo


# ------------------------------------------------------------- layer masks
def cmd_layer_mask_new(session: Session, mode="reveal", uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None or isinstance(layer, AdjustmentLayer):
        return None, None, None
    if mode == "from_sel" and doc.selection is not None:
        m = np.zeros((doc.height, doc.width), np.uint8)
        m[doc.selection] = 255
    elif doc.selection is not None and mode == "reveal":
        m = np.zeros((doc.height, doc.width), np.uint8)
        m[doc.selection] = 255
    else:
        m = np.full((doc.height, doc.width), 255 if mode == "reveal" else 0, np.uint8)
    prev = layer.mask
    layer.mask = m
    layer.mask_enabled = True
    def undo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            lay.mask = prev
    def redo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            lay.mask = m
            lay.mask_enabled = True
    return layer.uid, undo, redo


def cmd_layer_mask_delete(session: Session, apply=False, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None or layer.mask is None:
        return None, None, None
    prev_mask = layer.mask
    prev_pixels = layer.pixels.copy() if isinstance(layer, PixelLayer) and layer.pixels is not None else None
    if apply and prev_pixels is not None and isinstance(layer, PixelLayer):
        a = layer.pixels[..., 3].astype(np.float32) * (prev_mask / 255.0)
        layer.pixels[..., 3] = np.clip(a + 0.5, 0, 255).astype(np.uint8)
    layer.mask = None
    def undo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            lay.mask = prev_mask
            if prev_pixels is not None and isinstance(lay, PixelLayer):
                lay.pixels = prev_pixels
    def redo(s):
        lay = s.doc.find(layer.uid)
        if lay:
            lay.mask = None
    return layer.uid, undo, redo


def cmd_layer_mask_paint(session: Session, points, size=20, hardness=0.7,
                         value=255, uid=None):
    """Paint black/white on the layer's mask (erase=True paints value 0)."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None or layer.mask is None:
        return None, None, None
    before = layer.mask.copy()
    for (x, y) in points:
        _stamp_gray(layer.mask, int(x), int(y), size, hardness, int(value))
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.mask = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.mask = layer.mask
    return uid_, undo, redo


def _stamp_gray(mask: np.ndarray, x: int, y: int, size: int, hardness: float, value: int):
    from .engine import _stroke_stamp  # reuse profile math
    r = max(1, int(size) // 2)
    h, w = mask.shape
    x0, x1 = max(0, x - r), min(w, x + r + 1)
    y0, y1 = max(0, y - r), min(h, y + r + 1)
    if x1 <= x0 or y1 <= y0:
        return
    yy, xx = np.mgrid[y0:y1, x0:x1]
    dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2) / max(r, 1e-6)
    soft = 1.0 - float(np.clip(hardness, 0.0, 1.0))
    profile = np.clip((1.0 - dist) / max(soft, 0.02), 0.0, 1.0) if soft > 0.001 else (dist <= 1.0).astype(np.float32)
    region = mask[y0:y1, x0:x1].astype(np.float32)
    target = float(value)
    mask[y0:y1, x0:x1] = np.clip(np.maximum(region, profile * target) + 0.5, 0, 255).astype(np.uint8) \
        if value >= 128 else np.clip(np.minimum(region, (1 - profile) * 255) + 0.5, 0, 255).astype(np.uint8)


# --------------------------------------------------------------- selections
def cmd_selection_set_mask(session: Session, mask=None):
    doc = session.doc
    prev = doc.selection
    if mask is not None:
        mask = np.asarray(mask).astype(bool)
        if mask.shape != (doc.height, doc.width):
            full = np.zeros((doc.height, doc.width), bool)
            h = min(doc.height, mask.shape[0]); w = min(doc.width, mask.shape[1])
            full[:h, :w] = mask[:h, :w]
            mask = full
    doc.selection = mask
    def undo(s): s.doc.selection = prev
    def redo(s): s.doc.selection = mask
    session.emit("doc")
    return (mask is not None), undo, redo


def cmd_selection_rect(session: Session, rect):
    doc = session.doc
    m = np.zeros((doc.height, doc.width), bool)
    x0, y0, x1, y1 = [int(v) for v in rect]
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(doc.width, x1), min(doc.height, y1)
    if x1 > x0 and y1 > y0:
        m[y0:y1, x0:x1] = True
    return cmd_selection_set_mask(session, m if m.any() else None)


def cmd_selection_ellipse(session: Session, rect):
    doc = session.doc
    m = np.zeros((doc.height, doc.width), bool)
    x0, y0, x1, y1 = [int(v) for v in rect]
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(doc.width, x1), min(doc.height, y1)
    if x1 > x0 and y1 > y0:
        yy, xx = np.mgrid[y0:y1, x0:x1]
        cx, cy = (x0 + x1 - 1) / 2, (y0 + y1 - 1) / 2
        rx, ry = max(1e-6, (x1 - x0) / 2), max(1e-6, (y1 - y0) / 2)
        m[y0:y1, x0:x1] = (((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2) <= 1.0
    return cmd_selection_set_mask(session, m if m.any() else None)


def cmd_selection_polygon(session: Session, points):
    """Freehand lasso: fill the polygon."""
    doc = session.doc
    if len(points) < 3:
        return cmd_selection_set_mask(session, None)
    from PIL import Image, ImageDraw
    img = Image.new("L", (doc.width, doc.height), 0)
    d = ImageDraw.Draw(img)
    d.polygon([(float(x), float(y)) for x, y in points], fill=255)
    m = np.asarray(img) > 0
    return cmd_selection_set_mask(session, m if m.any() else None)


def cmd_selection_magic_wand(session: Session, x, y, tolerance=32, contiguous=True):
    doc = session.doc
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None:
        return None, None, None
    x, y = int(np.clip(x, 0, doc.width - 1)), int(np.clip(y, 0, doc.height - 1))
    target = comp[y, x].astype(np.int16)
    diff = np.abs(comp.astype(np.int16) - target).max(-1)
    m = diff <= tolerance
    if contiguous and cv2_ok():
        import cv2
        ff = np.where(m, 255, 0).astype(np.uint8)
        mask2 = np.zeros((doc.height + 2, doc.width + 2), np.uint8)
        cv2.floodFill(ff, mask2, (int(x), int(y)), 128, loDiff=0, upDiff=0, flags=4)
        m = ff == 128
    elif contiguous:
        from scipy import ndimage
        lab, _ = ndimage.label(m)
        m = lab == lab[y, x]
    m &= m
    return cmd_selection_set_mask(session, m if m.any() else None)


def cmd_selection_all(session: Session):
    doc = session.doc
    return cmd_selection_set_mask(session, np.ones((doc.height, doc.width), bool))


def cmd_selection_deselect(session: Session):
    return cmd_selection_set_mask(session, None)


def cmd_selection_color_range(session: Session, color, tolerance=48):
    doc = session.doc
    comp = compose.composite_rgba8(doc)
    target = np.array(color[:3], np.int16)
    diff = np.abs(comp[..., :3].astype(np.int16) - target).max(-1)
    m = diff <= tolerance
    return cmd_selection_set_mask(session, m if m.any() else None)


def cmd_selection_invert(session: Session):
    doc = session.doc
    prev = doc.selection
    if prev is None:
        return None, None, None
    inv = ~prev
    doc.selection = inv
    def undo(s): s.doc.selection = prev
    def redo(s): s.doc.selection = inv
    session.emit("doc")
    return True, undo, redo


def cmd_selection_feather(session: Session, radius=4.0):
    doc = session.doc
    prev = doc.selection
    if prev is None:
        return None, None, None
    soft = _ndi.gaussian_filter(prev.astype(np.float32), radius)
    doc.selection = soft > 0.5  # crisp core; feathering applied at usage time below
    doc.selection_soft = soft   # TODO engine-level soft mask use
    def undo(s):
        s.doc.selection = prev
        if hasattr(s.doc, "selection_soft"): del s.doc.selection_soft
    def redo(s):
        s.doc.selection = soft > 0.5
        s.doc.selection_soft = soft
    session.emit("doc")
    return True, undo, redo


def cmd_selection_grow_contract(session: Session, px=3):
    doc = session.doc
    prev = doc.selection
    if prev is None:
        return None, None, None
    if px >= 0:
        m = _ndi.binary_dilation(prev, iterations=int(px))
    else:
        m = _ndi.binary_erosion(prev, iterations=int(-px))
    doc.selection = m
    def undo(s): s.doc.selection = prev
    def redo(s): s.doc.selection = m
    session.emit("doc")
    return True, undo, redo


def cmd_selection_subject(session: Session):
    """Select Subject: GrabCut on the composite (cv2)."""
    doc = session.doc
    if cv2_ok():
        import cv2
        comp = compose.composite_rgb8(doc)
        scale = min(1.0, 640.0 / max(comp.shape[:2]))
        small = cv2.resize(comp, (0, 0), fx=scale, fy=scale,
                           interpolation=cv2.INTER_AREA) if scale < 1.0 else comp
        rgb = cv2.cvtColor(small, cv2.COLOR_RGB2BGR)
        mask = np.zeros(small.shape[:2], np.uint8)
        bgd = np.zeros((1, 65), np.float64)
        fgd = np.zeros((1, 65), np.float64)
        pad = int(min(small.shape[0], small.shape[1]) * 0.04) + 2
        rect = (pad, pad, small.shape[1] - 2 * pad, small.shape[0] - 2 * pad)
        cv2.grabCut(rgb, mask, rect, bgd, fgd, 4, cv2.GC_INIT_WITH_RECT)
        m8 = ((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)).astype(np.uint8) * 255
        if scale < 1.0:
            m8 = cv2.resize(m8, (doc.width, doc.height), interpolation=cv2.INTER_LINEAR)
        m = m8 > 127
        m = _ndi.binary_opening(m, iterations=2)
        m = _ndi.binary_dilation(m, iterations=1)
        if m.sum() < 0.01 * doc.width * doc.height:
            m = np.ones_like(m)
        return cmd_selection_set_mask(session, m)
    # graceful fallback: center ellipse
    return cmd_selection_ellipse(session, (int(doc.width * .1), int(doc.height * .1),
                                           int(doc.width * .9), int(doc.height * .9)))


def cv2_ok():
    import importlib
    try:
        importlib.import_module("cv2")
        return True
    except Exception:
        return False


# ---------------------------------------------------- text / shape / adjust
def cmd_layer_new_text(session: Session, x=40, y=40, **params):
    doc = session.doc
    layer = TextLayer(x=int(x), y=int(y))
    layer.params.update(params or {})
    layer.name = (layer.params.get("text", "Text")[:24] or "Text")
    doc.layers.append(layer)
    doc.active_uid = layer.uid
    def undo(s):
        s.doc.layers.remove(layer)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    def redo(s):
        s.doc.layers.append(layer)
        s.doc.active_uid = layer.uid
    return layer.uid, undo, redo


def cmd_layer_set_text(session: Session, uid: str | None = None, **params):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, TextLayer):
        return None, None, None
    before = dict(layer.params)
    before_xy = (layer.x, layer.y)
    layer.params.update(params)
    layer.name = (layer.params.get("text", "Text")[:24] or "Text")
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.params = dict(before)
            lay.x, lay.y = before_xy
    def redo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.params.update(params)
    return uid_, undo, redo


def cmd_layer_new_shape(session: Session, x=40, y=40, **params):
    doc = session.doc
    layer = ShapeLayer(x=int(x), y=int(y))
    layer.params.update(params or {})
    layer.name = str(layer.params.get("shape", "Shape")).title()
    doc.layers.append(layer)
    doc.active_uid = layer.uid
    def undo(s):
        s.doc.layers.remove(layer)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    def redo(s):
        s.doc.layers.append(layer)
        s.doc.active_uid = layer.uid
    return layer.uid, undo, redo


def cmd_layer_set_shape(session: Session, uid: str | None = None, **params):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, ShapeLayer):
        return None, None, None
    before = dict(layer.params)
    before_xy = (layer.x, layer.y)
    layer.params.update(params)
    layer.name = str(layer.params.get("shape", "Shape")).title()
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.params = dict(before)
            lay.x, lay.y = before_xy
    def redo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.params.update(params)
    return uid_, undo, redo


def cmd_layer_new_adjustment(session: Session, kind: str, **params):
    doc = session.doc
    if kind not in ADJUSTMENT_KINDS:
        raise ValueError(f"unknown adjustment `{kind}`")
    layer = AdjustmentLayer(adjustment=kind, params=params or {}, name=ADJUSTMENT_KINDS[kind])
    doc.layers.append(layer)
    doc.active_uid = layer.uid
    def undo(s):
        s.doc.layers.remove(layer)
        s.doc.active_uid = s.doc.layers[-1].uid if s.doc.layers else None
    def redo(s):
        s.doc.layers.append(layer)
        s.doc.active_uid = layer.uid
    return layer.uid, undo, redo


def cmd_layer_set_adjustment(session: Session, uid: str | None = None, **params):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, AdjustmentLayer):
        return None, None, None
    before = dict(layer.params)
    layer.params.update(params)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.params = dict(before)
    def redo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.params.update(params)
    return uid_, undo, redo


# ------------------------------------------------------------ layer effects
def cmd_layer_set_effects(session: Session, effects: dict, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None or isinstance(layer, (GroupLayer, AdjustmentLayer)):
        return None, None, None
    before = copy.deepcopy(layer.effects)
    layer.effects = copy.deepcopy(effects or {})
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.effects = copy.deepcopy(before)
    def redo(s):
        lay = s.doc.find(uid_)
        if lay:
            lay.effects = copy.deepcopy(layer.effects)
    return uid_, undo, redo


# --------------------------------------------------------------- transform
def cmd_layer_transform(session: Session, scale_x=1.0, scale_y=1.0, rotate=0.0,
                        uid=None, smooth=True):
    """Free transform: scale+rotate the layer's content about its center."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    pixels, lx, ly = None, 0, 0
    if isinstance(layer, PixelLayer):
        pixels, lx, ly = layer.pixels, layer.x, layer.y
    elif isinstance(layer, (TextLayer, ShapeLayer)):
        r = compose._rasterize_live(layer)
        if r is None:
            return None, None, None
        pixels, lx, ly = r
    else:
        return None, None, None
    if pixels is None or (abs(scale_x - 1) < 1e-3 and abs(scale_y - 1) < 1e-3 and abs(rotate) < 1e-3):
        return None, None, None
    from PIL import Image
    sx, sy = float(np.clip(scale_x, 0.02, 20)), float(np.clip(scale_y, 0.02, 20))
    ang = float(rotate)
    h, w = pixels.shape[:2]
    nw, nh = max(1, int(round(w * sx))), max(1, int(round(h * sy)))
    img = Image.fromarray(pixels, "RGBA")
    resized = img.resize((nw, nh), Image.LANCZOS if smooth else Image.NEAREST)
    if abs(ang) > 1e-3:
        resized = resized.rotate(-ang, resample=Image.BICUBIC, expand=True,
                                 fillcolor=(0, 0, 0, 0))
    new_px = np.asarray(resized, np.uint8)
    # keep the center anchored
    ncx = lx + w / 2
    ncy = ly + h / 2
    nx, ny = int(round(ncx - new_px.shape[1] / 2)), int(round(ncy - new_px.shape[0] / 2))

    before_px, before_x, before_y = pixels, lx, ly
    uid_ = layer.uid

    if isinstance(layer, PixelLayer):
        layer.pixels = new_px
        layer.x, layer.y = nx, ny
        def undo(s):
            lay = s.doc.find(uid_)
            if lay is not None and isinstance(lay, PixelLayer):
                lay.pixels = before_px
                lay.x, lay.y = before_x, before_y
        def redo(s):
            lay = s.doc.find(uid_)
            if lay is not None and isinstance(lay, PixelLayer):
                lay.pixels = new_px
                lay.x, lay.y = nx, ny
    else:  # live layer: bake params change into x/y (approximation: rasterized move)
        def undo(s):
            lay = s.doc.find(uid_)
            if lay:
                lay.x, lay.y = before_x, before_y
        def redo(s):
            lay = s.doc.find(uid_)
            if lay:
                lay.x, lay.y = nx, ny
    return uid_, undo, redo


def cmd_layer_flip(session: Session, horizontal=True, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    before = layer.pixels
    layer.pixels = np.ascontiguousarray(layer.pixels[:, ::-1] if horizontal else layer.pixels[::-1])
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_layer_rotate90(session: Session, ccw=False, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    before = layer.pixels
    before_xy = (layer.x, layer.y)
    h, w = layer.pixels.shape[:2]
    layer.pixels = np.ascontiguousarray(np.rot90(layer.pixels, 1 if ccw else -1))
    dx = (h - w) / 2
    layer.x += int(round(-dx if not ccw else dx))
    layer.y += int(round(dx if not ccw else -dx))
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
            lay.x, lay.y = before_xy
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


# -------------------------------------------------------------- image menu
def cmd_image_canvas_size(session: Session, width, height, anchor="center"):
    doc = session.doc
    snapshot = _snapshot_layers(doc)
    old_w, old_h = doc.width, doc.height
    width, height = max(1, int(width)), max(1, int(height))
    ax = {"left": 0, "center": (width - old_w) // 2, "right": width - old_w}[anchor if anchor in ("left", "center", "right") else "center"]
    ay = {"top": 0, "center": (height - old_h) // 2, "bottom": height - old_h}[anchor if anchor in ("top", "center", "bottom") else "center"]

    def shift_list(layers):
        out = []
        for layer in layers:
            if isinstance(layer, GroupLayer):
                out.append(GroupLayer(kind="group", name=layer.name, visible=layer.visible,
                                      opacity=layer.opacity, blend=layer.blend,
                                      children=shift_list(layer.children),
                                      passthrough=layer.passthrough, mask=layer.mask,
                                      x=layer.x + ax, y=layer.y + ay))
            else:
                out.append(_clone_layer(layer, x=layer.x + ax, y=layer.y + ay))
                out[-1].pixels = getattr(layer, "pixels", None)
        return out

    doc.layers = shift_list(doc.layers)
    doc.width, doc.height = width, height
    doc.selection = None
    def undo(s):
        _restore_layers(s, snapshot)
        s.doc.width, s.doc.height = old_w, old_h
    def redo(s):
        s.doc.layers = shift_list(s.doc.layers)
        s.doc.width, s.doc.height = width, height
    return (width, height), undo, redo


def cmd_image_rotate_canvas(session: Session, degrees=90):
    doc = session.doc
    snapshot = _snapshot_layers(doc)
    old_w, old_h = doc.width, doc.height
    k = {90: -1, 180: 2, 270: 1, -90: 1}.get(int(degrees) % 360, -1)
    new_w, new_h = (old_h, old_w) if int(degrees) % 180 else (old_w, old_h)

    def _size_of(layer):
        if isinstance(layer, PixelLayer) and layer.pixels is not None:
            return layer.pixels.shape[:2]  # h, w
        r = compose._rasterize_live(layer)
        if r is not None:
            return r[0].shape[:2]
        return 0, 0

    def rot(layers):
        out = []
        for layer in layers:
            if isinstance(layer, GroupLayer):
                out.append(GroupLayer(kind="group", name=layer.name, visible=layer.visible,
                                      opacity=layer.opacity, blend=layer.blend,
                                      children=rot(layer.children),
                                      passthrough=layer.passthrough, mask=layer.mask,
                                      x=layer.x, y=layer.y))
                continue
            clone = _clone_layer(layer)
            if isinstance(layer, PixelLayer) and layer.pixels is not None:
                clone.pixels = np.ascontiguousarray(np.rot90(layer.pixels, k))
            ph, pw = _size_of(layer)
            if ph and pw:
                if k == -1:
                    clone.x, clone.y = old_h - layer.y - ph, layer.x
                elif k == 1:
                    clone.x, clone.y = layer.y, old_w - layer.x - pw
                else:
                    clone.x, clone.y = old_w - layer.x - pw, old_h - layer.y - ph
            out.append(clone)
        return out

    doc.layers = rot(doc.layers)
    doc.width, doc.height = new_w, new_h
    doc.selection = None
    def undo(s):
        _restore_layers(s, snapshot)
        s.doc.width, s.doc.height = old_w, old_h
    def redo(s):
        s.doc.layers = rot(s.doc.layers)
        s.doc.width, s.doc.height = new_w, new_h
    return int(degrees), undo, redo


def cmd_image_flip_canvas(session: Session, horizontal=True):
    doc = session.doc
    snapshot = _snapshot_layers(doc)
    old_w, old_h = doc.width, doc.height

    def flip(layers):
        out = []
        for layer in layers:
            clone = _clone_layer(layer)
            if isinstance(layer, GroupLayer):
                clone.children = flip(layer.children)
            if isinstance(layer, PixelLayer) and layer.pixels is not None:
                clone.pixels = np.ascontiguousarray(layer.pixels[:, ::-1] if horizontal else layer.pixels[::-1])
                pw, ph = layer.w, layer.h
            else:
                r = compose._rasterize_live(layer)
                pw, ph = (r[0].shape[1], r[0].shape[0]) if r else (0, 0)
            if horizontal:
                clone.x = old_w - layer.x - pw
            else:
                clone.y = old_h - layer.y - ph
            out.append(clone)
        return out

    doc.layers = flip(doc.layers)
    doc.selection = None
    def undo(s):
        _restore_layers(s, snapshot)
    def redo(s):
        s.doc.layers = flip(s.doc.layers)
    return horizontal, undo, redo


def cmd_image_trim(session: Session, tolerance=1):
    """Trim transparent borders (like Photoshop Trim, transparent pixels)."""
    doc = session.doc
    comp = compose.composite_rgba8(doc)
    a = comp[..., 3]
    ys, xs = np.nonzero(a > 0)
    if ys.size == 0:
        return None, None, None
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    return cmd_image_crop(session, (x0, y0, x1, y1))


def cmd_image_crop(session: Session, rect):
    doc = session.doc
    x0, y0, x1, y1 = [int(v) for v in rect]
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(doc.width, x1), min(doc.height, y1)
    if x1 <= x0 or y1 <= y0:
        return None, None, None
    snapshot = _snapshot_layers(doc)
    old_w, old_h = doc.width, doc.height

    def shift(layers):
        out = []
        for layer in layers:
            if isinstance(layer, GroupLayer):
                out.append(GroupLayer(kind="group", name=layer.name, visible=layer.visible,
                                      opacity=layer.opacity, blend=layer.blend,
                                      children=shift(layer.children),
                                      passthrough=layer.passthrough, mask=layer.mask,
                                      x=layer.x - x0, y=layer.y - y0))
            else:
                clone = _clone_layer(layer)
                clone.mask = _crop_mask(layer.mask, x0, y0, x1, y1)
                if isinstance(layer, PixelLayer) and layer.pixels is not None:
                    cx0, cy0 = max(x0, layer.x), max(y0, layer.y)
                    cx1, cy1 = min(x1, layer.x + layer.w), min(y1, layer.y + layer.h)
                    if cx1 <= cx0 or cy1 <= cy0:
                        continue
                    clone.pixels = layer.pixels[cy0 - layer.y:cy1 - layer.y, cx0 - layer.x:cx1 - layer.x].copy()
                    clone.x, clone.y = cx0 - x0, cy0 - y0
                else:
                    clone.pixels = getattr(layer, "pixels", None)
                    clone.x = getattr(layer, "x", 0) - x0
                    clone.y = getattr(layer, "y", 0) - y0
                out.append(clone)
        return out

    doc.layers = shift(doc.layers)
    doc.width, doc.height = x1 - x0, y1 - y0
    doc.selection = None
    def undo(s):
        _restore_layers(s, snapshot)
        s.doc.width, s.doc.height = old_w, old_h
    def redo(s):
        s.doc.layers = shift(s.doc.layers)
        s.doc.width, s.doc.height = x1 - x0, y1 - y0
    return (x0, y0, x1, y1), undo, redo


def _crop_mask(mask, x0, y0, x1, y1):
    if mask is None:
        return None
    out = np.zeros((y1 - y0, x1 - x0), np.uint8)
    h, w = mask.shape
    cx0, cy0 = max(x0, 0), max(y0, 0)
    cx1, cy1 = min(x1, w), min(y1, h)
    if cx1 > cx0 and cy1 > cy0:
        out[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0] = mask[cy0:cy1, cx0:cx1]
    return out


def layer0_check(*a, **k):
    return None


def cmd_image_resize(session: Session, width, height):
    doc = session.doc
    from PIL import Image
    snapshot = _snapshot_layers(doc)
    old_w, old_h = doc.width, doc.height
    width, height = max(1, int(width)), max(1, int(height))
    sx, sy = width / old_w, height / old_h

    def rs(a):
        return np.asarray(Image.fromarray(a, "RGBA").resize((width, height), Image.LANCZOS), np.uint8)

    def scale_list(layers):
        out = []
        for layer in layers:
            if isinstance(layer, PixelLayer) and layer.pixels is not None:
                out.append(PixelLayer(name=layer.name, pixels=rs(layer.pixels),
                                      x=int(round(layer.x * sx)), y=int(round(layer.y * sy)),
                                      opacity=layer.opacity, blend=layer.blend,
                                      visible=layer.visible, mask=layer.mask,
                                      effects=copy.deepcopy(layer.effects)))
            elif isinstance(layer, (TextLayer, ShapeLayer)):
                clone = copy.deepcopy(layer)
                clone.x, clone.y = int(round(layer.x * sx)), int(round(layer.y * sy))
                if isinstance(layer, TextLayer):
                    clone.params["size"] = max(4, float(layer.params.get("size", 48)) * (sx + sy) / 2)
                else:
                    clone.params["w"] = max(2, int(layer.params.get("w", 100) * sx))
                    clone.params["h"] = max(2, int(layer.params.get("h", 100) * sy))
                    clone.params["stroke_w"] = max(0, int(layer.params.get("stroke_w", 0) * (sx + sy) / 2))
                out.append(clone)
            elif isinstance(layer, GroupLayer):
                out.append(GroupLayer(kind="group", name=layer.name, visible=layer.visible,
                                      opacity=layer.opacity, blend=layer.blend,
                                      children=scale_list(layer.children),
                                      passthrough=layer.passthrough, mask=layer.mask))
            else:
                out.append(copy.deepcopy(layer))
        return out

    doc.layers = scale_list(doc.layers)
    doc.width, doc.height = width, height
    doc.selection = None
    def undo(s):
        _restore_layers(s, snapshot)
        s.doc.width, s.doc.height = old_w, old_h
    def redo(s):
        s.doc.layers = scale_list(s.doc.layers)
        s.doc.width, s.doc.height = width, height
    return (width, height), undo, redo


# ----------------------------------------------------------------- painting
def _stroke_stamp(pixels: np.ndarray, x: int, y: int, size: int, hardness: float,
                  color_rgba: tuple, erase: bool) -> tuple:
    r = max(1, int(size) // 2)
    h, w = pixels.shape[:2]
    x0, x1 = max(0, x - r), min(w, x + r + 1)
    y0, y1 = max(0, y - r), min(h, y + r + 1)
    if x1 <= x0 or y1 <= y0:
        return (x, y, x, y)
    yy, xx = np.mgrid[y0:y1, x0:x1]
    dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2) / max(r, 1e-6)
    soft = 1.0 - float(np.clip(hardness, 0.0, 1.0))
    profile = np.clip((1.0 - dist) / max(soft, 0.02), 0.0, 1.0) if soft > 0.001 else (dist <= 1.0).astype(np.float32)
    profile = (profile ** 0.9).astype(np.float32)
    region = pixels[y0:y1, x0:x1]
    if erase:
        keep = 1.0 - profile * (color_rgba[3] / 255.0 if len(color_rgba) > 3 else 1.0)
        region[..., 3] = (region[..., 3].astype(np.float32) * keep).astype(np.uint8)
    else:
        a = (profile * (color_rgba[3] / 255.0 if len(color_rgba) > 3 else 1.0))[..., None]
        src_rgb = np.array(color_rgba[:3], np.float32) / 255.0
        dst_rgb = region[..., :3].astype(np.float32) / 255.0
        dst_a = region[..., 3:4].astype(np.float32) / 255.0
        src_a = a
        co = src_a * (1 - dst_a) * src_rgb + src_a * dst_a * src_rgb + (1 - src_a) * dst_a * dst_rgb
        ao = src_a + dst_a * (1 - src_a)
        out_rgb = np.where(ao > 1e-6, co / np.maximum(ao, 1e-6), 0)
        region[..., :3] = np.clip(out_rgb * 255.0 + 0.5, 0, 255).astype(np.uint8)
        region[..., 3] = np.clip(ao[..., 0] * 255.0 + 0.5, 0, 255).astype(np.uint8)
    return (x0, y0, x1, y1)


def cmd_paint_stroke(session: Session, points, size=12, hardness=0.85,
                     color=(0, 0, 0, 255), uid=None, erase=False, only_selection=True):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or not points:
        return None, None, None
    before = layer.pixels.copy()
    dirty = None
    sel = _sel_mask(doc) if only_selection else None

    def seg(p0, p1):
        nonlocal dirty
        x0, y0 = int(p0[0]), int(p0[1])
        x1, y1 = int(p1[0]), int(p1[1])
        n = max(abs(x1 - x0), abs(y1 - y0), 1)
        for t in range(n + 1):
            x = x0 + (x1 - x0) * t // n
            y = y0 + (y1 - y0) * t // n
            if sel is not None and doc.selection is not None:
                if not (0 <= y < doc.height and 0 <= x < doc.width and sel[y, x]):
                    continue
            bb = _stroke_stamp(layer.pixels, x, y, size, hardness, color, erase)
            dirty = bb if dirty is None else (min(dirty[0], bb[0]), min(dirty[1], bb[1]),
                                              max(dirty[2], bb[2]), max(dirty[3], bb[3]))

    seg(points[0], points[0])
    for a, b in zip(points[:-1], points[1:]):
        seg(a, b)
    if dirty is None:
        return None, None, None
    bx0, by0, bx1, by1 = dirty
    before_crop = before[by0:by1, bx0:bx1].copy()
    after_crop = layer.pixels[by0:by1, bx0:bx1].copy()
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[by0:by1, bx0:bx1] = before_crop
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[by0:by1, bx0:bx1] = after_crop
    return uid_, undo, redo


def cmd_paint_bucket(session: Session, x, y, color=(0, 0, 0, 255), tolerance=32,
                     uid=None, contiguous=True):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    x, y = int(x), int(y)
    h, w = layer.pixels.shape[:2]
    if not (0 <= x < w and 0 <= y < h):
        return None, None, None
    lx, ly = x - layer.x, y - layer.y
    if not (0 <= lx < w and 0 <= ly < h):
        return None, None, None
    target = layer.pixels[ly, lx].astype(np.int16)
    diff = np.abs(layer.pixels.astype(np.int16) - target).max(-1) <= tolerance
    if contiguous:
        lab, _ = _ndi.label(diff)
        m = lab == lab[ly, lx]
    else:
        m = diff
    before = layer.pixels.copy()
    region = layer.pixels[m]
    region[..., :3] = color[:3]
    region[..., 3] = color[3] if len(color) > 3 else 255
    layer.pixels[m] = region
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[m] = region
    return uid_, undo, redo


def cmd_paint_gradient(session: Session, p0, p1, kind="linear", color0=None,
                       color1=None, uid=None, transparency=True):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    c0 = np.array(color0 if color0 is not None else session.foreground[:3], np.float32)
    c1 = np.array(color1 if color1 is not None else np.array(session.foreground[:3]) * 0.2 + 204, np.float32)
    a0 = 255.0
    a1 = 0.0 if transparency else 255.0
    h, w = layer.pixels.shape[:2]
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    lx = xs - layer.x
    ly = ys - layer.y
    x0, y0 = float(p0[0]), float(p0[1])
    x1, y1 = float(p1[0]), float(p1[1])
    dx, dy = x1 - x0, y1 - y0
    L2 = max(dx * dx + dy * dy, 1.0)
    if kind == "linear":
        t = ((lx - x0) * dx + (ly - y0) * dy) / L2
    else:
        t = np.sqrt((lx - x0) ** 2 + (ly - y0) ** 2) / np.sqrt(L2)
    t = np.clip(t, 0, 1)[..., None]
    before = layer.pixels.copy()
    rgb = c0 * (1 - t) + c1 * t
    a = a0 * (1 - t) + a1 * t
    region_rgb = layer.pixels[..., :3].astype(np.float32)
    sa = (a / 255.0)
    out_rgb = region_rgb * (1 - sa) + rgb * sa
    layer.pixels[..., :3] = np.clip(out_rgb + 0.5, 0, 255).astype(np.uint8)
    layer.pixels[..., 3] = np.clip(np.maximum(layer.pixels[..., 3].astype(np.float32), a[..., 0]) + 0.5, 0, 255).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_paint_clone(session: Session, points, src_offset=(0, 0), size=24, hardness=0.8, uid=None):
    """Clone stamp: copy pixels from (point + src_offset). Alt-click sets source in the UI."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or not points:
        return None, None, None
    before = layer.pixels.copy()
    ox, oy = int(src_offset[0]), int(src_offset[1])
    h, w = layer.pixels.shape[:2]
    for (x, y) in points:
        dx_, dy_ = int(x) - layer.x, int(y) - layer.y
        if not (0 <= dx_ < w and 0 <= dy_ < h):
            continue
        r = max(1, size // 2)
        x0, x1 = max(0, dx_ - r), min(w, dx_ + r + 1)
        y0, y1 = max(0, dy_ - r), min(h, dy_ + r + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        bx0, by0 = x0 + ox, y0 + oy
        bx1, by1 = x1 + ox, y1 + oy
        if bx0 < 0 or by0 < 0 or bx1 > w or by1 > h:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        dist = np.sqrt((xx - dx_) ** 2 + (yy - dy_) ** 2) / max(r, 1e-6)
        prof = np.clip((1 - dist) / 0.35, 0, 1)[..., None]
        src_patch = before[by0:by1, bx0:bx1].astype(np.float32)
        tgt = layer.pixels[y0:y1, x0:x1].astype(np.float32)
        layer.pixels[y0:y1, x0:x1] = (tgt * (1 - prof) + src_patch * prof).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def _local_op(layer, points, size, hardness, fn):
    """Apply fn on pixel neighborhoods along a stroke (blur/sharpen/dodge...)."""
    pixels = layer.pixels
    before = pixels.copy()
    h, w = pixels.shape[:2]
    r = max(2, int(size) // 2)
    for (x, y) in points:
        x, y = int(x) - layer.x, int(y) - layer.y
        x0, x1 = max(0, x - r), min(w, x + r + 1)
        y0, y1 = max(0, y - r), min(h, y + r + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2) / max(r, 1e-6)
        prof = (np.clip((1 - dist) / 0.4, 0, 1) * float(hardness))[..., None]
        patch = pixels[y0:y1, x0:x1]
        out = fn(patch.copy())
        pixels[y0:y1, x0:x1] = (patch * (1 - prof) + out * prof).astype(np.uint8)
    return before


def cmd_paint_dodge_burn(session: Session, points, size=40, mode="dodge",
                         exposure=0.25, hardness=0.7, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    def fn(patch):
        rgb = patch[..., :3].astype(np.float32)
        if mode == "dodge":
            rgb = 255 - (255 - rgb) * (1 - exposure)
        else:
            rgb = rgb * (1 - exposure)
        patch[..., :3] = np.clip(rgb + 0.5, 0, 255).astype(np.uint8)
        return patch
    before = _local_op(layer, points, size, hardness, fn)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_paint_blur_sharpen(session: Session, points, size=40, mode="blur",
                           strength=0.6, hardness=0.7, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    def fn(patch):
        if mode == "blur":
            blur = np.stack([ndimage_g(patch[..., i], 3) for i in range(4)], -1)
            return blur.astype(patch.dtype)
        blurred = np.stack([ndimage_g(patch[..., i].astype(np.float32), 2) for i in range(3)], -1)
        rgb = np.clip(patch[..., :3].astype(np.float32) + (patch[..., :3].astype(np.float32) - blurred) * strength, 0, 255)
        patch[..., :3] = rgb.astype(np.uint8)
        return patch
    before = _local_op(layer, points, size, hardness, fn)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_paint_smudge(session: Session, points, size=40, strength=0.6, hardness=0.7, uid=None):
    """Finger smudge: drag the content under the previous stamp along the stroke."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    pixels = layer.pixels
    before = pixels.copy()
    h, w = pixels.shape[:2]
    r = max(2, int(size) // 2)
    prev = None
    for (x, y) in points:
        x, y = int(x) - layer.x, int(y) - layer.y
        if prev is not None:
            px, py = prev
            dx0, dx1 = max(0, x - r), min(w, x + r + 1)
            dy0, dy1 = max(0, y - r), min(h, y + r + 1)
            if dx1 > dx0 and dy1 > dy0:
                sh, sw_ = dy1 - dy0, dx1 - dx0
                cx, cy = px - sw_ // 2, py - sh // 2
                sx0, sy0 = max(0, cx), max(0, cy)
                sx1, sy1 = min(w, cx + sw_), min(h, cy + sh)
                if sx1 > sx0 and sy1 > sy0:
                    src = pixels[sy0:sy1, sx0:sx1].astype(np.float32)
                    hh2, ww2 = src.shape[:2]
                    yy, xx = np.mgrid[dy0:dy0 + hh2, dx0:dx0 + ww2]
                    dist = np.sqrt((xx - x) ** 2 + (yy - y) ** 2) / max(r, 1e-6)
                    prof = (np.clip((1 - dist) / 0.4, 0, 1) * float(strength))[..., None]
                    dst = pixels[dy0:dy0 + hh2, dx0:dx0 + ww2].astype(np.float32)
                    out = dst * (1 - prof) + src * prof
                    pixels[dy0:dy0 + hh2, dx0:dx0 + ww2] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
        prev = (x, y)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_paint_sponge(session: Session, points, size=40, strength=0.4,
                     mode="saturate", hardness=0.7, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    def fn(patch):
        rgb = patch[..., :3].astype(np.float32)
        gray = rgb.mean(-1, keepdims=True)
        amt = float(strength) if mode == "saturate" else -float(strength)
        s = 1.0 + amt
        if s < 0:
            s = 0.0
        rgb = gray + (rgb - gray) * s
        patch[..., :3] = np.clip(rgb + 0.5, 0, 255).astype(np.uint8)
        return patch
    before = _local_op(layer, points, size, hardness, fn)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_spot_heal(session: Session, points, size=24, uid=None):
    """Heal a brush stroke: TELEA inpaint of the stroked region on the active layer."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    import cv2
    h, w = layer.pixels.shape[:2]
    mask = np.zeros((h, w), np.uint8)
    r = max(3, int(size) // 2)
    for (x, y) in points:
        x, y = int(x) - layer.x, int(y) - layer.y
        if 0 <= x < w and 0 <= y < h:
            cv2.circle(mask, (x, y), r, 255, -1)
    if not mask.any():
        return None, None, None
    before = layer.pixels.copy()
    bgr = cv2.cvtColor(layer.pixels[..., :3], cv2.COLOR_RGB2BGR)
    fixed = cv2.inpaint(bgr, mask, 5, cv2.INPAINT_TELEA)
    fixed = cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB).astype(np.float32)
    m = mask.astype(np.float32)[..., None] / 255.0
    out = layer.pixels.astype(np.float32)
    out[..., :3] = out[..., :3] * (1 - m) + fixed * m
    layer.pixels[:] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_red_eye(session: Session, x, y, radius=12, uid=None):
    """Darken red pupil pixels inside the clicked circle (active layer)."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    h, w = layer.pixels.shape[:2]
    x, y = int(x) - layer.x, int(y) - layer.y
    r = max(4, int(radius))
    x0, x1 = max(0, x - r), min(w, x + r + 1)
    y0, y1 = max(0, y - r), min(h, y + r + 1)
    if x1 <= x0 or y1 <= y0:
        return None, None, None
    before = layer.pixels.copy()
    patch = layer.pixels[y0:y1, x0:x1]
    rgb = patch[..., :3].astype(np.float32)
    rr, gg, bb = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    redness = (rr > 60) & (rr > gg * 1.3) & (rr > bb * 1.3)
    yy, xx = np.mgrid[y0:y1, x0:x1]
    redness &= (xx - x) ** 2 + (yy - y) ** 2 <= r * r
    if redness.any():
        avg = (gg + bb)[redness] / 2.0
        rgb[..., 0][redness] = np.clip(avg * 0.9, 0, 70)
        patch[..., :3] = np.clip(rgb + 0.5, 0, 255).astype(np.uint8)
        uid_ = layer.uid
        def undo(s):
            lay = s.doc.find(uid_)
            if lay is not None and isinstance(lay, PixelLayer):
                lay.pixels = before
        def redo(s):
            lay = s.doc.find(uid_)
            if lay is not None and isinstance(lay, PixelLayer):
                lay.pixels = layer.pixels
        return uid_, undo, redo
    return None, None, None


def cmd_selection_quick(session: Session, points, tolerance=32):
    """Quick Selection: union of magic-wand blobs along the dragged points."""
    doc = session.doc
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None or not points:
        return None, None, None
    total = np.zeros((doc.height, doc.width), bool)
    for (x, y) in points[::3]:
        xi = int(np.clip(x, 0, doc.width - 1))
        yi = int(np.clip(y, 0, doc.height - 1))
        target = comp[yi, xi].astype(np.int16)
        diff = np.abs(comp.astype(np.int16) - target).max(-1)
        m = diff <= tolerance
        if m.any():
            from scipy import ndimage
            lab, _ = ndimage.label(m)
            total |= (lab == lab[yi, xi])
    return cmd_selection_set_mask(session, total if total.any() else None)


def cmd_selection_object_rect(session: Session, rect):
    """Object Selection: GrabCut the subject inside the dragged rect."""
    doc = session.doc
    import cv2
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None:
        return None, None, None
    x0, y0, x1, y1 = [int(v) for v in rect]
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(doc.width, x1), min(doc.height, y1)
    if x1 - x0 < 8 or y1 - y0 < 8:
        return None, None, None
    crop = np.ascontiguousarray(comp[y0:y1, x0:x1, :3])
    s = 640.0 / max(crop.shape[0], crop.shape[1], 1)
    if s < 1.0:
        small = cv2.resize(crop, (int(crop.shape[1] * s), int(crop.shape[0] * s)),
                           interpolation=cv2.INTER_AREA)
    else:
        small = crop
    mask = np.zeros(small.shape[:2], np.uint8)
    mask[:] = cv2.GC_BGD
    pad = max(2, int(min(small.shape[:2]) * 0.08))
    mask[pad:-pad, pad:-pad] = cv2.GC_PR_BGD
    inner = max(pad + 2, int(min(small.shape[:2]) * 0.25))
    mask[inner:-inner, inner:-inner] = cv2.GC_PR_FGD
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(small, mask, None, bgd, fgd, 4, cv2.GC_INIT_WITH_MASK)
    except cv2.error:
        return None, None, None
    m = np.isin(mask, [cv2.GC_FGD, cv2.GC_PR_FGD])
    full = np.zeros((doc.height, doc.width), bool)
    mh, mw = y1 - y0, x1 - x0
    mi = cv2.resize(m.astype(np.uint8) * 255, (mw, mh), interpolation=cv2.INTER_LINEAR)
    full[y0:y1, x0:x1] = mi > 127
    if not full.any():
        return None, None, None
    return cmd_selection_set_mask(session, full)


def cmd_image_heal_stroke(session: Session, points, src_offset=(0, 0), size=24,
                          hardness=0.8, uid=None):
    """Healing Brush: clone from source, keeping only high-frequency detail —
    the destination's mean color is preserved, so seams blend like Photoshop."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or not points:
        return None, None, None
    before = layer.pixels.copy()
    ox, oy = int(src_offset[0]), int(src_offset[1])
    h, w = layer.pixels.shape[:2]
    for (x, y) in points:
        dx_, dy_ = int(x) - layer.x, int(y) - layer.y
        if not (0 <= dx_ < w and 0 <= dy_ < h):
            continue
        r = max(1, size // 2)
        x0, x1 = max(0, dx_ - r), min(w, dx_ + r + 1)
        y0, y1 = max(0, dy_ - r), min(h, dy_ + r + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        bx0, by0, bx1, by1 = x0 + ox, y0 + oy, x1 + ox, y1 + oy
        if bx0 < 0 or by0 < 0 or bx1 > w or by1 > h:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        dist = np.sqrt((xx - dx_) ** 2 + (yy - dy_) ** 2) / max(r, 1e-6)
        prof = np.clip((1 - dist) / 0.35, 0, 1)[..., None]
        src = before[by0:by1, bx0:bx1].astype(np.float32)
        tgt = layer.pixels[y0:y1, x0:x1].astype(np.float32)
        healed = tgt.mean(-1, keepdims=True) + (src - src.mean(-1, keepdims=True))
        out = tgt * (1 - prof) + healed * prof
        layer.pixels[y0:y1, x0:x1] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_patch_heal(session: Session, feather=6):
    """Patch: inpaint the current selection on the active layer."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or doc.selection is None:
        return None, None, None
    import cv2
    before = layer.pixels.copy()
    mask = (doc.selection * 255).astype(np.uint8)
    if feather:
        mask = cv2.dilate(mask, np.ones((feather * 2 + 1, feather * 2 + 1), np.uint8))
    bgr = cv2.cvtColor(layer.pixels[..., :3], cv2.COLOR_RGB2BGR)
    fixed = cv2.inpaint(bgr, mask, 5, cv2.INPAINT_TELEA)
    fixed = cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB).astype(np.float32)
    m = mask.astype(np.float32)[..., None] / 255.0
    out = layer.pixels.astype(np.float32)
    out[..., :3] = out[..., :3] * (1 - m) + fixed * m
    layer.pixels[:] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_content_aware_move(session: Session, dx=0, dy=0):
    """Content-Aware Move: shift the selected content by (dx, dy); the vacated
    area is inpainted. The selection follows the move."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or doc.selection is None:
        return None, None, None
    import cv2
    dx, dy = int(dx), int(dy)
    if dx == 0 and dy == 0:
        return None, None, None
    before = layer.pixels.copy()
    sel = doc.selection
    h, w = layer.pixels.shape[:2]
    mask = (sel * 255).astype(np.uint8)
    bgr = cv2.cvtColor(layer.pixels[..., :3], cv2.COLOR_RGB2BGR)
    base = cv2.inpaint(bgr, mask, 5, cv2.INPAINT_TELEA)
    base = cv2.cvtColor(base, cv2.COLOR_BGR2RGB).astype(np.float32)
    out = layer.pixels.astype(np.float32).copy()
    out[..., :3] = base
    out[..., 3] = out[..., 3] * (1 - sel)  # clear alpha in the hole
    # paste the grabbed content at the offset with a feathered edge
    m = cv2.GaussianBlur(sel.astype(np.float32), (0, 0), 2.0)[..., None]
    ys, xs = np.nonzero(sel)
    if len(ys) == 0:
        return None, None, None
    ys1, xs1 = ys + dy, xs + dx
    keep = (0 <= ys1) & (ys1 < h) & (0 <= xs1) & (xs1 < w)
    ys2, xs2 = ys1[keep], xs1[keep]
    y0s, y1s = max(0, ys2.min()), min(h, ys2.max() + 1)
    x0s, x1s = max(0, xs2.min()), min(w, xs2.max() + 1)
    src_sel = np.zeros((h, w), bool)
    src_sel[ys[keep], xs[keep]] = True
    content = layer.pixels.copy()
    region = np.zeros((h, w, 4), np.float32)
    region[src_sel] = content[src_sel]
    shifted = np.zeros_like(region)
    ys3 = ys2.clip(0, h - 1)
    xs3 = xs2.clip(0, w - 1)
    shifted[ys3, xs3] = region[ys[keep], xs[keep]]
    a = shifted[..., 3:4] / 255.0
    rgb_out = out[..., :3] * (1 - a) + shifted[..., :3] * a
    alpha_out = np.maximum(out[..., 3], shifted[..., 3])
    out[..., :3] = rgb_out
    out[..., 3] = alpha_out
    layer.pixels[:] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    new_sel = np.zeros((h, w), bool)
    ys4, xs4 = ys1[keep], xs1[keep]
    new_sel[ys4.clip(0, h - 1), xs4.clip(0, w - 1)] = True
    doc.selection = new_sel
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
        s.doc.selection = sel
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
        s.doc.selection = new_sel
    return uid_, undo, redo


def _pattern_color(pattern, x, y, fg, bg, scale):
    if pattern == "dots":
        cell = max(2, scale)
        return fg if ((x % cell) == cell // 2 and (y % cell) == cell // 2) else bg
    if pattern == "diagonal":
        cell = max(3, scale)
        return fg if ((x + y) % cell) < max(1, cell // 3) else bg
    return fg if ((x // max(2, scale // 2)) + (y // max(2, scale // 2))) % 2 == 0 else bg


def cmd_paint_pattern_stamp(session: Session, points, size=40, pattern="checker",
                            scale=8, hardness=0.85, uid=None,
                            fg=(0, 0, 0, 255), bg=(255, 255, 255, 255)):
    """Pattern Stamp: paint one of the built-in patterns (checker/dots/diagonal)."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or not points:
        return None, None, None
    before = layer.pixels.copy()
    h, w = layer.pixels.shape[:2]
    for (x, y) in points:
        dx_, dy_ = int(x) - layer.x, int(y) - layer.y
        if not (0 <= dx_ < w and 0 <= dy_ < h):
            continue
        r = max(1, size // 2)
        x0, x1 = max(0, dx_ - r), min(w, dx_ + r + 1)
        y0, y1 = max(0, dy_ - r), min(h, dy_ + r + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        dist = np.sqrt((xx - dx_) ** 2 + (yy - dy_) ** 2) / max(r, 1e-6)
        prof = (np.clip((1 - dist) / 0.35, 0, 1) * float(hardness))[..., None]
        col = np.zeros((y1 - y0, x1 - x0, 4), np.float32)
        for c in range(3):
            f = np.array([_pattern_color(pattern, int(xx[i, j]) + layer.x, int(yy[i, j]) + layer.y,
                                         fg, bg, scale)[c]
                          for i in range(y1 - y0) for j in range(x1 - x0)], np.float32)
            col[..., c] = f.reshape(y1 - y0, x1 - x0)
        col[..., 3] = fg[3]
        tgt = layer.pixels[y0:y1, x0:x1].astype(np.float32)
        layer.pixels[y0:y1, x0:x1] = (tgt * (1 - prof) + col * prof).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_paint_bg_erase(session: Session, points, size=40, color=(255, 255, 255, 255),
                       tolerance=32, hardness=0.9, uid=None):
    """Background Eraser: erase only pixels similar to the sampled color."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or not points:
        return None, None, None
    before = layer.pixels.copy()
    h, w = layer.pixels.shape[:2]
    target = np.array(color[:3], np.float32)
    for (x, y) in points:
        dx_, dy_ = int(x) - layer.x, int(y) - layer.y
        if not (0 <= dx_ < w and 0 <= dy_ < h):
            continue
        r = max(1, size // 2)
        x0, x1 = max(0, dx_ - r), min(w, dx_ + r + 1)
        y0, y1 = max(0, dy_ - r), min(h, dy_ + r + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        dist = np.sqrt((xx - dx_) ** 2 + (yy - dy_) ** 2) / max(r, 1e-6)
        prof = (np.clip((1 - dist) / 0.35, 0, 1) * float(hardness))[..., None]
        diff = np.abs(layer.pixels[y0:y1, x0:x1, :3].astype(np.float32) - target).max(-1)
        hit = (diff <= float(tolerance))[..., None].astype(np.float32)
        a = layer.pixels[y0:y1, x0:x1, 3].astype(np.float32)
        layer.pixels[y0:y1, x0:x1, 3] = (a * (1 - prof * hit))[..., 0].astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_history_reveal(session: Session, points, size=40, snapshot=None,
                             hardness=0.85, uid=None):
    """History Brush: paint the document-open composite back into the layer."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if (not isinstance(layer, PixelLayer) or layer.pixels is None or not points
            or snapshot is None):
        return None, None, None
    before = layer.pixels.copy()
    h, w = layer.pixels.shape[:2]
    snap = snapshot
    if snap.shape[:2] != (h, w):
        return None, None, None
    for (x, y) in points:
        dx_, dy_ = int(x) - layer.x, int(y) - layer.y
        if not (0 <= dx_ < w and 0 <= dy_ < h):
            continue
        r = max(1, size // 2)
        x0, x1 = max(0, dx_ - r), min(w, dx_ + r + 1)
        y0, y1 = max(0, dy_ - r), min(h, dy_ + r + 1)
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        dist = np.sqrt((xx - dx_) ** 2 + (yy - dy_) ** 2) / max(r, 1e-6)
        prof = (np.clip((1 - dist) / 0.35, 0, 1) * float(hardness))[..., None]
        src = snap[y0:y1, x0:x1].astype(np.float32)
        tgt = layer.pixels[y0:y1, x0:x1].astype(np.float32)
        layer.pixels[y0:y1, x0:x1] = (tgt * (1 - prof) + src * prof).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


# --------------------------------------------------- 2026 AI-style (on-device)
def cmd_image_upscale_smart(session: Session, factor=2, detail=0.6):
    """Generative-Upscale-lite: edge-preserving enlargement with detail
    recovery. Interpolation feeds a bilateral base; the high-frequency layer
    is re-derived at the target scale and boosted."""
    doc = session.doc
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None:
        return None, None, None
    import cv2
    f = float(factor) if float(factor) >= 1.0 else 2.0
    w, h = int(doc.width * f), int(doc.height * f)
    big = cv2.resize(comp, (w, h), interpolation=cv2.INTER_LANCZOS4)
    soft = cv2.GaussianBlur(big, (0, 0), max(1.0, f * 0.9)).astype(np.float32)
    hi = big.astype(np.float32) - soft
    gain = 1.0 + float(np.clip(detail, 0, 2))
    big = np.clip(big.astype(np.float32) + hi * gain + 0.5, 0, 255).astype(np.uint8)
    doc = Document(width=w, height=h, path=doc.path)
    doc.layers.append(PixelLayer(name="Background", pixels=big))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return None, None, None


def cmd_image_expand_gen(session: Session, left=0, right=0, top=0, bottom=0, feather=18):
    """Generative-Expand-lite: grow the canvas and let TELEA inpaint invent the
    new border content from the image context (flattens to one pixel layer)."""
    doc = session.doc
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None:
        return None, None, None
    import cv2
    l, r, t, b = (max(0, int(v)) for v in (left, right, top, bottom))
    if l + r + t + b <= 0:
        return None, None, None
    w, h = doc.width + l + r, doc.height + t + b
    canvas = np.zeros((h, w, 4), np.uint8)
    canvas[t:t + doc.height, l:l + doc.width] = comp
    mask = np.zeros((h, w), np.uint8)
    if l: mask[:, :l] = 255
    if r: mask[:, w - r:] = 255
    if t: mask[:t, :] = 255
    if b: mask[h - b:, :] = 255
    bgr = cv2.cvtColor(canvas[..., :3], cv2.COLOR_RGB2BGR)
    fixed = cv2.inpaint(bgr, mask, 7, cv2.INPAINT_TELEA)
    fixed = cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB)
    soft = cv2.GaussianBlur(mask, (0, 0), feather)
    m = (soft.astype(np.float32) / 255.0)[..., None]
    out = canvas.astype(np.float32)
    out[..., :3] = out[..., :3] * (1 - m) + fixed.astype(np.float32) * m
    out[..., 3] = np.maximum(out[..., 3], mask.astype(np.float32))  # border is opaque
    doc = Document(width=w, height=h, path=doc.path)
    doc.layers.append(PixelLayer(name="Background",
                                 pixels=np.clip(out + 0.5, 0, 255).astype(np.uint8)))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return None, None, None


def _lab_mean_std(rgb01):
    import cv2
    lab = cv2.cvtColor((np.clip(rgb01, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32) / 255.0
    mean = lab.reshape(-1, 3).mean(0)
    std = lab.reshape(-1, 3).std(0) + 1e-4
    return mean, std


def _lab_transfer(src01, ref_mean, ref_std, strength=1.0):
    import cv2
    lab = cv2.cvtColor((np.clip(src01, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32) / 255.0
    mean, std = lab.reshape(-1, 3).mean(0), lab.reshape(-1, 3).std(0) + 1e-4
    out = (lab - mean) * (ref_std / std) + ref_mean
    out = lab * (1 - strength) + out * strength
    return cv2.cvtColor(np.clip(out, 0, 1) * 255, cv2.COLOR_LAB2RGB if False else cv2.COLOR_LAB2RGB)


def cmd_layer_harmonize(session: Session, strength=0.85, uid=None):
    """Harmonize-lite (PS 2026): re-light/recolor the active pixel layer so it
    sits in the scene — Lab mean/std transfer toward the backdrop."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None or not hasattr(layer, "x"):
        return None, None, None
    from pf import compose as _c
    if len(doc.layers) < 2:
        return None, None, None
    saved_visible = {id(l): l.visible for l in doc.layers}
    layer.visible = False
    comp = _c.composite_rgba8(doc)
    layer.visible = saved_visible.get(id(layer), True)
    if comp is None or comp.max() == 0:
        return None, None, None
    px = layer.pixels
    alpha = px[..., 3:4].astype(np.float32) / 255.0
    if alpha.max() < 1e-3:
        return None, None, None
    import cv2
    src01 = px.astype(np.float32) / 255.0
    fg = src01[..., :3] * alpha
    ref = comp.astype(np.float32) / 255.0
    # stats from layer fg vs backdrop
    lab = cv2.cvtColor((np.clip(fg, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32) / 255.0
    reflab = cv2.cvtColor(comp, cv2.COLOR_RGB2LAB).astype(np.float32) / 255.0
    mean, std = lab.reshape(-1, 3).mean(0), lab.reshape(-1, 3).std(0) + 1e-4
    rmean, rstd = reflab.reshape(-1, 3).mean(0), reflab.reshape(-1, 3).std(0) + 1e-4
    out = (lab - mean) * (rstd / std) + rmean
    s = float(np.clip(strength, 0, 1))
    out = lab * (1 - s) + out * s
    matched = cv2.cvtColor(np.clip(out, 0, 1) * 255, cv2.COLOR_LAB2RGB).astype(np.float32)
    before = px.copy()
    new = px.copy()
    new[..., :3] = np.clip(matched * alpha + src01[..., :3] * (1 - alpha) * 255 + 0.5, 0, 255).astype(np.uint8)
    layer.pixels = new
    uid_ = layer.uid
    def undo(s2):
        lay = s2.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s2):
        lay = s2.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


SKY_PRESETS = {
    "clear":   ((0.55, 0.75, 0.98), (0.78, 0.88, 1.0)),
    "sunset":  ((0.98, 0.45, 0.20), (0.35, 0.18, 0.45)),
    "golden":  ((1.00, 0.72, 0.30), (0.55, 0.70, 0.90)),
    "dusk":    ((0.20, 0.22, 0.45), (0.75, 0.45, 0.45)),
    "storm":   ((0.30, 0.33, 0.38), (0.55, 0.58, 0.62)),
    "teal":    ((0.10, 0.45, 0.65), (0.70, 0.85, 0.92)),
}


def _sky_mask(comp):
    """Sky-ness per COLUMN: scan from the top to the last sky-ish pixel, so no
    strip of original sky survives under the replacement."""
    import cv2
    h, w = comp.shape[:2]
    f = comp.astype(np.float32) / 255.0
    gray = 0.299 * f[..., 0] + 0.587 * f[..., 1] + 0.114 * f[..., 2]
    tex = cv2.Laplacian(gray, cv2.CV_32F, ksize=3)
    tex = cv2.GaussianBlur(np.abs(tex), (0, 0), 6)
    r, g, b = f[..., 0], f[..., 1], f[..., 2]
    skyish = ((b >= r - 0.03) & (gray > 0.4)) | (gray > 0.9)
    skyish &= np.arange(h)[:, None] < int(h * 0.8)
    # (texture test only trims speckle, not the horizon anchor)
    anchor_ok = cv2.GaussianBlur((skyish * 255).astype(np.uint8), (0, 0), 2) > 60
    skyish &= anchor_ok
    col_bot = np.full(w, -1, np.int32)
    ys, xs = np.nonzero(skyish)
    if len(ys) == 0:
        return None
    np.maximum.at(col_bot, xs, ys)
    valid = col_bot >= int(h * 0.15)          # this column really has sky
    rr = np.arange(h)[:, None]
    mask = ((rr <= np.clip(col_bot + 2, 0, h - 1)[None, :]) & valid[None, :])
    if not mask.any():
        return None
    mask = (mask * 255).astype(np.uint8)
    mask = cv2.GaussianBlur(mask, (0, 0), 2.0)
    return mask.astype(np.float32) / 255.0


def cmd_image_sky_replace(session: Session, preset="sunset", relight=0.35):
    """Sky Replacement (Luminar-style, on-device): find the sky, swap in a
    generated gradient sky, and warm/dim the scene a touch for realism."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None:
        return None, None, None
    m = _sky_mask(comp)
    if m is None:
        raise ValueError("No sky region detected")
    import cv2
    h, w = comp.shape[:2]
    top, bottom = SKY_PRESETS.get(preset, SKY_PRESETS["sunset"])
    grad = np.zeros((h, w, 3), np.float32)
    t = (np.mgrid[0:h, 0:w][0] / max(1, h)).astype(np.float32)
    for c in range(3):
        grad[..., c] = (bottom[c] + (top[c] - bottom[c]) * (1 - t)) * 255.0
    # keep sky luminance structure: modulate gradient by the original sky's V
    hsv = cv2.cvtColor(comp, cv2.COLOR_RGB2HSV).astype(np.float32)
    v = hsv[..., 2] / 255.0
    sky = grad * (0.72 + 0.5 * v[..., None])
    sky = np.clip(sky, 0, 255)
    px = layer.pixels.astype(np.float32)
    mm = m[..., None]
    out = px.copy()
    out[..., :3] = px[..., :3] * (1 - mm) + sky * mm
    # relight the scene: warm the land slightly, pull its exposure down
    rl = float(np.clip(relight, 0, 1))
    if rl > 0:
        land = (1 - mm) * rl
        tone = np.array([0.96, 0.94, 0.98], np.float32)
        out[..., :3] = out[..., :3] * (1 - land) + (out[..., :3] * tone) * land
        red = out[..., 0:1]
        out[..., 0:1] = red * (1 - land) + np.clip(red * 1.06 + 6, 0, 255) * land
    before = layer.pixels.copy()
    layer.pixels = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_match_color_file(session: Session, path, strength=0.8, uid=None):
    """Match Color (Photoshop): pull the active layer's color statistics
    toward another image's."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    import cv2
    from PIL import Image
    ref = np.asarray(Image.open(path).convert("RGB"))
    ref = cv2.resize(ref, (min(512, ref.shape[1]), min(512, ref.shape[0])))
    ref01 = ref.astype(np.float32) / 255.0
    rmean, rstd = _lab_mean_std(ref01)
    px = layer.pixels
    src01 = px.astype(np.float32) / 255.0
    lab = cv2.cvtColor((src01[..., :3] * 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32) / 255.0
    mean, std = lab.reshape(-1, 3).mean(0), lab.reshape(-1, 3).std(0) + 1e-4
    out = (lab - mean) * (rstd / std) + rmean
    s = float(np.clip(strength, 0, 1))
    out = lab * (1 - s) + out * s
    matched = cv2.cvtColor(np.clip(out, 0, 1) * 255, cv2.COLOR_LAB2RGB).astype(np.float32)
    before = px.copy()
    new = px.copy()
    new[..., :3] = np.clip(matched + 0.5, 0, 255).astype(np.uint8)
    layer.pixels = new
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_doc_photomerge(session: Session, paths):
    """Photomerge: cv2.Stitcher builds a panorama from the given images and
    opens it as a new document."""
    import cv2
    from PIL import Image
    imgs = []
    for p in paths:
        im = np.asarray(Image.open(p).convert("RGB"))
        if max(im.shape[:2]) > 1600:
            s = 1600 / max(im.shape[:2])
            im = cv2.resize(im, (int(im.shape[1] * s), int(im.shape[0] * s)))
        imgs.append(im)
    if len(imgs) < 2:
        raise ValueError("Pick at least two photos")
    stitcher = cv2.Stitcher_create(cv2.Stitcher_PANORAMA) if hasattr(cv2, "Stitcher_create") else cv2.Stitcher()
    status, pano = stitcher.stitch(imgs)
    if status != cv2.Stitcher_OK:
        raise ValueError(f"Stitcher could not align these photos (code {status})")
    h, w = pano.shape[:2]
    doc = Document(width=w, height=h, path=None)
    doc.layers.append(PixelLayer(name="Pano", pixels=pano))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return None, None, None


def cmd_doc_hdr_merge(session: Session, paths):
    """Merge to HDR Pro-lite: Mertens fusion of 2+ exposures into a new doc."""
    import cv2
    from PIL import Image
    imgs = [cv2.cvtColor(np.asarray(Image.open(p).convert("RGB")), cv2.COLOR_RGB2BGR)
            for p in paths]
    if len(imgs) < 2:
        raise ValueError("Pick at least two exposures")
    size = (min(i.shape[1] for i in imgs), min(i.shape[0] for i in imgs))
    imgs = [cv2.resize(i, size) for i in imgs]
    merge = cv2.createMergeMertens()
    hdr = merge.process(imgs)
    hdr = (np.clip(hdr, 0, 1) * 255).astype(np.uint8)
    rgb = cv2.cvtColor(hdr, cv2.COLOR_BGR2RGB)
    h, w = rgb.shape[:2]
    doc = Document(width=w, height=h, path=None)
    doc.layers.append(PixelLayer(name="HDR", pixels=rgb))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return None, None, None


# --------------------------------------------- 27.6-era workflow (on-device)
def cmd_file_delete_empty_layers(session: Session, rename=True):
    """Layer Cleanup (PS 27.6): remove empty layers, rename the rest by what
    they look like (dominant hue / tone / shape heuristic)."""
    doc = session.doc
    if doc is None:
        return None, None, None
    from pf.doc import PixelLayer as PL, TextLayer as TL, ShapeLayer as SL, GroupLayer as GL

    def describe(px):
        a = px[..., 3]
        ys, xs = np.nonzero(a)
        if len(ys) == 0:
            return "Empty"
        content = px[a > 10]
        r, g, b = content[:, 0].mean(), content[:, 1].mean(), content[:, 2].mean()
        mx, mn = max(r, g, b), min(r, g, b)
        sat = 0 if mx < 1e-3 else (mx - mn) / mx
        lum = 0.299 * r + 0.587 * g + 0.114 * b
        hue = None
        if sat > 0.2:
            if r >= g and r >= b:
                hue = "Red" if g < b * 1.4 else "Orange"
            elif g >= r and g >= b:
                hue = "Green"
            else:
                hue = "Blue" if b > g * 1.3 else "Purple"
        tone = "White" if lum > 200 else ("Black" if lum < 55 else ("Gray" if sat <= 0.2 else ""))
        return " ".join(x for x in (hue or tone, "fill" if hue else "") .split()) or tone or "Layer"

    order = list(doc.layers)
    removed = []
    new_names = {}
    for l in order:
        if isinstance(l, PL):
            if l.pixels is None or not (l.pixels[..., 3] > 8).any():
                removed.append(l)
            elif rename and l.name.startswith(("Layer", "Pasted", "layer")):
                new_names[l.uid] = describe(l.pixels) or l.name
        elif isinstance(l, (TL, SL)):
            if rename and l.name.startswith(("Layer", "Text", "Shape")):
                base = (l.params.get("text", "").strip().split("\n")[0][:18] if isinstance(l, TL)
                        else str(l.params.get("shape", "Shape")).title())
                if base:
                    new_names[l.uid] = base
        elif isinstance(l, GL):
            if not l.children:
                removed.append(l)
    if not removed and not new_names:
        return None, None, None

    def apply(s):
        d = s.doc
        if d is None:
            return
        for l in removed:
            if l in d.layers:
                d.layers.remove(l)
        if d.active_uid in [r.uid for r in removed]:
            d.active_uid = d.layers[-1].uid if d.layers else None
        for l in d.flat_composite_list():
            if l.uid in new_names:
                l.name = new_names[l.uid]

    def undo(s):
        d = s.doc
        if d is None:
            return
        pos = {id(l): i for i, l in enumerate(order)}
        for l in removed:
            if l not in d.layers:
                d.layers.insert(min(pos.get(id(l), len(d.layers)), len(d.layers)), l)
        for l in d.flat_composite_list():
            pass
        # restore original names
        for l in order:
            if l.uid in getattr(l, "_pf_prev_name", {}):
                l.name = l._pf_prev_name[l.uid][0]

    # capture previous names for exact undo
    prev = {}
    for l in order:
        if l.uid in new_names:
            prev[l.uid] = l.name
            l._pf_prev_name = {l.uid: [l.name]}
    def redo(s):
        apply(s)

    apply(session)
    session.emit("doc")
    session.emit("history")
    return {"removed": len(removed), "renamed": len(new_names)}, undo, redo


def cmd_edit_rotate_object(session: Session, angle=0, scale=1.0, uid=None):
    """Rotate Object (PS 27.6): spin the active pixel layer's pixels about its
    own center at any angle, keeping the layer box."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    import cv2
    px = layer.pixels
    h, w = px.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), float(angle), float(scale))
    out = cv2.warpAffine(px, M, (w, h), flags=cv2.INTER_LINEAR,
                         borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    before = px.copy()
    layer.pixels = out
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_product_shot(session: Session, style="studio", shadow=True, color=(245, 245, 247)):
    """Product Shot (Photoroom-style): matte the subject, drop it on a clean
    e-commerce backdrop, and generate a soft contact shadow underneath."""
    doc = session.doc
    from pf import compose as _c
    comp = _c.composite_rgba8(doc)
    if comp is None:
        return None, None, None
    import cv2
    h, w = comp.shape[:2]
    small = cv2.resize(comp, (640, max(1, int(640 * h / w))), interpolation=cv2.INTER_AREA)
    m = np.zeros(small.shape[:2], np.uint8)
    m[:] = cv2.GC_BGD
    pad = max(2, int(min(small.shape[:2]) * 0.03))
    m[pad:-pad, pad:-pad] = cv2.GC_PR_BGD
    inner = max(pad + 2, int(min(small.shape[:2]) * 0.2))
    m[inner:-inner, inner:-inner] = cv2.GC_PR_FGD
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(small[..., :3], m, None, bgd, fgd, 4, cv2.GC_INIT_WITH_MASK)
    except cv2.error:
        return None, None, None
    matte = np.isin(m, [cv2.GC_FGD, cv2.GC_PR_FGD]).astype(np.uint8) * 255
    matte = cv2.resize(matte, (w, h), interpolation=cv2.INTER_LINEAR)
    matte = cv2.GaussianBlur(matte, (0, 0), 1.5)
    alpha = matte.astype(np.float32) / 255.0
    ys, xs = np.nonzero(alpha > 0.5)
    if len(ys) == 0:
        raise ValueError("No subject found for the product shot")
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()

    # backdrop
    bg = np.zeros((h, w, 3), np.float32)
    if style == "solid":
        bg[..., 0], bg[..., 1], bg[..., 2] = color
    else:  # studio radial gradient
        base = np.array(color, np.float32)
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        d = np.sqrt(((xx - cx) / w) ** 2 + ((yy - cy) / h) ** 2)
        k = np.clip(1 - d * 1.4, 0, 1) * 0.10
        bg = base * (1 - k[..., None])
    out = np.zeros((h, w, 4), np.float32)
    out[..., :3] = bg
    out[..., 3] = 255

    if shadow:
        band = max(4, int(min(h, w) * 0.02))
        foot_y = min(int(y1 + band * 0.6), h - 1)
        sh = np.zeros((h, w), np.float32)
        sw = max(6, int((x1 - x0) * 0.5))
        cx = (x0 + x1) // 2
        sh[max(0, foot_y - band):min(h, foot_y + band),
           max(0, cx - sw):min(w, cx + sw)] = 1.0
        sh = cv2.GaussianBlur(sh, (0, 0), band * 0.7) * 0.45
        sh = sh * np.clip(1.0 - (np.abs(np.arange(h)[:, None] - foot_y) / max(band * 2.2, 1)), 0, 1)
        dark = np.array([0.55, 0.53, 0.55], np.float32)
        out[..., :3] = out[..., :3] * (1 - sh[..., None]) + out[..., :3] * dark * sh[..., None]

    a3 = alpha[..., None]
    out[..., :3] = comp[..., :3].astype(np.float32) * a3 + out[..., :3] * (1 - a3)
    doc = Document(width=w, height=h, path=doc.path)
    doc.layers.append(PixelLayer(name="Product",
                                 pixels=np.clip(out + 0.5, 0, 255).astype(np.uint8)))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return None, None, None


def cmd_image_relight(session: Session, angle=315, strength=0.5, falloff=1.2):
    """Relight AI-lite (Luminar): emulate a light source at `angle` degrees —
    soft directional shading with a gentle highlight bloom on the lit side."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    import cv2
    px = layer.pixels
    h, w = px.shape[:2]
    f = px.astype(np.float32) / 255.0
    gray = 0.299 * f[..., 0] + 0.587 * f[..., 1] + 0.114 * f[..., 2]
    depth = cv2.GaussianBlur(gray, (0, 0), min(h, w) * 0.12)   # crude depth proxy
    depth = (depth - depth.min()) / max(float(np.ptp(depth)), 1e-3)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = w / 2, h / 2
    th = np.radians(float(angle))
    lx, ly = np.cos(th), -np.sin(th)
    g = ((xx - cx) * lx + (yy - cy) * ly) / (min(w, h) * 0.7 * float(falloff))
    g = np.clip(g, -1, 1)                                   # -1 away, +1 toward light
    s = float(np.clip(strength, 0, 1))
    shade = 1.0 + s * 0.45 * g - s * 0.25 * depth           # directional + depth dim
    out = px.copy()
    out[..., :3] = np.clip(f[..., :3] * shade[..., None] * 255 + 0.5, 0, 255).astype(np.uint8)
    before = px.copy()
    layer.pixels = out
    uid_ = layer.uid
    def undo(s2):
        lay = s2.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s2):
        lay = s2.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_restore_old(session: Session, denoise=8, colorize=False):
    """Restoration (Luminar-style): dust/scratch removal, denoise, faded
    contrast recovery, optional warm tone for monochrome originals."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    import cv2
    px = layer.pixels
    rgb = px[..., :3]
    # 1) dust & speckle
    med = cv2.medianBlur(rgb, 3)
    diff = np.abs(rgb.astype(np.int16) - med.astype(np.int16)).max(-1)
    rgb = np.where((diff > 40)[..., None], med, rgb)
    # 2) edge-preserving denoise FIRST — the contrast step below is a global
    #    LUT and cannot re-create high-frequency noise
    rgb = cv2.fastNlMeansDenoisingColored(rgb, None, float(denoise), float(denoise), 7, 21)
    f = rgb.astype(np.float32) / 255.0
    # 3) faded contrast: bounded-slope levels LUT built from BLURRED luma
    #    percentiles, so noise flutter never defines the range and no
    #    per-pixel gain can blow up
    lum = 0.299 * f[..., 0] + 0.587 * f[..., 1] + 0.114 * f[..., 2]
    r = max(3, min(lum.shape) // 12)
    struct = cv2.GaussianBlur(lum, (0, 0), r)
    lo, hi = np.percentile(struct, 2), np.percentile(struct, 98)
    if hi - lo > 0.08:   # need real structure, not noise flutter
        slope = min(0.92 / (hi - lo), 4.0)
        c = (lo + hi) / 2
        xs = np.arange(256, dtype=np.float32) / 255.0
        lut = np.clip(0.475 + (xs - c) * slope, 0.03, 0.95)
        f[..., :3] = lut[np.clip(f[..., :3] * 255, 0, 255).astype(np.uint8)]
    if colorize:
        warm = np.array([1.04, 0.98, 0.9], np.float32)
        f[..., :3] = np.clip(f[..., :3] * warm, 0, 1)
    out = px.copy()
    out[..., :3] = np.clip(f * 255 + 0.5, 0, 255).astype(np.uint8)
    before = px.copy()
    layer.pixels = out
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_portrait_pro(session: Session, skin=0.55, eye=0.35):
    """Portrait Pro (Face AI-lite): Haar-detect faces; smooth skin inside them,
    brighten eyes, keep everything else untouched. Falls back to global soft
    smoothing when no face is found."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    import cv2
    px = layer.pixels
    rgb = px[..., :3]
    h, w = rgb.shape[:2]
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    faces = []
    cascade = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    if os.path.exists(cascade):
        det = cv2.CascadeClassifier(cascade)
        faces = det.detectMultiScale(gray, 1.15, 5, minSize=(max(24, w // 20),) * 2)
    smooth_all = cv2.bilateralFilter(rgb, 9, 60, 20).astype(np.float32)
    out = rgb.astype(np.float32).copy()
    s = float(np.clip(skin, 0, 1))
    if len(faces):
        for (fx, fy, fw, fh) in faces:
            m = np.zeros((h, w), np.float32)
            cv2.ellipse(m, (fx + fw // 2, fy + int(fh * 0.55)),
                        (int(fw * 0.52), int(fh * 0.42)), 0, 0, 360, 1.0, -1)
            m = cv2.GaussianBlur(m, (0, 0), max(2, fw * 0.1))[..., None]
            out = out * (1 - m * s) + smooth_all * (m * s)
            # eyes: brighten + clarify
            ecas = os.path.join(cv2.data.haarcascades, "haarcascade_eye.xml")
            if os.path.exists(ecas) and eye > 0:
                roi = gray[fy:fy + fh, fx:fx + fw]
                eyes = cv2.CascadeClassifier(ecas).detectMultiScale(roi, 1.1, 4,
                                                                    minSize=(fw // 12,) * 2)
                for (ex, ey, ew, eh) in eyes[:2]:
                    ey0, ey1 = max(0, fy + ey), min(h, fy + ey + eh)
                    ex0, ex1 = max(0, fx + ex), min(w, fx + ex + ew)
                    patch = out[ey0:ey1, ex0:ex1]
                    lum = patch.mean(-1, keepdims=True)
                    out[ey0:ey1, ex0:ex1] = patch * (1 - eye) + (lum * 1.12 + 8) * eye
    else:
        out = out * (1 - s) + smooth_all * s
    before = px.copy()
    new = px.copy()
    new[..., :3] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    layer.pixels = new
    uid_ = layer.uid
    session.last_faces = len(faces)
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_image_find_distractions(session: Session, heal_tiny=True, max_px=400):
    """Find Distractions (PS 27.6-lite): detect small high-contrast specks,
    auto-heal the tiny ones, report the bigger ones as points to review."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return ([], 0, None), None, None
    import cv2
    px = layer.pixels
    rgb = px[..., :3]
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    th = cv2.medianBlur(gray, 5)
    diff = cv2.absdiff(gray, th)
    m = (diff > 26).astype(np.uint8) * 255
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
    spots = []
    healed = 0
    mask = np.zeros(gray.shape, np.uint8)
    for i in range(1, n):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < 3 or area > max_px:
            continue
        x, y, ww, hh = stats[i, 0], stats[i, 1], stats[i, 2], stats[i, 3]
        spots.append((int(x + ww / 2), int(y + hh / 2), int(area)))
        if heal_tiny and area <= 40:
            r = max(3, int(max(ww, hh) / 2) + 3)
            cv2.circle(mask, (int(x + ww / 2), int(y + hh / 2)), r, 255, -1)
            healed += 1
    before = px.copy()
    if healed:
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        fixed = cv2.inpaint(bgr, mask, 5, cv2.INPAINT_TELEA)
        fixed = cv2.cvtColor(fixed, cv2.COLOR_BGR2RGB).astype(np.float32)
        mm = (mask.astype(np.float32) / 255.0)[..., None]
        out = px.astype(np.float32)
        out[..., :3] = out[..., :3] * (1 - mm) + fixed * mm
        layer.pixels[:] = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return (spots, healed, uid_), undo, redo


def cmd_doc_focus_stack(session: Session, paths):
    """Focus Stacking (Luminar): blend N focus brackets — the sharpest pixels
    (max Laplacian response, blended) win."""
    import cv2
    from PIL import Image
    imgs = []
    for p in paths:
        im = np.asarray(Image.open(p).convert("RGB"))
        if max(im.shape[:2]) > 2200:
            s = 2200 / max(im.shape[:2])
            im = cv2.resize(im, (int(im.shape[1] * s), int(im.shape[0] * s)))
        imgs.append(im)
    if len(imgs) < 2:
        raise ValueError("Pick at least two focus brackets")
    size = (min(i.shape[1] for i in imgs), min(i.shape[0] for i in imgs))
    imgs = [cv2.resize(i, size) for i in imgs]
    sharps, wts = [], []
    for im in imgs:
        g = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY)
        lap = np.abs(cv2.Laplacian(g, cv2.CV_32F, ksize=5))
        wts.append(cv2.GaussianBlur(lap, (0, 0), 2) + 1e-6)
        sharps.append(im.astype(np.float32))
    acc = np.zeros_like(sharps[0])
    for im, wt in zip(sharps, wts):
        acc += im * wt[..., None]
    acc /= sum(wts)[..., None]
    rgb = np.clip(acc + 0.5, 0, 255).astype(np.uint8)
    h, w = rgb.shape[:2]
    doc = Document(width=w, height=h, path=None)
    doc.layers.append(PixelLayer(name="Focus Stack", pixels=rgb))
    doc.active_uid = doc.layers[0].uid
    session.doc = doc
    session.undo_stack.clear()
    session.redo_stack.clear()
    session.emit("doc")
    session.emit("history")
    return None, None, None


def cmd_image_watermark(session: Session, text="© PixelForge", corner="bottom-right",
                        opacity=0.35, tile=False, uid=None):
    """Text watermark — used by Batch and the AI Studio."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    from PIL import Image, ImageDraw, ImageFont
    px = layer.pixels
    h, w = px.shape[:2]
    img = Image.fromarray(px[..., :3])
    wm = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(wm)
    fsize = max(14, min(w, h) // 18)
    try:
        fdir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "assets", "fonts", "Inter-SemiBold.ttf")
        f = ImageFont.truetype(fdir, fsize)
    except Exception:
        f = ImageFont.load_default()
    alpha = int(255 * float(np.clip(opacity, 0.05, 1)))
    gray = np.asarray(img.convert("L")).astype(np.float32)

    def pick_ink(region):
        mean_l = float(region.mean()) if region.size else float(gray.mean())
        if mean_l < 140:
            return (255, 255, 255, alpha), (0, 0, 0, alpha)
        return (12, 12, 12, alpha), (245, 245, 245, alpha)

    if tile:
        ink, stroke = pick_ink(gray)
        step_x, step_y = max(120, w // 3), max(90, h // 4)
        for yy in range(0, h, step_y):
            for xx in range(0, w, step_x):
                d.text((xx, yy), text, font=f, fill=ink,
                       stroke_width=max(1, fsize // 16), stroke_fill=stroke)
    else:
        bbox = d.textbbox((0, 0), text, font=f)
        tw, th_ = bbox[2] - bbox[0], bbox[3] - bbox[1]
        pos = {"bottom-right": (w - tw - 18, h - th_ - 18),
               "bottom-left": (18, h - th_ - 18),
               "top-right": (w - tw - 18, 18),
               "top-left": (18, 18),
               "center": ((w - tw) // 2, (h - th_) // 2)}[corner]
        x0p, y0p = max(0, pos[0]), max(0, pos[1])
        region = gray[y0p:min(h, pos[1] + th_ + 4), x0p:min(w, pos[0] + tw + 4)]
        ink, stroke = pick_ink(region)
        d.text(pos, text, font=f, fill=ink,
               stroke_width=max(1, fsize // 16), stroke_fill=stroke)
    from pf.doc import Document as _Doc
    wm_px = np.zeros_like(px)
    wm_px[..., :3] = np.asarray(wm.convert("RGB"))
    wm_px[..., 3] = np.asarray(wm)[..., 3]
    wm_layer = PixelLayer(name="Watermark", pixels=wm_px)
    snapshot = _snapshot_layers(doc)
    doc.layers.append(wm_layer)
    doc.active_uid = wm_layer.uid
    uid_ = wm_layer.uid
    def undo(s):
        if s.doc is not None:
            _restore_layers(s, snapshot)
    def redo(s):
        if s.doc is not None:
            s.doc.layers.append(wm_layer)
            s.doc.active_uid = wm_layer.uid
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def ndimage_g(a, sigma):
    from scipy import ndimage
    return ndimage.gaussian_filter(a.astype(np.float32), sigma).astype(a.dtype) if a.dtype == np.uint8 \
        else ndimage.gaussian_filter(a.astype(np.float32), sigma)


# ------------------------------------------------------------------ filters
def cmd_filter_run(session: Session, filter_id: str, **params):
    """Run a registered filter on the active pixel layer, honoring selection."""
    entry = F.REGISTRY.get(filter_id)
    if entry is None:
        raise KeyError(f"unknown filter `{filter_id}`")
    fn, defaults, _, _ = entry
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    p = dict(defaults)
    p.update(params)
    if filter_id == "gaussianBlur" and session.doc.warnings:
        pass
    before = layer.pixels.copy()
    region = _sel_mask(doc) if doc.selection is not None else None
    if region is None:
        layer.pixels = fn(layer.pixels, **p)
    else:
        patched = fn(layer.pixels, **p)
        out = layer.pixels.copy()
        out[region] = patched[region]
        layer.pixels = out
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = layer.pixels
    return uid_, undo, redo


def cmd_edit_fill(session: Session, color=(0, 0, 0, 255), uid=None, only_selection=True):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer):
        return None, None, None
    if only_selection and doc.selection is not None:
        m = _sel_mask(doc)
        before = layer.pixels.copy()
        region = layer.pixels[m]
        region[..., :3] = color[:3]
        region[..., 3] = color[3] if len(color) > 3 else 255
        layer.pixels[m] = region
        uid_ = layer.uid
        def undo(s):
            lay = s.doc.find(uid_)
            if lay is not None and isinstance(lay, PixelLayer):
                lay.pixels = before
        def redo(s):
            lay = s.doc.find(uid_)
            if lay is not None and isinstance(lay, PixelLayer):
                lay.pixels[m] = region
        return uid_, undo, redo
    x0, y0, x1, y1 = 0, 0, doc.width, doc.height
    lx0, ly0 = max(x0, layer.x), max(y0, layer.y)
    lx1, ly1 = min(x1, layer.x + layer.w), min(y1, layer.y + layer.h)
    if lx1 <= lx0 or ly1 <= ly0:
        return None, None, None
    before = layer.pixels[ly0 - layer.y:ly1 - layer.y, lx0 - layer.x:lx1 - layer.x].copy()
    target = layer.pixels[ly0 - layer.y:ly1 - layer.y, lx0 - layer.x:lx1 - layer.x]
    target[..., :3] = color[:3]
    target[..., 3] = color[3] if len(color) > 3 else 255
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[ly0 - lay.y:ly1 - lay.y, lx0 - lay.x:lx1 - lay.x] = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[ly0 - lay.y:ly1 - lay.y, lx0 - lay.x:lx1 - lay.x][..., :3] = color[:3]
            lay.pixels[ly0 - lay.y:ly1 - lay.y, lx0 - lay.x:lx1 - lay.x][..., 3] = color[3]
    return uid_, undo, redo


def cmd_edit_clear(session: Session, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer):
        return None, None, None
    m = _sel_mask(doc)
    before = layer.pixels.copy()
    layer.pixels[m] = 0
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[m] = 0
    return uid_, undo, redo


def cmd_edit_stroke_selection(session: Session, width=4, color=(0, 0, 0, 255), uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, PixelLayer) or doc.selection is None:
        return None, None, None
    from scipy import ndimage
    inner = _ndi.binary_erosion(doc.selection, iterations=int(width))
    ring = doc.selection & ~inner
    before = layer.pixels.copy()
    layer.pixels[ring] = np.array(color, np.uint8)
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels[ring] = np.array(color, np.uint8)
    return uid_, undo, redo


# ------------------------------------------------------- merge and flatten
def cmd_layer_merge_down(session: Session, uid=None):
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if layer is None:
        return None, None, None
    top = _top_ancestor(doc, layer)
    idx = doc.layers.index(top)
    if idx <= 0:
        return None, None, None
    below = doc.layers[idx - 1]
    if not isinstance(below, PixelLayer) or not isinstance(top, PixelLayer):
        return None, None, None
    merged_px, mx, my = _merge_pair(doc, below, top)
    snapshot = _snapshot_layers(doc)
    merged = PixelLayer(name=below.name, pixels=merged_px, x=mx, y=my,
                        opacity=below.opacity, blend=below.blend, visible=below.visible)
    doc.layers[idx - 1:idx + 1] = [merged]
    doc.active_uid = merged.uid
    def undo(s):
        _restore_layers(s, snapshot)
    def redo(s):
        s.doc.layers[idx - 1:idx + 1] = [merged]
        s.doc.active_uid = merged.uid
    return merged.uid, undo, redo


def _merge_pair(doc, below: PixelLayer, above: PixelLayer):
    x = min(below.x, above.x)
    y = min(below.y, above.y)
    x2 = max(below.x + below.w, above.x + above.w)
    y2 = max(below.y + below.h, above.y + above.h)
    buffer = np.zeros((y2 - y, x2 - x, 4), np.float32)
    below_off = PixelLayer(name=below.name, pixels=below.pixels, x=below.x - x, y=below.y - y,
                           opacity=below.opacity, blend=below.blend, visible=True)
    above_off = PixelLayer(name=above.name, pixels=above.pixels, x=above.x - x, y=above.y - y,
                           opacity=above.opacity, blend=above.blend, visible=True)
    compose._blend_layer(buffer, below_off, x2 - x, y2 - y)
    compose._blend_layer(buffer, above_off, x2 - x, y2 - y)
    px = np.clip(buffer * 255.0 + 0.5, 0, 255).astype(np.uint8)
    return px, x, y


def cmd_layer_flatten(session: Session):
    doc = session.doc
    snapshot = _snapshot_layers(doc)
    canvas = compose.composite_document(doc)
    px = np.clip(canvas * 255.0 + 0.5, 0, 255).astype(np.uint8)
    flat = PixelLayer(name="Background", pixels=px)
    doc.layers = [flat]
    doc.active_uid = flat.uid
    def undo(s):
        _restore_layers(s, snapshot)
    def redo(s):
        s.doc.layers = [flat]
        s.doc.active_uid = flat.uid
    return flat.uid, undo, redo


def cmd_layer_rasterize(session: Session, uid=None):
    """Bake a live layer (text/shape) into pixels."""
    doc = session.doc
    layer = doc.find(uid) if uid else doc.active
    if not isinstance(layer, (TextLayer, ShapeLayer)):
        return None, None, None
    snapshot = _snapshot_layers(doc)
    r = compose._rasterize_live(layer)
    px, lx, ly = r if r else (np.zeros((1, 1, 4), np.uint8), 0, 0)
    baked = PixelLayer(name=layer.name, pixels=px, x=lx, y=ly, opacity=layer.opacity,
                       blend=layer.blend, visible=layer.visible, mask=layer.mask,
                       effects=copy.deepcopy(layer.effects))
    idx = doc.layers.index(layer)
    doc.layers[idx] = baked
    doc.active_uid = baked.uid
    def undo(s):
        _restore_layers(s, snapshot)
    def redo(s):
        s.doc.layers[idx] = baked
        s.doc.active_uid = baked.uid
    return baked.uid, undo, redo




def cmd_image_remove_background(session: Session, softness=2):
    """Canva-style one-click background removal on the active layer (GrabCut)."""
    doc = session.doc
    layer = doc.active
    if not isinstance(layer, PixelLayer) or layer.pixels is None:
        return None, None, None
    try:
        import cv2
    except Exception:
        raise RuntimeError("background removal needs opencv-python")
    comp = compose.composite_rgb8(doc)
    rgb = cv2.cvtColor(comp, cv2.COLOR_RGB2BGR)
    mask = np.zeros(comp.shape[:2], np.uint8)
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    pad = int(min(doc.width, doc.height) * 0.03) + 2
    cv2.grabCut(rgb, mask, (pad, pad, doc.width - 2 * pad, doc.height - 2 * pad),
                bgd, fgd, 5, cv2.GC_INIT_WITH_RECT)
    m = ((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)).astype(np.uint8) * 255
    m = _ndi.binary_opening(m > 0, iterations=2).astype(np.uint8) * 255
    m = _ndi.gaussian_filter(m.astype(np.float32), float(softness))
    before = layer.pixels.copy()
    out = layer.pixels.copy()
    # composite-visible area of this layer only: keep layer alpha where subject
    a = out[..., 3].astype(np.float32) * (m / 255.0)
    out[..., 3] = np.clip(a + 0.5, 0, 255).astype(np.uint8)
    layer.pixels = out
    uid_ = layer.uid
    def undo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = before
    def redo(s):
        lay = s.doc.find(uid_)
        if lay is not None and isinstance(lay, PixelLayer):
            lay.pixels = out
    return uid_, undo, redo

def _top_ancestor(doc: Document, layer: Layer) -> Layer:
    for cand, parent in doc.walk():
        if cand.uid == layer.uid and parent is doc.layers:
            return cand
    return layer


def _locate(doc: Document, layer: Layer):
    for cand, parent in doc.walk():
        if cand.uid == layer.uid:
            return parent, parent.index(cand)
    return doc.layers, len(doc.layers)


# ----------------------------------------------------------------- registry
def _register():
    table = {
        "doc.new": cmd_doc_new, "doc.open": cmd_doc_open, "doc.save": cmd_doc_save,
        "doc.place": cmd_doc_place,
        "layer.add": cmd_layer_add, "layer.addGroup": cmd_layer_add_group,
        "layer.remove": cmd_layer_remove, "layer.duplicate": cmd_layer_duplicate,
        "layer.select": cmd_layer_select, "layer.setProps": cmd_layer_set_props,
        "layer.reorder": cmd_layer_reorder, "layer.translate": cmd_layer_translate,
        "layer.movePixels": cmd_layer_move_pixels,
        "layer.mergeDown": cmd_layer_merge_down, "layer.flatten": cmd_layer_flatten,
        "layer.rasterize": cmd_layer_rasterize,
        "layer.mask.new": cmd_layer_mask_new, "layer.mask.delete": cmd_layer_mask_delete,
        "layer.mask.paint": cmd_layer_mask_paint,
        "layer.newText": cmd_layer_new_text, "layer.setText": cmd_layer_set_text,
        "layer.newShape": cmd_layer_new_shape, "layer.setShape": cmd_layer_set_shape,
        "layer.newAdjustment": cmd_layer_new_adjustment,
        "layer.setAdjustment": cmd_layer_set_adjustment,
        "layer.setEffects": cmd_layer_set_effects,
        "layer.transform": cmd_layer_transform, "layer.flip": cmd_layer_flip,
        "layer.rotate90": cmd_layer_rotate90,
        "selection.setMask": cmd_selection_set_mask, "selection.rect": cmd_selection_rect,
        "selection.ellipse": cmd_selection_ellipse, "selection.polygon": cmd_selection_polygon,
        "selection.wand": cmd_selection_magic_wand, "selection.colorRange": cmd_selection_color_range,
        "selection.invert": cmd_selection_invert, "selection.feather": cmd_selection_feather,
        "selection.growContract": cmd_selection_grow_contract,
        "selection.subject": cmd_selection_subject,
        "selection.all": cmd_selection_all, "selection.deselect": cmd_selection_deselect,
        "paint.stroke": cmd_paint_stroke, "paint.bucket": cmd_paint_bucket,
        "paint.gradient": cmd_paint_gradient, "paint.clone": cmd_paint_clone,
        "paint.dodgeBurn": cmd_paint_dodge_burn, "paint.blurSharpen": cmd_paint_blur_sharpen,
        "paint.smudge": cmd_paint_smudge, "paint.sponge": cmd_paint_sponge,
        "image.spotHeal": cmd_image_spot_heal, "image.redEye": cmd_image_red_eye,
        "selection.quick": cmd_selection_quick, "selection.objectRect": cmd_selection_object_rect,
        "image.healStroke": cmd_image_heal_stroke, "image.patchHeal": cmd_image_patch_heal,
        "image.contentAwareMove": cmd_image_content_aware_move,
        "paint.patternStamp": cmd_paint_pattern_stamp, "paint.bgErase": cmd_paint_bg_erase,
        "image.historyReveal": cmd_image_history_reveal,
        "image.upscaleSmart": cmd_image_upscale_smart, "image.expandGen": cmd_image_expand_gen,
        "layer.harmonize": cmd_layer_harmonize, "image.matchColorFile": cmd_image_match_color_file,
        "image.skyReplace": cmd_image_sky_replace,
        "doc.photomerge": cmd_doc_photomerge, "doc.hdrMerge": cmd_doc_hdr_merge,
        "file.scripts.deleteAllEmptyLayers": cmd_file_delete_empty_layers,
        "edit.rotateObject": cmd_edit_rotate_object,
        "image.productShot": cmd_image_product_shot, "image.relight": cmd_image_relight,
        "image.restoreOld": cmd_image_restore_old, "image.portraitPro": cmd_image_portrait_pro,
        "image.findDistractions": cmd_image_find_distractions,
        "doc.focusStack": cmd_doc_focus_stack, "image.watermark": cmd_image_watermark,
        "image.resize": cmd_image_resize, "image.crop": cmd_image_crop,
        "image.canvasSize": cmd_image_canvas_size, "image.rotateCanvas": cmd_image_rotate_canvas,
        "image.flipCanvas": cmd_image_flip_canvas, "image.trim": cmd_image_trim,
        "image.removeBackground": cmd_image_remove_background,
        "edit.fill": cmd_edit_fill, "edit.clear": cmd_edit_clear,
        "edit.strokeSelection": cmd_edit_stroke_selection,
        "filter.run": cmd_filter_run,
    }
    labels = {
        "doc.new": "New", "doc.open": "Open", "doc.save": "Save", "doc.place": "Place",
        "layer.add": "New Layer", "layer.addGroup": "New Group",
        "layer.remove": "Delete Layer", "layer.duplicate": "Duplicate Layer",
        "layer.select": "Select Layer", "layer.setProps": "Layer Properties",
        "layer.reorder": "Reorder Layer", "layer.translate": "Move Layer",
        "layer.movePixels": "Move Pixels", "layer.mergeDown": "Merge Down",
        "layer.flatten": "Flatten Image", "layer.rasterize": "Rasterize Layer",
        "layer.mask.new": "Add Layer Mask", "layer.mask.delete": "Delete Layer Mask",
        "layer.mask.paint": "Paint Mask",
        "layer.newText": "Text Layer", "layer.setText": "Edit Text",
        "layer.newShape": "Shape Layer", "layer.setShape": "Edit Shape",
        "layer.newAdjustment": "New Adjustment Layer",
        "layer.setAdjustment": "Adjustment Properties",
        "layer.setEffects": "Layer Style", "layer.transform": "Free Transform",
        "layer.flip": "Flip Layer", "layer.rotate90": "Rotate Layer 90°",
        "image.resize": "Image Size", "image.crop": "Crop",
        "image.canvasSize": "Canvas Size", "image.rotateCanvas": "Rotate Canvas",
        "image.flipCanvas": "Flip Canvas", "image.trim": "Trim",
        "image.removeBackground": "Remove Background",
        "image.spotHeal": "Spot Healing Brush", "image.redEye": "Red Eye",
        "paint.smudge": "Smudge", "paint.sponge": "Sponge",
        "selection.quick": "Quick Selection", "selection.objectRect": "Object Selection",
        "image.healStroke": "Healing Brush", "image.patchHeal": "Patch",
        "image.contentAwareMove": "Content-Aware Move",
        "paint.patternStamp": "Pattern Stamp", "paint.bgErase": "Background Eraser",
        "image.historyReveal": "History Brush",
        "image.upscaleSmart": "Smart Upscale", "image.expandGen": "Generative Expand",
        "layer.harmonize": "Harmonize", "image.matchColorFile": "Match Color",
        "image.skyReplace": "Replace Sky",
        "doc.photomerge": "Photomerge", "doc.hdrMerge": "Merge to HDR",
        "file.scripts.deleteAllEmptyLayers": "Layer Cleanup",
        "edit.rotateObject": "Rotate Object",
        "image.productShot": "Product Shot", "image.relight": "Relight",
        "image.restoreOld": "Restore Old Photo", "image.portraitPro": "Portrait Pro",
        "image.findDistractions": "Find Distractions",
        "doc.focusStack": "Focus Stack", "image.watermark": "Watermark",
        "edit.fill": "Fill", "edit.clear": "Clear", "edit.strokeSelection": "Stroke",
    }
    # selections + paint + filters get labels from names
    for cmd_id, fn in table.items():
        fn.__cmd_id__ = cmd_id
        fn.__label__ = labels.get(cmd_id, cmd_id)
        if cmd_id in ("doc.new", "doc.open"):
            fn.__session_cmd__ = True
    return table


REGISTRY = _register()


# convenience: register each filter as its own command id for CLI/batch parity
def register_filter_commands():
    for fid, (fn, defaults, label, category) in F.REGISTRY.items():
        cid = f"filter.{category.lower()}.{fid}"

        def _make(fid_=fid):
            def cmd(session: Session, **params):
                return cmd_filter_run(session, fid_, **params)
            cmd.__label__ = label
            cmd.__cmd_id__ = cid
            return cmd

        REGISTRY[cid] = _make()


register_filter_commands()
