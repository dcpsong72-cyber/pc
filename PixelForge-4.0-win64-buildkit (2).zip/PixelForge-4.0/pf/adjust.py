"""L2 — adjustment math (mirror of their algo adjustments). Pure numpy.

All ops take float32 RGB in [0,1] and return float32 RGB in [0,1].
"""

from __future__ import annotations

import numpy as np


def _clip(x):
    return np.clip(x, 0.0, 1.0).astype(np.float32)


def brightness_contrast(rgb, brightness=0.0, contrast=0.0):
    out = rgb + brightness * 0.5
    factor = np.tan((np.clip(contrast, -0.99, 0.99) + 1.0) * np.pi / 4.0)
    return _clip((out - 0.5) * factor + 0.5)


def levels(rgb, black=0.0, white=1.0, gamma=1.0):
    black, white, gamma = float(black), max(float(white), float(black) + 1e-3), max(float(gamma), 0.01)
    x = np.clip((rgb - black) / (white - black), 0.0, 1.0)
    return _clip(x ** (1.0 / gamma))


def curves(rgb, points=None):
    pts = np.array(points or [[0, 0], [255, 255]], np.float32)
    xs, ys = pts[:, 0] / 255.0, pts[:, 1] / 255.0
    xs = np.maximum.accumulate(xs)
    lut = np.interp(np.linspace(0, 1, 256), xs, ys).astype(np.float32)
    idx = np.clip(rgb * 255, 0, 255).astype(np.uint8)
    return (lut[idx]).astype(np.float32)


def exposure(rgb, ev=0.0):
    return _clip(rgb * (2.0 ** float(ev)))


def _rgb_to_hsv(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    maxc = rgb.max(-1)
    minc = rgb.min(-1)
    v = maxc
    delta = maxc - minc
    s = np.where(maxc > 0, delta / np.maximum(maxc, 1e-6), 0.0)
    rc = np.where(delta > 0, (maxc - r) / np.maximum(delta, 1e-6), 0)
    gc = np.where(delta > 0, (maxc - g) / np.maximum(delta, 1e-6), 0)
    bc = np.where(delta > 0, (maxc - b) / np.maximum(delta, 1e-6), 0)
    h = np.where(r == maxc, bc - gc, np.where(g == maxc, 2.0 + rc - bc, 4.0 + gc - rc))
    h = (h / 6.0) % 1.0
    h = np.where(delta <= 0, 0.0, h)
    return h, s, v


def _hsv_to_rgb(h, s, v):
    i = np.floor(h * 6.0).astype(int)
    f = h * 6.0 - i
    p = v * (1 - s)
    q = v * (1 - s * f)
    t = v * (1 - s * (1 - f))
    i = i % 6
    r = np.choose(i, [v, q, p, p, t, v])
    g = np.choose(i, [t, v, v, q, p, p])
    b = np.choose(i, [p, p, t, v, v, q])
    return np.stack([r, g, b], -1).astype(np.float32)


def hue_sat(rgb, hue=0.0, sat=0.0, light=0.0):
    h, s, v = _rgb_to_hsv(rgb)
    h = (h + hue / 360.0) % 1.0
    s = np.clip(s * (1.0 + sat), 0.0, 1.0)
    v = np.clip(v + light * (np.where(v < 0.5, v, 1 - v)), 0.0, 1.0)
    return _hsv_to_rgb(h, s, v)


def vibrance(rgb, amount=0.3):
    h, s, v = _rgb_to_hsv(rgb)
    # only boost pixels that actually have chroma (pure grays keep s=0)
    boost = amount * (1.0 - s) * (s > 1e-4)
    s = np.clip(s + boost, 0.0, 1.0)
    return _hsv_to_rgb(h, s, v)


def temperature(rgb, temp=0.0, tint=0.0):
    out = rgb.copy()
    out[..., 0] += temp * 0.25          # warm
    out[..., 2] -= temp * 0.25          # cool
    out[..., 1] += tint * 0.2           # green / magenta
    return _clip(out)


def invert(rgb):
    return _clip(1.0 - rgb)


def threshold(rgb, level=0.5):
    l = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    out = (l >= level).astype(np.float32)
    return np.repeat(out[..., None], 3, -1)


def posterize(rgb, levels=4):
    n = max(2, int(levels))
    return np.floor(rgb * (n - 1) + 0.5) / (n - 1)


def bw(rgb):
    l = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    return np.repeat(l[..., None], 3, -1).astype(np.float32)


def photo_filter(rgb, color=(255, 160, 40), density=0.25):
    c = np.array(color, np.float32) / 255.0
    d = float(np.clip(density, 0, 1))
    return _clip(rgb * (1 - d) + c * d * rgb + c * d * 0.15)


def gradient_map(rgb, shadow=(20, 24, 60), highlight=(255, 220, 160)):
    l = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    a = np.array(shadow, np.float32) / 255.0
    b = np.array(highlight, np.float32) / 255.0
    return (a[None, None] * (1 - l[..., None]) + b[None, None] * l[..., None]).astype(np.float32)


def clarity(rgb, amount=0.4, radius=24):
    """Local midtone contrast (the 2026 Clarity adjustment layer)."""
    a = float(np.clip(amount, -1, 1))
    if abs(a) < 1e-3:
        return rgb
    lum = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    if cv2 is not None:
        soft = cv2.GaussianBlur(lum, (0, 0), radius)
    else:
        soft = ndimage.gaussian_filter(lum, radius)
    detail = lum - soft
    out = lum + detail * a
    out = np.clip(out, 0, 1)
    gain = np.where(lum > 1e-4, out / np.maximum(lum, 1e-4), 1.0)
    return rgb * gain[..., None]


def dehaze(rgb, strength=0.5):
    """Haze reduction via a light dark-channel estimate (the Dehaze layer)."""
    s = float(np.clip(strength, 0, 1))
    if s < 1e-3:
        return rgb
    patch = 15
    dark = rgb.min(-1)
    if cv2 is not None:
        dark = cv2.erode(dark, np.ones((patch, patch), np.uint8))
        dark = cv2.GaussianBlur(dark, (0, 0), 8)
    else:
        dark = ndimage.minimum_filter(dark, patch)
    atmosphere = float(np.percentile(dark, 96))
    atmosphere = max(0.05, min(0.95, atmosphere))
    t = np.clip(1.0 - 0.9 * dark / atmosphere, 0.15, 1.0)
    out = (rgb - atmosphere * (1 - t)[..., None]) / t[..., None]
    return rgb * (1 - s) + out * s


def grain(rgb, amount=0.15, size=1.0, monochrome=True):
    """Film grain (the 2026 Grain adjustment layer)."""
    a = float(np.clip(amount, 0, 2))
    h, w = rgb.shape[:2]
    if a < 1e-3 or h == 0 or w == 0:
        return rgb
    rng = np.random.default_rng(7)
    sigma = a * 0.35
    if monochrome:
        n = rng.normal(0, sigma, (h, w)).astype(np.float32)
        if size > 1.0:
            from scipy import ndimage as _nd
            n = _nd.gaussian_filter(n, size - 1.0)
        return rgb + n[..., None]
    n = rng.normal(0, sigma, (h, w, 3)).astype(np.float32)
    return rgb + n


APPLY = {
    "clarity": lambda rgb, p: clarity(rgb, p.get("amount", 0.4)),
    "dehaze": lambda rgb, p: dehaze(rgb, p.get("strength", 0.5)),
    "grain": lambda rgb, p: grain(rgb, p.get("amount", 0.15), p.get("size", 1.0),
                                  p.get("monochrome", True)),
    "brightness_contrast": lambda rgb, p: brightness_contrast(rgb, p.get("brightness", 0), p.get("contrast", 0)),
    "levels": lambda rgb, p: levels(rgb, p.get("black", 0), p.get("white", 1), p.get("gamma", 1)),
    "curves": lambda rgb, p: curves(rgb, p.get("points")),
    "exposure": lambda rgb, p: exposure(rgb, p.get("ev", 0)),
    "hue_sat": lambda rgb, p: hue_sat(rgb, p.get("hue", 0), p.get("sat", 0), p.get("light", 0)),
    "vibrance": lambda rgb, p: vibrance(rgb, p.get("amount", 0.3)),
    "temperature": lambda rgb, p: temperature(rgb, p.get("temp", 0), p.get("tint", 0)),
    "invert": lambda rgb, p: invert(rgb),
    "threshold": lambda rgb, p: threshold(rgb, p.get("level", 0.5)),
    "posterize": lambda rgb, p: posterize(rgb, p.get("levels", 4)),
    "bw": lambda rgb, p: bw(rgb),
    "photo_filter": lambda rgb, p: photo_filter(rgb, p.get("color", (255, 160, 40)), p.get("density", 0.25)),
    "gradient_map": lambda rgb, p: gradient_map(rgb, p.get("shadow", (20, 24, 60)), p.get("highlight", (255, 220, 160))),
}


def apply_adjustment(rgb: np.ndarray, kind: str, params: dict) -> np.ndarray:
    fn = APPLY.get(kind)
    if fn is None:
        return rgb
    try:
        out = fn(rgb, params or {})
        return np.clip(out, 0.0, 1.0).astype(np.float32)
    except Exception:
        return rgb
