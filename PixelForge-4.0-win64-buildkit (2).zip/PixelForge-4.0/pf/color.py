"""L0 — pixel blend math (mirror of photocraft-color's blend modes).

Clean-room implementations from public specifications only:
  * W3C Compositing and Blending Level 1 (also ISO 32000 PDF separable modes)
  * Photoshop-compatible non-separable modes (hue/saturation/color/luminosity)

All functions operate on float32 RGB(A) arrays in [0, 1], straight alpha.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------- constants
NORMAL = "normal"
MULTIPLY = "multiply"
SCREEN = "screen"
OVERLAY = "overlay"
DARKEN = "darken"
LIGHTEN = "lighten"
COLOR_DODGE = "color dodge"
COLOR_BURN = "color burn"
LINEAR_BURN = "linear burn"
HARD_LIGHT = "hard light"
SOFT_LIGHT = "soft light"
VIVID_LIGHT = "vivid light"
LINEAR_LIGHT = "linear light"
PIN_LIGHT = "pin light"
DIFFERENCE = "difference"
EXCLUSION = "exclusion"
SUBTRACT = "subtract"
DIVIDE = "divide"
HUE = "hue"
SATURATION = "saturation"
COLOR = "color"
LUMINOSITY = "luminosity"
PASSTHROUGH = "pass through"  # groups only

BLEND_MODES = [
    NORMAL, MULTIPLY, SCREEN, OVERLAY, DARKEN, LIGHTEN, COLOR_DODGE, COLOR_BURN,
    LINEAR_BURN, HARD_LIGHT, SOFT_LIGHT, VIVID_LIGHT, LINEAR_LIGHT, PIN_LIGHT,
    DIFFERENCE, EXCLUSION, SUBTRACT, DIVIDE, HUE, SATURATION, COLOR, LUMINOSITY,
]

# Photoshop PSD blend-mode keys <-> ours
PSD_TO_OURS = {
    "norm": NORMAL, "mul ": MULTIPLY, "scrn": SCREEN, "over": OVERLAY,
    "dark": DARKEN, "lite": LIGHTEN, "div ": COLOR_DODGE, "idiv": COLOR_BURN,
    "lbrn": LINEAR_BURN, "hLit": HARD_LIGHT, "sLit": SOFT_LIGHT, "vLit": VIVID_LIGHT,
    "lLit": LINEAR_LIGHT, "pLit": PIN_LIGHT, "diff": DIFFERENCE, "smud": EXCLUSION,
    "fsub": SUBTRACT, "fdiv": DIVIDE, "hue ": HUE, "sat ": SATURATION,
    "colr": COLOR, "lum ": LUMINOSITY, "pass": PASSTHROUGH,
}
OURS_TO_PSD = {v: k for k, v in PSD_TO_OURS.items()}


# ------------------------------------------------------------- separable B()
def _multiply(s, d):
    return s * d


def _screen(s, d):
    return s + d - s * d


def _overlay(s, d):
    return _hard_light(d, s)  # Overlay(Cb,Cs) == HardLight(Cs,Cb)


def _darken(s, d):
    return np.minimum(s, d)


def _lighten(s, d):
    return np.maximum(s, d)


def _color_dodge(s, d):
    out = np.where(d <= 0.0, 0.0, np.where(s >= 1.0, 1.0, np.minimum(1.0, d / np.maximum(1.0 - s, 1e-6))))
    return out.astype(np.float32)


def _color_burn(s, d):
    out = np.where(d >= 1.0, 1.0, np.where(s <= 0.0, 0.0, 1.0 - np.minimum(1.0, (1.0 - d) / np.maximum(s, 1e-6))))
    return out.astype(np.float32)


def _linear_burn(s, d):
    return np.clip(s + d - 1.0, 0.0, 1.0)


def _hard_light(s, d):
    lo = 2.0 * s * d
    hi = _screen(2.0 * s - 1.0, d)
    return np.where(s <= 0.5, lo, hi).astype(np.float32)


def _soft_light(s, d):
    def _d(x):
        return np.where(x <= 0.25, ((16.0 * x - 12.0) * x + 4.0) * x, np.sqrt(np.clip(x, 0.0, 1.0)))
    lo = d - (1.0 - 2.0 * s) * d * (1.0 - d)
    hi = d + (2.0 * s - 1.0) * (_d(d) - d)
    return np.where(s <= 0.5, lo, hi).astype(np.float32)


def _vivid_light(s, d):
    """s <= .5 burns the backdrop, s > .5 dodges it (public W3C-style formula)."""
    burn_amt = 1.0 - 2.0 * s
    dodge_amt = 2.0 * s - 1.0
    burn = np.where(d >= 1.0, 1.0, np.where(burn_amt <= 0.0, 0.0,
                    1.0 - np.minimum(1.0, (1.0 - d) / np.maximum(burn_amt, 1e-6))))
    dodge = np.where(d <= 0.0, 0.0, np.where(dodge_amt >= 1.0, 1.0,
                     np.minimum(1.0, d / np.maximum(1.0 - dodge_amt, 1e-6))))
    return np.where(s <= 0.5, burn, dodge).astype(np.float32)


def _linear_light(s, d):
    return np.clip(d + 2.0 * s - 1.0, 0.0, 1.0)


def _pin_light(s, d):
    lo = np.minimum(d, 2.0 * s)
    hi = np.maximum(d, 2.0 * s - 1.0)
    return np.where(s <= 0.5, lo, hi).astype(np.float32)


def _difference(s, d):
    return np.abs(d - s)


def _exclusion(s, d):
    return d + s - 2.0 * d * s


def _subtract(s, d):
    return np.clip(d - s, 0.0, 1.0)


def _divide(s, d):
    return np.where(s <= 0.0, 1.0, np.minimum(1.0, d / np.maximum(s, 1e-6))).astype(np.float32)


# --------------------------------------------------------- non-separable
def _lum(c):
    return 0.3 * c[..., 0] + 0.59 * c[..., 1] + 0.11 * c[..., 2]


def _clip_color(c):
    """W3C ClipColor: push channels back into gamut around their luminance."""
    l = _lum(c)[..., None]
    out = c.copy()
    n = out.min(axis=-1, keepdims=True)
    denom = np.where(l - n == 0.0, 1.0, l - n)
    out = np.where(n < 0.0, l + (out - l) * l / np.where(n < 0.0, denom, 1.0), out)
    x = out.max(axis=-1, keepdims=True)
    l2 = _lum(out)[..., None]
    denom = np.where(x - l2 == 0.0, 1.0, x - l2)
    out = np.where(x > 1.0, l2 + (out - l2) * (1.0 - l2) / np.where(x > 1.0, denom, 1.0), out)
    return out


def _set_lum(c, l):
    d = l - _lum(c)
    out = c + d[..., None]
    return _clip_color(out)


def _sat(c):
    return c.max(axis=-1) - c.min(axis=-1)


def _set_sat(c, s):
    """W3C SetSat: assign min/mid/max channels from s."""
    order = np.argsort(c, axis=-1)  # ascending channel indices
    out = np.empty_like(c)
    i_min = order[..., 0]
    i_max = order[..., 2]
    i_mid = order[..., 1]
    rows = np.arange(c.shape[0])[:, None]
    cols = np.arange(c.shape[1])[None, :]
    out[rows, cols, i_min] = 0.0
    # mid: (c_mid - c_min) * s / (c_max - c_min)
    c_min = np.take_along_axis(c, i_min[..., None], -1)[..., 0]
    c_mid = np.take_along_axis(c, i_mid[..., None], -1)[..., 0]
    c_max = np.take_along_axis(c, i_max[..., None], -1)[..., 0]
    denom = np.maximum(c_max - c_min, 1e-6)
    out[rows, cols, i_mid] = (c_mid - c_min) * s / denom
    out[rows, cols, i_max] = s
    return out


def _hue(s, d):
    return _set_lum(_set_sat(s, _sat(d)), _lum(d))


def _saturation(s, d):
    return _set_lum(_set_sat(d, _sat(s)), _lum(d))


def _color(s, d):
    return _set_lum(s, _lum(d))


def _luminosity(s, d):
    return _set_lum(d, _lum(s))


BLEND_FUNCS = {
    NORMAL: None,  # handled directly
    MULTIPLY: _multiply, SCREEN: _screen, OVERLAY: _overlay, DARKEN: _darken,
    LIGHTEN: _lighten, COLOR_DODGE: _color_dodge, COLOR_BURN: _color_burn,
    LINEAR_BURN: _linear_burn, HARD_LIGHT: _hard_light, SOFT_LIGHT: _soft_light,
    VIVID_LIGHT: _vivid_light, LINEAR_LIGHT: _linear_light, PIN_LIGHT: _pin_light,
    DIFFERENCE: _difference, EXCLUSION: _exclusion, SUBTRACT: _subtract,
    DIVIDE: _divide, HUE: _hue, SATURATION: _saturation, COLOR: _color,
    LUMINOSITY: _luminosity,
}

SEPARABLE = {m for m in BLEND_FUNCS if m not in (None, NORMAL, HUE, SATURATION, COLOR, LUMINOSITY, PASSTHROUGH)}


# ------------------------------------------------------------ core operator
def blend_rgb(mode: str, src: np.ndarray, dst: np.ndarray) -> np.ndarray:
    """B(Cb, Cs) for equally-shaped HxWx3 float arrays. Unknown mode -> normal."""
    fn = BLEND_FUNCS.get(mode)
    if fn is None:
        return src
    try:
        return np.clip(fn(src, dst), 0.0, 1.0).astype(np.float32)
    except Exception:
        return src


def over(dst: np.ndarray, src: np.ndarray, mode: str = NORMAL, opacity: float = 1.0) -> np.ndarray:
    """Porter-Duff source-over with blend function and opacity.

    dst, src: HxWx4 float32 straight alpha in [0,1]. Returns HxWx4 float32.
    Follows the W3C compositing formula:
        co = as*(1-ab)*Cs + as*ab*B(Cb,Cs) + (1-as)*ab*Cb ;  ao = as + ab*(1-as)
    """
    opacity = float(np.clip(opacity, 0.0, 1.0))
    as_ = src[..., 3:4] * opacity
    ab = dst[..., 3:4]
    src_rgb = src[..., :3]
    dst_rgb = dst[..., :3]

    if mode == NORMAL:
        blended = src_rgb
    elif mode in SEPARABLE or mode in (HUE, SATURATION, COLOR, LUMINOSITY):
        blended = blend_rgb(mode, src_rgb, dst_rgb)
    else:  # unknown / passthrough
        blended = src_rgb

    co = as_ * (1.0 - ab) * src_rgb + as_ * ab * blended + (1.0 - as_) * ab * dst_rgb
    ao = as_ + ab * (1.0 - as_)
    out_rgb = np.where(ao > 1e-6, co / np.maximum(ao, 1e-6), 0.0)
    return np.concatenate([out_rgb, ao], axis=-1).astype(np.float32)
