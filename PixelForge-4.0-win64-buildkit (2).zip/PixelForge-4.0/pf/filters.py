"""L2 — filter library (mirror of their algo filters, working on RGBA uint8).

Every function: f(pixels: HxWx4 uint8, **params) -> HxWx4 uint8 (new array).
Selection-restricted application is handled by the engine.
"""

from __future__ import annotations

import numpy as np
from scipy import ndimage

try:
    import cv2
except Exception:            # cv2 optional
    cv2 = None


def _f32(px):
    return px.astype(np.float32) / 255.0


def _u8(x):
    return np.clip(x * 255.0 + 0.5, 0, 255).astype(np.uint8)


def gaussian_blur(px, radius=4.0):
    a = px[..., 3:4].astype(np.float32) / 255.0
    rgb = px[..., :3].astype(np.float32)
    w = ndimage.gaussian_filter(a, (radius, radius, 0))
    b = np.stack([ndimage.gaussian_filter(rgb[..., i] * a[..., 0], (radius, radius)) for i in range(3)], -1)
    out = np.where(w > 1e-4, b / np.maximum(w, 1e-4), rgb)
    return np.concatenate([np.clip(out, 0, 255).astype(np.uint8),
                           np.clip(w * 255 + 0.5, 0, 255).astype(np.uint8)], -1)


def motion_blur(px, angle=0.0, length=15):
    n = max(1, int(length))
    k = np.zeros((n, n), np.float32)
    rad = np.deg2rad(angle)
    c, s = int(n // 2), int(n // 2)
    for i in range(n):
        x = c + int(round((i - c) * np.cos(rad)))
        y = s + int(round((i - s) * np.sin(rad)))
        k[np.clip(y, 0, n - 1), np.clip(x, 0, n - 1)] = 1.0
    k /= k.sum()
    out = np.stack([ndimage.convolve(px[..., i], k, mode="reflect") for i in range(4)], -1)
    return out.astype(np.uint8)


def zoom_blur(px, amount=0.3, steps=12):
    out = _f32(px)
    h, w = px.shape[:2]
    base = _f32(px)
    for i in range(1, max(2, steps)):
        s = 1.0 + amount * i / steps
        img = Image_scale(base, s)
        oy, ox = (img.shape[0] - h) // 2, (img.shape[1] - w) // 2
        out += img[oy:oy + h, ox:ox + w]
    return _u8(out / max(2, steps))


def Image_scale(arr_f32, s):
    from PIL import Image
    h, w = arr_f32.shape[:2]
    img = Image.fromarray(_u8(arr_f32))
    img = img.resize((max(2, int(w * s)), max(2, int(h * s))), Image.BILINEAR)
    return np.asarray(img, np.float32) / 255.0


def radial_blur(px, amount=6, steps=8):
    out = _f32(px) * 0
    base = _f32(px)
    h, w = px.shape[:2]
    cy, cx = h / 2, w / 2
    ang = np.deg2rad(max(0.01, amount))
    for i in range(max(2, steps)):
        t = ang * i / steps
        # rotate about center
        ys, xs = np.mgrid[0:h, 0:w]
        dx, dy = xs - cx, ys - cy
        xr = cx + dx * np.cos(t) - dy * np.sin(t)
        yr = cy + dx * np.sin(t) + dy * np.cos(t)
        out += np.stack([ndimage.map_coordinates(base[..., c], [yr, xr], order=1, mode="reflect") for c in range(4)], -1)
    return _u8(out / max(2, steps))


def unsharp_mask(px, radius=2.0, amount=0.8, threshold=2):
    rgb = px[..., :3].astype(np.float32)
    blurred = np.stack([ndimage.gaussian_filter(rgb[..., i], radius) for i in range(3)], -1)
    diff = rgb - blurred
    mask = np.abs(diff) > max(0, threshold)
    out = rgb + diff * amount * mask
    return np.concatenate([np.clip(out, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def high_pass(px, radius=4.0):
    rgb = px[..., :3].astype(np.float32)
    blurred = np.stack([ndimage.gaussian_filter(rgb[..., i], radius) for i in range(3)], -1)
    out = rgb - blurred + 128
    return np.concatenate([np.clip(out, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def sharpen(px, strength=1.0):
    return unsharp_mask(px, radius=1.2, amount=0.6 * float(strength), threshold=1)


def add_noise(px, amount=0.15, mono=True):
    n = np.random.rand(*px.shape[:2]).astype(np.float32) - 0.5
    if mono:
        noise = n[..., None] * 255 * float(amount)
        out = px.astype(np.float32) + noise
    else:
        noise = (np.random.rand(*px.shape) - 0.5) * 255 * float(amount)
        out = px.astype(np.float32) + noise
    return np.clip(out, 0, 255).astype(np.uint8)


def median(px, size=3):
    k = max(1, int(size)) | 1
    out = np.stack([ndimage.median_filter(px[..., i], k) for i in range(4)], -1)
    return out.astype(np.uint8)


def reduce_noise(px, strength=0.6):
    if cv2 is None:
        return median(px, 3)
    d = int(np.clip(strength * 12, 1, 12))
    out = cv2.bilateralFilter(px[..., :3], d, d * 8, d * 3)
    return np.concatenate([out, px[..., 3:4]], -1)


def mosaic(px, size=10):
    s = max(2, int(size))
    h, w = px.shape[:2]
    small = px[:h // s * s, :w // s * s].reshape(h // s, s, w // s, s, -1).mean(axis=(1, 3))
    out = np.repeat(np.repeat(small, s, 0), s, 1).astype(np.uint8)
    full = np.empty_like(px)
    full[:out.shape[0], :out.shape[1]] = out
    if out.shape[0] < h: full[out.shape[0]:, :out.shape[1]] = out[-1:]
    if out.shape[1] < w: full[:, out.shape[1]:] = full[:, out.shape[1] - 1:out.shape[1]]
    return full


def crystallize(px, size=12):
    if cv2 is None:
        return mosaic(px, size)
    s = max(3, int(size))
    h, w = px.shape[:2]
    small = cv2.resize(px, (max(1, w // s), max(1, h // s)), interpolation=cv2.INTER_LINEAR)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)


def _remap(px, map_x, map_y):
    out = np.empty_like(px)
    for c in range(4):
        out[..., c] = ndimage.map_coordinates(px[..., c], [map_y, map_x], order=1, mode="reflect")
    return out


def twirl(px, angle=90.0, radius_frac=0.75):
    h, w = px.shape[:2]
    cy, cx = h / 2, w / 2
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    dx, dy = xs - cx, ys - cy
    r = np.sqrt(dx * dx + dy * dy)
    rmax = radius_frac * min(w, h) / 2
    t = np.deg2rad(angle) * np.clip(1 - r / max(rmax, 1), 0, 1) ** 2
    ca, sa = np.cos(t), np.sin(t)
    map_x = cx + dx * ca - dy * sa
    map_y = cy + dx * sa + dy * ca
    return _remap(px, map_x, map_y)


def wave(px, amplitude=8.0, wavelength=60.0):
    h, w = px.shape[:2]
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    map_x = xs + amplitude * np.sin(2 * np.pi * ys / max(4, wavelength))
    map_y = ys + amplitude * np.sin(2 * np.pi * xs / max(4, wavelength))
    return _remap(px, map_x, map_y)


def _pinch_map(px, amount=0.5):
    h, w = px.shape[:2]
    cy, cx = h / 2, w / 2
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    dx, dy = (xs - cx) / max(cx, 1), (ys - cy) / max(cy, 1)
    r = np.sqrt(dx * dx + dy * dy)
    r = np.clip(r, 0, 1)
    k = np.where(r > 0, r ** (1 + amount * 1.5), 0) / np.maximum(r, 1e-6)
    return cx + dx * k * cx, cy + dy * k * cy


def pinch(px, amount=0.5):
    map_x, map_y = _pinch_map(px, amount)
    return _remap(px, map_x, map_y)


def spherize(px, amount=0.6):
    return pinch(px, -abs(amount))   # negative pinch bulges outward


def emboss(px, strength=1.0):
    k = np.array([[-2, -1, 0], [-1, 1, 1], [0, 1, 2]], np.float32) * float(strength)
    rgb = np.stack([ndimage.convolve(px[..., i].astype(np.float32), k, mode="reflect") for i in range(3)], -1) + 128
    return np.concatenate([np.clip(rgb, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def find_edges(px):
    gx = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], np.float32)
    gy = gx.T
    rgb = px[..., :3].astype(np.float32)
    e = np.zeros_like(rgb)
    for i in range(3):
        e[..., i] = np.hypot(ndimage.convolve(rgb[..., i], gx, mode="reflect"),
                             ndimage.convolve(rgb[..., i], gy, mode="reflect"))
    return np.concatenate([np.clip(255 - e + 40, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def oil_paint(px, radius=5, levels=24):
    if cv2 is not None:
        for _ in range(2):
            px3 = cv2.bilateralFilter(px[..., :3], max(3, int(radius) | 1), 60, 20)
        q = (px3.astype(np.float32) / 255 * max(2, levels)).astype(np.uint8) * (255 // max(2, levels))
        return np.concatenate([q, px[..., 3:4]], -1)
    out = median(px, 5)
    return out


def pencil_sketch(px):
    if cv2 is not None:
        gray, _ = cv2.pencilSketch(px[..., :3], sigma_s=60, sigma_r=0.07, shade_factor=0.02)
        if gray.ndim == 2:
            gray = np.stack([gray] * 3, -1)
        return np.concatenate([gray, px[..., 3:4]], -1)
    rgb = px[..., :3]
    l = (0.3 * rgb[..., 0] + 0.59 * rgb[..., 1] + 0.11 * rgb[..., 2]).astype(np.uint8)
    inv = 255 - ndimage.median_filter(l, 5)
    return np.stack([l, l, l], -1) * inv[..., None] // 255


def clouds(px=None, width=512, height=512, scale=4.0, color_a=(72, 110, 220), color_b=(250, 250, 245)):
    """Render fractal noise -> RGBA (ignores input pixels)."""
    rng = np.random.default_rng(7)
    h, w = int(height), int(width)
    acc = np.zeros((h, w), np.float32)
    amp, total = 1.0, 0.0
    size0 = max(2, int(scale))
    for oct_ in range(5):
        small = rng.random((max(2, h // (size0 * (2 ** oct_))), max(2, w // (size0 * (2 ** oct_))))).astype(np.float32)
        acc += ndimage.zoom(small, (h / small.shape[0], w / small.shape[1]), order=3)[:h, :w] * amp
        total += amp
        amp *= 0.5
    t = np.clip(acc / total, 0, 1)[..., None]
    a = np.array(color_a, np.float32)
    b = np.array(color_b, np.float32)
    rgb = a * (1 - t) + b * t
    return np.concatenate([np.clip(rgb, 0, 255).astype(np.uint8), np.full((h, w, 1), 255, np.uint8)], -1)


def difference_clouds(px, scale=4.0):
    c = clouds(width=px.shape[1], height=px.shape[0], scale=scale)
    return np.abs(px.astype(np.int16) - c.astype(np.int16)).astype(np.uint8)


def lens_flare(px, x=None, y=None, strength=1.0):
    h, w = px.shape[:2]
    cx = w * 0.7 if x is None else float(x)
    cy = h * 0.3 if y is None else float(y)
    ys, xs = np.mgrid[0:h, 0:w]
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
    glow = np.exp(-(d / (min(w, h) * 0.18)) ** 2) * float(strength)
    rays = np.clip(1 - (d % 24) / 24, 0, 1) ** 3 * np.exp(-(d / (min(w, h) * 0.5)) ** 2) * 0.5 * float(strength)
    add = np.clip((glow + rays), 0, 1)[..., None]
    warm = np.array([1.0, 0.92, 0.75], np.float32)
    out = np.clip(px[..., :3].astype(np.float32) + add * 255 * warm * 0.9, 0, 255)
    return np.concatenate([out.astype(np.uint8), px[..., 3:4]], -1)


def vignette(px, amount=0.5, radius=0.75):
    h, w = px.shape[:2]
    ys, xs = np.mgrid[0:h, 0:w]
    d = np.sqrt(((xs - w / 2) / (w / 2)) ** 2 + ((ys - h / 2) / (h / 2)) ** 2)
    mask = 1 - np.clip((d - radius) / max(0.1, 1 - radius), 0, 1) * float(amount)
    out = px.astype(np.float32)
    out[..., :3] *= mask[..., None]
    return np.clip(out, 0, 255).astype(np.uint8)


def gradient_map(px, shadow=(30, 20, 80), highlight=(255, 225, 170)):
    rgb = px[..., :3].astype(np.float32) / 255.0
    l = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    a = np.array(shadow, np.float32)
    b = np.array(highlight, np.float32)
    out = a * (1 - l[..., None]) + b * l[..., None]
    return np.concatenate([np.clip(out, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def duotone(px, shadow=(28, 32, 90), highlight=(255, 200, 120)):
    return gradient_map(px, shadow, highlight)


def auto_tone(px, bleed=0.1):
    out = px.astype(np.float32)
    for c in range(3):
        ch = px[..., c].astype(np.float32)
        lo, hi = np.percentile(ch, bleed), np.percentile(ch, 100 - bleed)
        if hi - lo > 1:
            out[..., c] = (ch - lo) * 255.0 / (hi - lo)
    return np.clip(out, 0, 255).astype(np.uint8)


def auto_contrast(px, bleed=0.1):
    l = 0.3 * px[..., 0] + 0.59 * px[..., 1] + 0.11 * px[..., 2]
    lo, hi = np.percentile(l, bleed), np.percentile(l, 100 - bleed)
    if hi - lo <= 1:
        return px.copy()
    lut = np.clip((np.arange(256) - lo) * 255.0 / (hi - lo), 0, 255).astype(np.uint8)
    out = px.copy()
    out[..., :3] = lut[px[..., :3]]
    return out


def auto_enhance(px):
    out = auto_contrast(px, 0.5)
    from . import adjust as ADJ
    rgb = out[..., :3].astype(np.float32) / 255.0
    rgb = ADJ.vibrance(rgb, 0.25)
    out[..., :3] = np.clip(rgb * 255 + 0.5, 0, 255).astype(np.uint8)
    return unsharp_mask(out, radius=1.6, amount=0.5, threshold=3)


def warm(px, strength=0.4):
    from . import adjust as ADJ
    rgb = px[..., :3].astype(np.float32) / 255.0
    rgb = ADJ.temperature(rgb, strength, 0)
    return np.concatenate([np.clip(rgb * 255 + 0.5, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def cool(px, strength=0.4):
    return warm(px, -strength)


def sepia(px):
    rgb = px[..., :3].astype(np.float32)
    l = 0.393 * rgb[..., 0] + 0.769 * rgb[..., 1] + 0.189 * rgb[..., 2]
    m = 0.349 * rgb[..., 0] + 0.686 * rgb[..., 1] + 0.168 * rgb[..., 2]
    d = 0.272 * rgb[..., 0] + 0.534 * rgb[..., 1] + 0.131 * rgb[..., 2]
    out = np.stack([l, m, d], -1)
    return np.concatenate([np.clip(out, 0, 255).astype(np.uint8), px[..., 3:4]], -1)


def lensFlare_fn(px, x=None, y=None, strength=1.0):
    return lens_flare(px, x, y, strength)


# registry: id -> (fn, defaults, label, category)

# ---------------------------------------------- 2026: Blur Gallery & friends
def _depth_mask(shape, kind, **kw):
    """0 = fully sharp center, 1 = fully blurred, for the Blur Gallery."""
    h, w = shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = w * kw.get("cx", 0.5), h * kw.get("cy", 0.5)
    if kind == "iris":
        rx, ry = w * kw.get("rx", 0.32), h * kw.get("ry", 0.32)
        d = np.sqrt(((xx - cx) / max(rx, 1)) ** 2 + ((yy - cy) / max(ry, 1)) ** 2)
        return np.clip((d - 0.75) / 0.75, 0, 1)
    if kind == "tilt":
        angle = np.radians(kw.get("angle", 0.0))
        u = (xx - cx) * np.cos(angle) + (yy - cy) * np.sin(angle)
        band = min(w, h) * kw.get("band", 0.14)
        return np.clip((np.abs(u) - band) / (band * 2.2), 0, 1)
    return np.ones((h, w), np.float32) * kw.get("amount", 1.0)


def blur_gallery(px, kind="iris", radius=14, **kw):
    if cv2 is None:
        from scipy import ndimage
        blurred = np.stack([ndimage.gaussian_filter(px[..., i], radius) for i in range(4)], -1)
    else:
        blurred = cv2.GaussianBlur(px, (0, 0), radius)
    blurred[..., 3] = px[..., 3]
    m = _depth_mask(px.shape, kind, **kw)[..., None]
    return (px * (1 - m) + blurred * m).astype(np.uint8)


def iris_blur(px, radius=16, cx=0.5, cy=0.5, rx=0.32, ry=0.32):
    return blur_gallery(px, "iris", radius, cx=cx, cy=cy, rx=rx, ry=ry)


def tilt_shift(px, radius=12, cx=0.5, cy=0.5, band=0.14, angle=0.0):
    return blur_gallery(px, "tilt", radius, cx=cx, cy=cy, band=band, angle=angle)


def field_blur(px, radius=10):
    return blur_gallery(px, "field", radius, amount=1.0)


def color_halftone(px, size=8, angle=15):
    """CMYK-style dot screen (Color Halftone)."""
    s = max(3, int(size))
    f32 = px.astype(np.float32) / 255.0
    out = np.zeros_like(f32)
    h, w = px.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    offs = [(0, 15.0), (1, 75.0), (2, 0.0)]
    for ch, deg in offs:
        ang = np.radians(deg)
        u = xx * np.cos(ang) + yy * np.sin(ang)
        v = -xx * np.sin(ang) + yy * np.cos(ang)
        phase = (np.sqrt((u % s - s / 2) ** 2 + (v % s - s / 2) ** 2) / (s * 0.62))
        cov = np.clip(1.0 - phase + (f32[..., ch] - 0.5) * 1.4, 0, 1)
        out[..., ch] = np.clip(cov, 0, 1)
    out[..., 3] = f32[..., 3]
    return _u8(out)


def dust_and_scratches(px, radius=2, threshold=12):
    """Median the small bright/dark defects only (Dust & Scratches)."""
    med = (cv2.medianBlur(px, 2 * int(radius) + 1) if cv2 is not None
           else np.stack([ndimage.median_filter(px[..., i], 2 * int(radius) + 1) for i in range(4)], -1))
    diff = np.abs(px.astype(np.int16) - med.astype(np.int16)).max(-1)
    m = (diff > float(threshold))[..., None]
    return np.where(m, med, px).astype(np.uint8)


def smart_sharpen(px, amount=0.8, radius=2.0, halo_guard=True):
    """Edge-preserving sharpen (Smart Sharpen): unsharp masked by local contrast."""
    f = px.astype(np.float32)
    if cv2 is not None:
        base = cv2.GaussianBlur(px, (0, 0), radius).astype(np.float32)
        noise = cv2.medianBlur(px, 3).astype(np.float32)
    else:
        base = np.stack([ndimage.gaussian_filter(f[..., i], radius) for i in range(4)], -1)
        noise = np.stack([ndimage.median_filter(px[..., i], 3) for i in range(4)], -1).astype(np.float32)
    detail = f - base
    if halo_guard:
        keep = np.abs(detail) > np.abs(noise - base) * 0.6
        detail = detail * keep
    out = f + detail * float(np.clip(amount, 0, 3))
    return _u8(out / 255.0)


def soft_portrait(px, amount=0.65, radius=6):
    """Skin-smooth: bilateral edge-preserving blur blended on low-detail areas."""
    if cv2 is None:
        return px
    a = float(np.clip(amount, 0, 1))
    smooth3 = cv2.bilateralFilter(px[..., :3], 9, 60, radius * 3)
    smooth = px.copy()
    smooth[..., :3] = smooth3
    f = px.astype(np.float32)
    s = smooth.astype(np.float32)
    # where the image is smooth-ish, take the bilateral result (skin); keep edges
    detail = np.abs(f[..., :3] - s[..., :3]).mean(-1)
    m = np.clip(1.0 - detail / 0.09, 0, 1)[..., None] * a
    out = f * (1 - m) + s * m
    out[..., 3] = f[..., 3]
    return np.clip(out + 0.5, 0, 255).astype(np.uint8)


def bokeh_background(px, radius=12, subject=None):
    """Blur everything except the subject mask (GrabCut-based when available)."""
    import cv2
    h, w = px.shape[:2]
    if subject is None:
        small = cv2.resize(px, (320, max(1, int(320 * h / w))), interpolation=cv2.INTER_AREA)
        m = np.zeros(small.shape[:2], np.uint8)
        m[:] = cv2.GC_PR_BGD
        pad = max(2, int(min(small.shape[:2]) * 0.06))
        m[pad:-pad, pad:-pad] = cv2.GC_PR_FGD
        try:
            bgd = np.zeros((1, 65), np.float64); fgd = np.zeros((1, 65), np.float64)
            cv2.grabCut(small[..., :3], m, None, bgd, fgd, 3, cv2.GC_INIT_WITH_MASK)
            mask = np.isin(m, [cv2.GC_FGD, cv2.GC_PR_FGD]).astype(np.uint8) * 255
            mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_LINEAR)
        except cv2.error:
            mask = np.zeros((h, w), np.uint8)
    else:
        mask = subject
    blurred = cv2.GaussianBlur(px, (0, 0), float(radius))
    blurred[..., 3] = px[..., 3]
    keep = (cv2.GaussianBlur(mask, (0, 0), 4).astype(np.float32) / 255.0)[..., None]
    out = (px.astype(np.float32) * keep + blurred.astype(np.float32) * (1 - keep))
    return np.clip(out + 0.5, 0, 255).astype(np.uint8)


# --------------------------------------------- 2026: Color Lookup preset packs
def _curve_look(px, lift=(0, 0, 0), gain=(1, 1, 1), gamma=(1, 1, 1), sat=1.0,
                split_shadow=None, split_high=None, balance=0.5):
    f = _f32(px)
    rgb = f[..., :3]
    for c in range(3):
        rgb[..., c] = rgb[..., c] * gain[c]
        rgb[..., c] = np.power(np.clip(rgb[..., c], 0, 1), 1.0 / gamma[c])
        rgb[..., c] = rgb[..., c] * (1 - lift[c] * (1 - rgb[..., c])) + lift[c] * (1 - rgb[..., c])
    lum = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
    if split_shadow is not None:
        m = (1 - lum[..., None]) * balance
        rgb = rgb + np.array(split_shadow, np.float32) * m * 0.5
    if split_high is not None:
        m = lum[..., None] * balance
        rgb = rgb + np.array(split_high, np.float32) * m * 0.5
    gray = np.repeat(lum[..., None], 3, -1)
    rgb = gray + (rgb - gray) * sat
    out = f.copy()
    out[..., :3] = np.clip(rgb, 0, 1)
    return _u8(out)


def look_vivid(px, **kw):
    return _curve_look(px, gain=(1.06, 1.03, 1.02), sat=1.35, balance=0.4,
                       split_shadow=(0, 0.01, 0.03), split_high=(0.0, 0.0, 0.0))


def look_teal_orange(px, **kw):
    return _curve_look(px, gain=(1.05, 1.0, 0.96), sat=1.18, balance=0.5,
                       split_shadow=(0.0, 0.03, 0.07), split_high=(0.05, 0.025, 0.0))


def look_warm_cinema(px, **kw):
    return _curve_look(px, gain=(1.07, 1.0, 0.92), gamma=(1.02, 1.0, 0.98),
                       sat=1.05, balance=0.45, split_shadow=(0.02, 0.02, 0.05))


def look_noir(px, **kw):
    return _curve_look(px, gain=(1.0, 1.0, 1.0), sat=0.0, balance=0.5,
                       split_shadow=(0.0, 0.0, 0.02), split_high=(0.03, 0.03, 0.03))


def look_fade(px, **kw):
    out = _curve_look(px, sat=0.82, balance=0.35, split_shadow=(0.03, 0.03, 0.04))
    f = out.astype(np.float32)
    f[..., :3] = f[..., :3] * 0.86 + 36.0
    out[..., :3] = np.clip(f[..., :3], 0, 255).astype(np.uint8)
    return out


def look_vintage(px, **kw):
    return _curve_look(px, gain=(1.05, 0.99, 0.9), gamma=(1.05, 1.0, 0.95),
                       sat=0.85, balance=0.55, split_shadow=(0.05, 0.02, 0.02),
                       split_high=(0.05, 0.04, 0.0))


def look_cyberpunk(px, **kw):
    return _curve_look(px, gain=(0.97, 0.99, 1.1), sat=1.45, balance=0.55,
                       split_shadow=(0.03, 0.0, 0.09), split_high=(0.0, 0.02, 0.06))


def look_bleach(px, **kw):
    out = _curve_look(px, gain=(1.1, 1.1, 1.1), sat=0.55, balance=0.4)
    f = out.astype(np.float32)
    f[..., :3] = 255.0 - (255.0 - f[..., :3]) * 0.88
    out[..., :3] = np.clip(f[..., :3], 0, 255).astype(np.uint8)
    return out


def look_landscape(px, **kw):
    return _curve_look(px, gain=(1.02, 1.05, 1.02), sat=1.28, balance=0.45,
                       split_shadow=(0.0, 0.01, 0.04), split_high=(0.0, 0.01, 0.0))


REGISTRY = {
    "gaussianBlur": (gaussian_blur, {"radius": 4.0}, "Gaussian Blur…", "Blur"),
    "motionBlur": (motion_blur, {"angle": 0, "length": 18}, "Motion Blur…", "Blur"),
    "zoomBlur": (zoom_blur, {"amount": 0.25}, "Zoom Blur…", "Blur"),
    "radialBlur": (radial_blur, {"amount": 4}, "Radial Blur…", "Blur"),
    "unsharpMask": (unsharp_mask, {"radius": 2.0, "amount": 0.8, "threshold": 2}, "Unsharp Mask…", "Sharpen"),
    "sharpen": (sharpen, {"strength": 1.0}, "Sharpen", "Sharpen"),
    "highPass": (high_pass, {"radius": 4.0}, "High Pass…", "Other"),
    "addNoise": (add_noise, {"amount": 0.15, "mono": True}, "Add Noise…", "Noise"),
    "median": (median, {"size": 3}, "Median…", "Noise"),
    "reduceNoise": (reduce_noise, {"strength": 0.6}, "Reduce Noise…", "Noise"),
    "mosaic": (mosaic, {"size": 12}, "Mosaic…", "Pixelate"),
    "crystallize": (crystallize, {"size": 14}, "Crystallize…", "Pixelate"),
    "twirl": (twirl, {"angle": 120}, "Twirl…", "Distort"),
    "wave": (wave, {"amplitude": 8, "wavelength": 70}, "Wave…", "Distort"),
    "pinch": (pinch, {"amount": 0.5}, "Pinch…", "Distort"),
    "spherize": (spherize, {"amount": 0.6}, "Spherize…", "Distort"),
    "emboss": (emboss, {"strength": 1.0}, "Emboss", "Stylize"),
    "findEdges": (find_edges, {}, "Find Edges", "Stylize"),
    "oilPaint": (oil_paint, {"radius": 5, "levels": 24}, "Oil Paint…", "Stylize"),
    "pencilSketch": (pencil_sketch, {}, "Pencil Sketch", "Stylize"),
    "differenceClouds": (difference_clouds, {"scale": 4.0}, "Difference Clouds", "Render"),
    "lensFlare": (lensFlare_fn, {"x": None, "y": None, "strength": 1.0}, "Lens Flare…", "Render"),
    "vignette": (vignette, {"amount": 0.5, "radius": 0.75}, "Vignette…", "Render"),
    "gradientMap": (gradient_map, {"shadow": (30, 20, 80), "highlight": (255, 225, 170)}, "Gradient Map…", "Adjust"),
    "duotone": (duotone, {"shadow": (28, 32, 90), "highlight": (255, 200, 120)}, "Duotone…", "Adjust"),
    "autoTone": (auto_tone, {"bleed": 0.1}, "Auto Tone", "Adjust"),
    "autoContrast": (auto_contrast, {"bleed": 0.5}, "Auto Contrast", "Adjust"),
    "autoEnhance": (auto_enhance, {}, "Auto Enhance (Canva)", "Adjust"),
    "warm": (warm, {"strength": 0.4}, "Warm", "Adjust"),
    "cool": (cool, {"strength": 0.4}, "Cool", "Adjust"),
    "sepia": (sepia, {}, "Sepia", "Adjust"),
    # --- Blur Gallery (catalog: filter.blurGallery.*) ---
    "irisBlur": (iris_blur, {"radius": 16}, "Iris Blur…", "Blur Gallery"),
    "tiltShift": (tilt_shift, {"radius": 12, "band": 0.14}, "Tilt-Shift…", "Blur Gallery"),
    "fieldBlur": (field_blur, {"radius": 10}, "Field Blur…", "Blur Gallery"),
    # --- newly live catalog filters ---
    "colorHalftone": (color_halftone, {"size": 8}, "Color Halftone…", "Pixelate"),
    "dustAndScratches": (dust_and_scratches, {"radius": 2, "threshold": 12}, "Dust & Scratches…", "Noise"),
    "smartSharpen": (smart_sharpen, {"amount": 0.8, "radius": 2.0}, "Smart Sharpen…", "Sharpen"),
    # --- AI-style portrait / bokeh (on-device) ---
    "softPortrait": (soft_portrait, {"amount": 0.65}, "Soft Portrait", "AI"),
    "bokehBackground": (bokeh_background, {"radius": 10}, "Bokeh Background", "AI"),
    # --- Color Lookup preset packs (image.adjustments.colorLookup) ---
    "lookVivid": (look_vivid, {}, "Look: Vivid", "Color Lookup"),
    "lookTealOrange": (look_teal_orange, {}, "Look: Teal & Orange", "Color Lookup"),
    "lookWarmCinema": (look_warm_cinema, {}, "Look: Warm Cinema", "Color Lookup"),
    "lookNoir": (look_noir, {}, "Look: Noir", "Color Lookup"),
    "lookFade": (look_fade, {}, "Look: Fade", "Color Lookup"),
    "lookVintage": (look_vintage, {}, "Look: Vintage", "Color Lookup"),
    "lookCyberpunk": (look_cyberpunk, {}, "Look: Cyberpunk", "Color Lookup"),
    "lookBleach": (look_bleach, {}, "Look: Bleach Bypass", "Color Lookup"),
    "lookLandscape": (look_landscape, {}, "Look: Landscape Pop", "Color Lookup"),
}
