"""L2 — rasterize live layers (text, shapes) and layer effects.

Fonts are discovered from system dirs + PhotoCraft's bundled Inter/JetBrains
(OFL) + matplotlib's DejaVu. Text/shapes render via PIL; effects (shadow,
glow, stroke) via scipy on the alpha channel.
"""

from __future__ import annotations

import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

FONT_DIRS = [
    "/usr/share/fonts",
    os.path.expanduser("~/.fonts"),
    os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "photocraft", "assets", "fonts"),
]

_FONT_ALIASES = {
    "arial": "DejaVu Sans", "helvetica": "DejaVu Sans", "roboto": "Roboto",
    "inter": "Inter", "montserrat": "Montserrat", "verdana": "DejaVu Sans",
    "times": "DejaVu Serif", "georgia": "DejaVu Serif", "courier": "DejaVu Sans Mono",
}


def scan_fonts() -> dict:
    """{family: {style: path}} — style in regular/bold/italic/bolditalic."""
    fonts: dict = {}
    for root_dir in FONT_DIRS:
        if not os.path.isdir(root_dir):
            continue
        for root, _, files in os.walk(root_dir):
            for f in files:
                if not f.lower().endswith((".ttf", ".otf")):
                    continue
                path = os.path.join(root, f)
                family, style = _parse_font_name(f)
                if not family:
                    continue
                fonts.setdefault(family, {})[style] = path
    return fonts


def _parse_font_name(filename: str):
    name = os.path.splitext(filename)[0]
    low = name.lower().replace("_", "-").replace(" ", "-")
    style = "regular"
    for tag, st in (("bolditalic", "bolditalic"), ("bold-italic", "bolditalic"),
                    ("boldoblique", "bolditalic"), ("bold", "bold"), ("black", "bold"),
                    ("semibold", "bold"), ("extrabold", "bold"), ("medium", "regular"),
                    ("italic", "italic"), ("oblique", "italic"), ("light", "regular"),
                    ("regular", "regular"), ("normal", "regular")):
        if tag in low:
            style = st
            break
    family = name
    for sep in ("-", "_"):
        if sep in name:
            family = name.split(sep)[0]
            break
    return family.replace("DejaVuSans", "DejaVu Sans").replace("DejaVuSerif", "DejaVu Serif") \
                 .replace("DejaVuSansMono", "DejaVu Sans Mono"), style


_FONTS = None
_CACHE: dict = {}


def fonts() -> dict:
    global _FONTS
    if _FONTS is None:
        _FONTS = scan_fonts()
    return _FONTS


def font_families() -> list[str]:
    fams = [f for f in fonts() if any(k in f.lower() for k in
            ("dejavu", "inter", "roboto", "montserrat", "jetbrains", "liberation", "noto", "stix"))]
    rest = sorted(f for f in fonts() if f not in fams)
    priority = [f for f in ("Inter", "Roboto", "Montserrat", "DejaVu Sans", "DejaVu Serif",
                            "DejaVu Sans Mono", "JetBrainsMono") if f in fonts()]
    return priority + sorted(set(fams) - set(priority)) + rest


def _pick_path(family: str, bold: bool, italic: bool) -> str | None:
    fam = fonts().get(family) or fonts().get(_FONT_ALIASES.get(family.lower(), family))
    if not fam:
        # substring fallback
        for name, styles in fonts().items():
            if family.lower() in name.lower():
                fam = styles
                break
    if not fam:
        fam = fonts().get("DejaVu Sans") or next(iter(fonts().values()), None)
    if not fam:
        return None
    want = "bolditalic" if bold and italic else "bold" if bold else "italic" if italic else "regular"
    return fam.get(want) or fam.get("regular") or next(iter(fam.values()), None)


def get_font(family: str, size: float, bold=False, italic=False):
    key = (family, round(size), bold, italic)
    if key not in _CACHE:
        path = _pick_path(family, bold, italic)
        if path is None:
            _CACHE[key] = None
        else:
            try:
                _CACHE[key] = ImageFont.truetype(path, int(round(max(4, size))))
            except Exception:
                _CACHE[key] = None
    return _CACHE[key]


# ------------------------------------------------------------------- text
def render_text(params: dict) -> np.ndarray:
    """Rasterize a text layer -> RGBA uint8 tight-cropped with 4px padding."""
    text = str(params.get("text", ""))
    if not text.strip():
        return np.zeros((1, 1, 4), np.uint8)
    size = float(params.get("size", 48))
    font = get_font(params.get("font", "DejaVu Sans"), size,
                    bool(params.get("bold")), bool(params.get("italic")))
    if font is None:
        return np.zeros((1, 1, 4), np.uint8)
    color = tuple(params.get("color", [30, 30, 30, 255]))
    lh = float(params.get("line_height", 1.2))
    lines = text.split("\n")
    # measure
    widths, heights = [], []
    for ln in lines:
        try:
            box = font.getbbox(ln or " ")
            widths.append(box[2] - box[0])
            heights.append(box[3] - box[1])
        except Exception:
            widths.append(font.size)
            heights.append(int(font.size * lh))
    asc, desc = font.getmetrics()
    line_h = int((asc + desc) * lh)
    w = max(4, max(widths) + 8)
    h = max(4, line_h * len(lines) + 8)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    align = params.get("align", "left")
    for i, ln in enumerate(lines):
        lw = widths[i]
        x = 4
        if align == "center":
            x = (w - lw) // 2
        elif align == "right":
            x = w - lw - 4
        d.text((x, 4 + i * line_h), ln, font=font, fill=color)
    return np.asarray(img, np.uint8)


# ------------------------------------------------------------------ shapes
def _star_points(cx, cy, rx, ry, n=5, inner=0.45, rot=-np.pi / 2):
    pts = []
    for i in range(n * 2):
        ang = rot + i * np.pi / n
        r = 1.0 if i % 2 == 0 else inner
        pts.append((cx + rx * r * np.cos(ang), cy + ry * r * np.sin(ang)))
    return pts


def _arrow_points(w, h):
    body = 0.34
    head_w, head_l = 0.55, 0.42
    return [(0, h * (1 - body) / 2), (w * (1 - head_l), h * (1 - body) / 2),
            (w * (1 - head_l), 0), (w, h * 0.5), (w * (1 - head_l), h),
            (w * (1 - head_l), h * (1 + body) / 2), (0, h * (1 + body) / 2)]


def _bubble_points(w, h):
    tail = [(w * 0.22, h * 0.82), (w * 0.10, h), (w * 0.34, h * 0.82)]
    return [("rect", (0, 0, w - 1, h * 0.82)), ("poly", tail)]


def _heart_points(w, h):
    t = np.linspace(0, 2 * np.pi, 100)
    x = 16 * np.sin(t) ** 3
    y = 13 * np.cos(t) - 5 * np.cos(2 * t) - 2 * np.cos(3 * t) - np.cos(4 * t)
    x = (x / 34.0 + 0.5) * w
    y = (1 - (y / 30.0 + 0.55)) * h
    return list(zip(x, y))


def render_shape(params: dict) -> np.ndarray:
    kind = params.get("shape", "rect")
    w = max(2, int(params.get("w", 200)))
    h = max(2, int(params.get("h", 200)))
    fill = tuple(params.get("fill", [90, 140, 230, 255]))
    stroke = tuple(params.get("stroke", [20, 20, 20, 255]))
    sw = max(0, int(params.get("stroke_w", 0)))
    pad = sw + 2
    img = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    box = (pad, pad, pad + w - 1, pad + h - 1)
    if kind == "rect":
        d.rectangle(box, fill=fill)
        if sw: d.rectangle(box, outline=stroke, width=sw)
    elif kind == "roundrect":
        r = int(min(w, h) * float(np.clip(params.get("radius", 0.15), 0, 0.5)))
        d.rounded_rectangle(box, radius=r, fill=fill)
        if sw: d.rounded_rectangle(box, radius=r, outline=stroke, width=sw)
    elif kind == "ellipse":
        d.ellipse(box, fill=fill)
        if sw: d.ellipse(box, outline=stroke, width=sw)
    elif kind == "triangle":
        pts = [(pad + w / 2, pad), (pad + w, pad + h), (pad, pad + h)]
        d.polygon(pts, fill=fill)
        if sw: d.polygon(pts, outline=stroke, width=sw)
    elif kind == "star":
        n = int(params.get("points", 5))
        pts = _star_points(pad + w / 2, pad + h / 2, w / 2, h / 2, max(3, n))
        d.polygon(pts, fill=fill)
        if sw: d.polygon(pts, outline=stroke, width=sw)
    elif kind == "polygon":
        n = max(3, int(params.get("points", 6)))
        cx, cy = pad + w / 2, pad + h / 2
        pts = [(cx + w / 2 * np.cos(2 * np.pi * i / n - np.pi / 2),
                cy + h / 2 * np.sin(2 * np.pi * i / n - np.pi / 2)) for i in range(n)]
        d.polygon(pts, fill=fill)
        if sw: d.polygon(pts, outline=stroke, width=sw)
    elif kind == "arrow":
        pts = [(pad + x, pad + y) for x, y in _arrow_points(w, h)]
        d.polygon(pts, fill=fill)
    elif kind == "bubble":
        r = int(min(w, h) * 0.12)
        d.rounded_rectangle((pad, pad, pad + w - 1, pad + h * 0.82), radius=r, fill=fill)
        d.polygon([(pad + x, pad + y) for x, y in _bubble_points(w, h)[1]], fill=fill)
        if sw:
            d.rounded_rectangle((pad, pad, pad + w - 1, pad + h * 0.82), radius=r, outline=stroke, width=sw)
    elif kind == "heart":
        pts = [(pad + x, pad + y) for x, y in _heart_points(w, h)]
        d.polygon(pts, fill=fill)
    elif kind == "line":
        d.line([box[0], box[1] + h / 2, box[2], box[1] + h / 2], fill=fill, width=max(1, sw or max(2, h // 8)))
    return np.asarray(img, np.uint8)


# ----------------------------------------------------------------- effects
def apply_effects(rgb: np.ndarray, alpha: np.ndarray, effects: dict):
    """Return (rgb, alpha) with drop shadow / outer glow / stroke composited
    *behind* the layer. rgb: HxWx3 float [0,1]; alpha: HxW float [0,1]."""
    rgb = rgb.copy()
    alpha = alpha.copy()

    def _col(c, default):
        v = np.array((c or default), np.float32) / 255.0
        return np.clip(v[:3], 0, 1)

    def _under(color3, a_eff, base_rgb, base_a):
        """source-over of (color, alpha) under existing (rgb, alpha)."""
        co = a_eff[..., None] * color3 + base_a[..., None] * (1 - a_eff[..., None]) * base_rgb
        ao = a_eff + base_a * (1 - a_eff)
        return co, ao

    fx = effects or {}
    a_orig = alpha.copy()   # object alpha: effects never show through it
    if "glow" in fx:
        p = fx["glow"]
        blur = max(0.5, float(p.get("blur", 12)))
        a_g = ndimage.gaussian_filter(alpha, blur) * (1.0 - a_orig)
        a_g = np.clip(a_g * float(p.get("opacity", 0.8)), 0, 1)
        rgb, alpha = _under(_col(p.get("color"), (255, 240, 180)), a_g, rgb, alpha)
    if "shadow" in fx:
        p = fx["shadow"]
        blur = max(0.5, float(p.get("blur", 10)))
        dx, dy = int(p.get("dx", 6)), int(p.get("dy", 6))
        a_s = np.roll(np.roll(ndimage.gaussian_filter(alpha, blur), dy, 0), dx, 1) * (1.0 - a_orig)
        a_s = np.clip(a_s * float(p.get("opacity", 0.55)), 0, 1)
        rgb, alpha = _under(_col(p.get("color"), (0, 0, 0)), a_s, rgb, alpha)
    if "stroke" in fx:
        p = fx["stroke"]
        w = max(1, int(p.get("width", 3)))
        struct = np.ones((w * 2 + 1, w * 2 + 1), bool)
        dil = ndimage.binary_dilation(alpha > 0.02, structure=struct).astype(np.float32)
        ring = np.clip(dil - alpha, 0, 1) * float(p.get("opacity", 1.0))
        rgb, alpha = _under(_col(p.get("color"), (255, 255, 255)), ring, rgb, alpha)
    return np.clip(rgb, 0, 1), np.clip(alpha, 0, 1)
