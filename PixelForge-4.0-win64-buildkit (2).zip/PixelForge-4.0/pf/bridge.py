"""L4 — PhotoCraft engine bridge.

Drives the Rust `photocraft-cli serve` headless engine (JSON lines on stdio)
to reuse PhotoCraft's proven core: 500+ Photoshop-grade commands, high-fidelity
PSD I/O, heavy filters. Our Python engine stays authoritative for interactive
editing; the bridge is the "pro engine" escape hatch.

Layout: a per-session work directory is passed as --automation-read-root and
--automation-write-root; file methods take paths relative to those roots.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile

import numpy as np
from PIL import Image

DEFAULT_ENGINE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "..", "engine", "photocraft-cli")


class EngineError(RuntimeError):
    pass


class PhotoCraftBridge:
    """Session-scoped bridge. Use as a context manager or call close()."""

    def __init__(self, engine_path: str | None = None, roots: list[str] | None = None):
        self.engine_path = engine_path or os.environ.get("PHOTOCRAFT_CLI") or os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "engine", "photocraft-cli"))
        self.workdir = tempfile.mkdtemp(prefix="pixelforge-engine-")
        self.roots = roots or [self.workdir]
        self.proc: subprocess.Popen | None = None
        self._id = 0
        self._commands: list[dict] | None = None

    # ----------------------------------------------------------- lifecycle
    def available(self) -> bool:
        return os.path.isfile(self.engine_path) and os.access(self.engine_path, os.X_OK)

    def start(self) -> bool:
        if self.proc is not None:
            return True
        if not self.available():
            return False
        args = [self.engine_path, "serve"]
        for root in self.roots:
            args += ["--automation-read-root", root, "--automation-write-root", root]
        self.proc = subprocess.Popen(
            args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, bufsize=1)
        return True

    def close(self) -> None:
        if self.proc is not None:
            try:
                self.proc.terminate()
            except Exception:
                pass
            self.proc = None
        shutil.rmtree(self.workdir, ignore_errors=True)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.close()

    # ---------------------------------------------------------------- rpc
    def rpc(self, method: str, params: dict | None = None) -> dict:
        if self.proc is None and not self.start():
            raise EngineError("PhotoCraft engine not found (set PHOTOCRAFT_CLI)")
        self._id += 1
        req_id = self._id
        line = json.dumps({"id": req_id, "method": method, "params": params or {}})
        try:
            self.proc.stdin.write(line + "\n")
            self.proc.stdin.flush()
        except Exception as exc:
            raise EngineError(f"engine write failed: {exc}") from exc
        while True:
            raw = self.proc.stdout.readline()
            if not raw:
                raise EngineError("engine closed the session")
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if msg.get("id") == req_id:
                if not msg.get("ok", False):
                    raise EngineError(str(msg.get("error", "engine error")))
                return msg.get("result")

    # ------------------------------------------------------------- helpers
    def commands(self, refetch: bool = False) -> list[dict]:
        if self._commands is None or refetch:
            self._commands = self.rpc("engine.commands") or []
        return self._commands

    def _stage(self, src_path: str) -> str:
        """Copy a file into the automation root; return relative name."""
        dst = os.path.join(self.workdir, "_in_" + os.path.basename(src_path))
        shutil.copy2(src_path, dst)
        return os.path.basename(dst)

    def open_document(self, path: str) -> int:
        rel = self._stage(path)
        res = self.rpc("doc.open", {"path": rel})
        return int(res["index"])

    def execute(self, doc_index: int, command: str, params: dict | None = None) -> None:
        self.rpc("engine.execute", {"document": doc_index, "command": command,
                                    "params": params or {}})

    def render(self, doc_index: int) -> Image.Image:
        res = self.rpc("doc.render", {"document": doc_index, "maxSide": 0})
        import base64
        data = base64.b64decode(res["base64"])
        return Image.open(__import__("io").BytesIO(data))

    def save_document(self, doc_index: int, dest_path: str, fmt: str | None = None) -> str:
        rel = "_out_" + os.path.basename(dest_path)
        params: dict = {"document": doc_index, "path": rel}
        if fmt:
            params["format"] = fmt
        self.rpc("doc.save", params)
        final = os.path.join(self.workdir, rel)
        shutil.move(final, dest_path)
        return dest_path

    # --------------------------------------------------------- one-shots
    def run_command_on_file(self, src_path: str, command: str, params: dict | None,
                            dest_path: str | None = None) -> str:
        """Open a file, run one engine command, save back out. Returns dest."""
        dest_path = dest_path or src_path
        doc_index = self.open_document(src_path)
        self.execute(doc_index, command, params)
        ext = os.path.splitext(dest_path)[1].lower().lstrip(".") or "png"
        fmt = {"jpg": "jpg", "jpeg": "jpg", "png": "png", "psd": "psd",
               "tif": "tif", "tiff": "tif", "webp": "webp"}.get(ext, "png")
        self.save_document(doc_index, dest_path, fmt=fmt)
        return dest_path

    def render_file(self, src_path: str) -> np.ndarray:
        """Render a file with the engine -> HxWx4 uint8 (for verification)."""
        doc_index = self.open_document(src_path)
        img = self.render(doc_index).convert("RGBA")
        return np.asarray(img, np.uint8)
