"""L3 — CPU compositor v2: pixels + live text/shape layers + adjustment layers,
layer masks, layer effects. numpy/scipy only."""

from __future__ import annotations

import json

import numpy as np

from . import adjust as ADJ
from . import color as C
from . import render as R
from .doc import (AdjustmentLayer, Document, GroupLayer, PixelLayer, ShapeLayer,
                  TextLayer)


def _rasterize_live(layer) -> tuple[np.ndarray, int, int] | None:
    """(rgba, x, y) pixels for text/shape layers, cached on the instance."""
    cache_key = json.dumps(layer.params, sort_keys=True)
    cached = getattr(layer, "_rcache", None)
    if cached is not None and cached[0] == cache_key:
        return cached[1]
    if isinstance(layer, TextLayer):
        px = R.render_text(layer.params)
    elif isinstance(layer, ShapeLayer):
        px = R.render_shape(layer.params)
    else:
        return None
    result = (px, layer.x, layer.y)
    layer._rcache = (cache_key, result)
    return result


def _effective_pixels(layer: PixelLayer, doc_w: int, doc_h: int):
    """Layer payload -> (rgba_u8, x, y) with live layers rasterized."""
    if isinstance(layer, PixelLayer):
        return layer.pixels, layer.x, layer.y
    r = _rasterize_live(layer)
    return (r[0], r[1], r[2]) if r else (None, 0, 0)


def _blend_layer(canvas: np.ndarray, layer, doc_w: int, doc_h: int) -> None:
    """Blend one visible layer (any kind) into the float canvas."""
    pixels, lx, ly = _effective_pixels(layer, doc_w, doc_h)
    if pixels is None or pixels.size == 0:
        return
    h, w = canvas.shape[:2]

    src_rgb_full = pixels[..., :3].astype(np.float32) / 255.0
    src_a_full = pixels[..., 3].astype(np.float32) / 255.0

    # layer effects on the tight source box
    if layer.effects:
        src_rgb_full, src_a_full = R.apply_effects(src_rgb_full, src_a_full, layer.effects)

    # clip to canvas
    x0, y0 = max(0, lx), max(0, ly)
    x1, y1 = min(w, lx + src_a_full.shape[1]), min(h, ly + src_a_full.shape[0])
    if x1 <= x0 or y1 <= y0:
        return
    src_rgb = src_rgb_full[y0 - ly:y1 - ly, x0 - lx:x1 - lx]
    src_a = src_a_full[y0 - ly:y1 - ly, x0 - lx:x1 - lx]

    # layer mask (canvas-aligned)
    if layer.mask is not None and layer.mask_enabled:
        m = layer.mask[y0:y1, x0:x1].astype(np.float32) / 255.0
        src_a = src_a * m

    dst = canvas[y0:y1, x0:x1]
    src4 = np.concatenate([src_rgb, src_a[..., None]], -1)
    canvas[y0:y1, x0:x1] = C.over(dst, src4, layer.blend, layer.opacity)


def _apply_adjustment(canvas: np.ndarray, layer: AdjustmentLayer) -> None:
    """Apply an adjustment layer to the current canvas (with mask+opacity)."""
    rgb = canvas[..., :3]
    out = ADJ.apply_adjustment(rgb, layer.adjustment, layer.params)
    amount = layer.opacity
    if layer.mask is not None and layer.mask_enabled:
        amount = amount * (layer.mask.astype(np.float32) / 255.0)[..., None]
    canvas[..., :3] = rgb * (1 - amount) + out * amount


def compose_children(children: list, width: int, height: int) -> np.ndarray | None:
    """Composite a bottom-to-top list into a WxH float buffer (groups)."""
    if width <= 0 or height <= 0:
        return None
    canvas = np.zeros((height, width, 4), np.float32)
    any_visible = False
    for layer in children:
        if not layer.visible:
            continue
        if isinstance(layer, AdjustmentLayer):
            if canvas[..., 3].max() > 0:
                _apply_adjustment(canvas, layer)
                any_visible = True
        elif isinstance(layer, (TextLayer, ShapeLayer, PixelLayer)):
            _blend_layer(canvas, layer, width, height)
            any_visible = True
    return canvas if any_visible else None


def composite_document(doc: Document) -> np.ndarray:
    canvas = np.zeros((doc.height, doc.width, 4), np.float32)
    for layer in doc.flat_composite_list():
        if not layer.visible:
            continue
        if isinstance(layer, AdjustmentLayer):
            if canvas[..., 3].max() > 0:
                _apply_adjustment(canvas, layer)
        else:
            _blend_layer(canvas, layer, doc.width, doc.height)
    return canvas


def composite_rgba8(doc: Document) -> np.ndarray:
    canvas = composite_document(doc)
    return np.clip(canvas * 255.0 + 0.5, 0, 255).astype(np.uint8)


def composite_rgb8(doc: Document, background=(255, 255, 255)) -> np.ndarray:
    canvas = composite_document(doc)
    a = canvas[..., 3:4]
    bg = np.array(background, np.float32) / 255.0
    rgb = canvas[..., :3] * a + bg * (1.0 - a)
    return np.clip(rgb * 255.0 + 0.5, 0, 255).astype(np.uint8)
